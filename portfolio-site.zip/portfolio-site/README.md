# Ajay Kumar Sharma — Personal Portfolio

A luxury-grade, ultra-premium personal portfolio website built with **React JS**, **Tailwind CSS**, and **Framer Motion**.

## Tech Stack

- **React 18** — Component-based UI
- **Vite** — Lightning-fast dev server and build tool
- **Tailwind CSS** — Utility-first styling with custom design system
- **Framer Motion** — Smooth entrance animations in Hero section
- **react-icons** — Icon library (Feather icons)

## Project Structure

```
portfolio-site/
├── public/
│   └── resume.pdf          ← Place your resume PDF here
├── src/
│   ├── components/
│   │   ├── Navbar.jsx      ← Sticky navbar with mobile menu
│   │   └── Footer.jsx      ← Minimal branded footer
│   ├── data/
│   │   └── portfolioData.js← Single source of truth for all content
│   ├── hooks/
│   │   ├── useScrollAnimation.js  ← IntersectionObserver reveal hook
│   │   └── useTypingEffect.js     ← Typewriter animation hook
│   ├── sections/
│   │   ├── Hero.jsx        ← Full-viewport landing with typing animation
│   │   ├── About.jsx       ← Professional summary + stat cards
│   │   ├── Skills.jsx      ← Categorized technical skills
│   │   ├── Experience.jsx  ← Expandable timeline cards
│   │   ├── Projects.jsx    ← Flagship project case study cards
│   │   ├── Education.jsx   ← Academic background
│   │   ├── Awards.jsx      ← Recognition & achievements
│   │   └── Contact.jsx     ← Contact details + CTA
│   ├── App.jsx
│   ├── main.jsx
│   └── index.css           ← Tailwind directives + custom utilities
├── index.html
├── package.json
├── tailwind.config.js
├── postcss.config.js
└── vite.config.js
```

## Getting Started

### 1. Install dependencies

```bash
npm install
```

### 2. Add your resume PDF

Place your `resume.pdf` inside the `public/` directory so the **Download Resume** button works.

### 3. Start development server

```bash
npm run dev
```

Open [http://localhost:5173](http://localhost:5173) in your browser.

### 4. Build for production

```bash
npm run build
```

Output will be in the `dist/` folder, ready for deployment.

### 5. Preview production build

```bash
npm run preview
```

## Updating Content

All portfolio content lives in a single file:

```
src/data/portfolioData.js
```

Edit this file to update:
- Personal info, email, phone, LinkedIn
- Skills and categories
- Work experience and highlights
- Projects, tech stack, and impact metrics
- Education history
- Awards and recognition

## Deployment

The built `dist/` folder can be deployed to:
- **Vercel** — `vercel --prod`
- **Netlify** — Drag & drop the `dist/` folder
- **GitHub Pages** — Use `vite-plugin-gh-pages`
- Any static hosting provider

## Design Highlights

- Dark premium theme (`#050816` deep space background)
- Sky blue accent (`#38bdf8`) with indigo gradient on display text
- Sora display font + Inter body + JetBrains Mono for code/labels
- Scroll-triggered section reveal animations
- Typewriter effect cycling through professional roles
- Expandable experience timeline cards
- Responsive across mobile, tablet, and desktop
- Custom scrollbar styling
- Accessible semantic HTML throughout
