import React, { useState } from 'react';
import { FiChevronDown } from 'react-icons/fi';
import { useScrollAnimation } from '../hooks/useScrollAnimation';
import { experience } from '../data/portfolioData';

export default function Experience() {
  const { ref, isVisible } = useScrollAnimation();
  const [expanded, setExpanded] = useState(0);

  const toggle = (i) => setExpanded((prev) => (prev === i ? -1 : i));

  return (
    <section id="experience" className="py-24 lg:py-36">
      <div className="max-w-7xl mx-auto px-6">
        <div
          ref={ref}
          className={`transition-all duration-700 ease-out ${
            isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
          }`}
        >
          {/* Section header */}
          <div className="mb-16">
            <p className="section-label mb-3">03 / Experience</p>
            <h2 className="font-display text-4xl md:text-5xl font-bold text-slate-100">
              Professional <span className="text-gradient">Journey</span>
            </h2>
          </div>

          <div className="relative">
            {/* Timeline line (desktop) */}
            <div className="absolute left-[31px] top-8 bottom-8 w-px bg-gradient-to-b from-sky-400/50 via-sky-400/15 to-transparent hidden md:block" />

            <div className="space-y-6">
              {experience.map((job, index) => (
                <div key={index} className="relative md:pl-20">
                  {/* Timeline dot */}
                  <div
                    className={`absolute left-[22px] top-7 w-[18px] h-[18px] rounded-full border-2 hidden md:flex items-center justify-center ${
                      job.current
                        ? 'border-sky-400 bg-sky-400/15'
                        : 'border-slate-600 bg-[#090d1f]'
                    }`}
                  >
                    {job.current && (
                      <div className="w-2 h-2 rounded-full bg-sky-400 animate-pulse" />
                    )}
                  </div>

                  {/* Card */}
                  <div
                    className="bg-[#090d1f] border border-slate-800/90 hover:border-sky-400/25 rounded-2xl overflow-hidden transition-all duration-300 card-glow card-glow-hover cursor-pointer"
                    onClick={() => toggle(index)}
                    role="button"
                    aria-expanded={expanded === index}
                  >
                    {/* Card header */}
                    <div className="p-6 md:p-8">
                      <div className="flex flex-wrap items-start justify-between gap-4">
                        <div>
                          <div className="flex flex-wrap items-center gap-2 mb-1">
                            <h3 className="font-display text-xl font-bold text-slate-100">
                              {job.role}
                            </h3>
                            {job.current && (
                              <span className="px-2.5 py-0.5 text-[10px] font-mono text-sky-400 border border-sky-400/30 rounded-full bg-sky-400/5 tracking-wider uppercase">
                                Current
                              </span>
                            )}
                          </div>
                          <p className="text-sky-400 font-semibold">{job.company}</p>
                          <p className="text-slate-500 text-sm mt-0.5">{job.location}</p>
                        </div>

                        <div className="flex items-start gap-4">
                          <div className="text-right">
                            <p className="text-slate-300 font-mono text-sm">{job.period}</p>
                            <p className="text-slate-500 text-xs mt-0.5">{job.duration}</p>
                          </div>
                          <FiChevronDown
                            className={`w-5 h-5 text-slate-500 mt-0.5 transition-transform duration-300 shrink-0 ${
                              expanded === index ? 'rotate-180' : ''
                            }`}
                          />
                        </div>
                      </div>

                      {/* Expandable highlights */}
                      <div
                        className={`overflow-hidden transition-all duration-500 ${
                          expanded === index ? 'max-h-[600px] opacity-100 mt-6' : 'max-h-0 opacity-0'
                        }`}
                      >
                        <div className="border-t border-slate-800/70 pt-5">
                          <ul className="space-y-3">
                            {job.highlights.map((item, i) => (
                              <li
                                key={i}
                                className="flex items-start gap-3 text-slate-400 text-sm leading-relaxed"
                              >
                                <span className="text-sky-400 mt-0.5 shrink-0 text-xs">▹</span>
                                {item}
                              </li>
                            ))}
                          </ul>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
