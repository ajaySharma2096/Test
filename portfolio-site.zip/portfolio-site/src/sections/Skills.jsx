import React from 'react';
import { useScrollAnimation } from '../hooks/useScrollAnimation';
import { skills, skillMeta } from '../data/portfolioData';

export default function Skills() {
  const { ref, isVisible } = useScrollAnimation();

  return (
    <section id="skills" className="py-24 lg:py-36 bg-[#090d1f]/40">
      <div className="max-w-7xl mx-auto px-6">
        <div
          ref={ref}
          className={`transition-all duration-700 ease-out ${
            isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
          }`}
        >
          {/* Section header */}
          <div className="mb-16">
            <p className="section-label mb-3">02 / Expertise</p>
            <h2 className="font-display text-4xl md:text-5xl font-bold text-slate-100">
              Technical <span className="text-gradient">Expertise</span>
            </h2>
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
            {Object.entries(skills).map(([category, items]) => {
              const meta = skillMeta[category];
              return (
                <div
                  key={category}
                  className={`relative border rounded-2xl p-6 bg-gradient-to-br ${meta.colorClasses} hover:scale-[1.02] transition-transform duration-300 card-glow`}
                >
                  {/* Category header */}
                  <div className="flex items-center gap-3 mb-5">
                    <span className="text-2xl leading-none">{meta.icon}</span>
                    <h3 className={`font-display font-semibold text-base ${meta.labelClass}`}>
                      {category}
                    </h3>
                  </div>

                  {/* Skill badges */}
                  <div className="flex flex-wrap gap-2">
                    {items.map((skill) => (
                      <span
                        key={skill}
                        className={`px-3 py-1 text-xs font-medium rounded-full border cursor-default transition-colors duration-200 ${meta.badgeClasses}`}
                      >
                        {skill}
                      </span>
                    ))}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
}
