import React from 'react';
import { FiMail, FiPhone, FiLinkedin, FiMapPin } from 'react-icons/fi';
import { useScrollAnimation } from '../hooks/useScrollAnimation';
import { personalInfo } from '../data/portfolioData';

const contactItems = [
  {
    Icon: FiMail,
    label: 'Email',
    value: 'ajaykumarsharma.20196@gmail.com',
    href: 'mailto:ajaykumarsharma.20196@gmail.com',
    external: false,
  },
  {
    Icon: FiPhone,
    label: 'Phone',
    value: '8077651669',
    href: 'tel:8077651669',
    external: false,
  },
  {
    Icon: FiLinkedin,
    label: 'LinkedIn',
    value: 'linkedin.com/in/ajay-sharma-219b53141',
    href: 'https://linkedin.com/in/ajay-sharma-219b53141',
    external: true,
  },
  {
    Icon: FiMapPin,
    label: 'Location',
    value: 'Noida, Uttar Pradesh, India',
    href: null,
    external: false,
  },
];

export default function Contact() {
  const { ref, isVisible } = useScrollAnimation();

  return (
    <section id="contact" className="py-24 lg:py-36">
      <div className="max-w-7xl mx-auto px-6">
        <div
          ref={ref}
          className={`transition-all duration-700 ease-out ${
            isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
          }`}
        >
          {/* Section header */}
          <div className="mb-16">
            <p className="section-label mb-3">07 / Contact</p>
            <h2 className="font-display text-4xl md:text-5xl font-bold text-slate-100">
              Let&apos;s <span className="text-gradient">Connect</span>
            </h2>
          </div>

          <div className="grid lg:grid-cols-2 gap-16 items-start">
            {/* Left — CTA copy */}
            <div>
              <p className="text-slate-300 text-lg leading-relaxed mb-5">
                I'm open to discussing{' '}
                <span className="text-sky-400 font-medium">
                  senior engineering roles, technical leadership
                </span>
                , and high-impact engineering challenges where I can drive architecture decisions,
                mentor teams, and deliver measurable business value.
              </p>
              <p className="text-slate-400 leading-relaxed mb-10">
                Whether you're a recruiter, hiring manager, or technology leader — reach out and
                let's explore what we can build together.
              </p>
              <a
                href={`mailto:${personalInfo.email}`}
                className="inline-flex items-center gap-3 px-8 py-4 bg-sky-500 hover:bg-sky-400 text-white font-semibold rounded-xl transition-all duration-200 shadow-lg shadow-sky-500/20 hover:shadow-sky-400/30 hover:-translate-y-0.5"
              >
                <FiMail className="w-5 h-5" />
                Send an Email
              </a>
            </div>

            {/* Right — Contact details */}
            <div className="space-y-3">
              {contactItems.map(({ Icon, label, value, href, external }, i) => {
                const inner = (
                  <div className="flex items-center gap-4 bg-[#090d1f] border border-slate-800 hover:border-sky-400/30 rounded-xl p-5 transition-all duration-300 card-glow card-glow-hover">
                    <div
                      className="w-12 h-12 rounded-xl border border-sky-400/20 flex items-center justify-center shrink-0"
                      style={{ background: 'rgba(56,189,248,0.07)' }}
                    >
                      <Icon className="w-5 h-5 text-sky-400" />
                    </div>
                    <div className="min-w-0">
                      <p className="text-[10px] font-mono text-slate-500 uppercase tracking-[0.18em] mb-0.5">
                        {label}
                      </p>
                      <p className="text-slate-200 font-medium text-sm truncate">{value}</p>
                    </div>
                  </div>
                );

                return href ? (
                  <a
                    key={i}
                    href={href}
                    target={external ? '_blank' : undefined}
                    rel={external ? 'noopener noreferrer' : undefined}
                    className="block"
                  >
                    {inner}
                  </a>
                ) : (
                  <div key={i}>{inner}</div>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
