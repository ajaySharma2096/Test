import React from 'react';
import { useScrollAnimation } from '../hooks/useScrollAnimation';
import { awards } from '../data/portfolioData';

export default function Awards() {
  const { ref, isVisible } = useScrollAnimation();

  return (
    <section id="awards" className="py-24 lg:py-36 bg-[#090d1f]/40">
      <div className="max-w-7xl mx-auto px-6">
        <div
          ref={ref}
          className={`transition-all duration-700 ease-out ${
            isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
          }`}
        >
          {/* Section header */}
          <div className="mb-16">
            <p className="section-label mb-3">06 / Recognition</p>
            <h2 className="font-display text-4xl md:text-5xl font-bold text-slate-100">
              Awards &amp; <span className="text-gradient">Achievements</span>
            </h2>
          </div>

          <div className="grid md:grid-cols-2 gap-6 max-w-4xl">
            {awards.map((award, index) => {
              const isPlat = award.tier === 'platinum';
              return (
                <div
                  key={index}
                  className={`relative overflow-hidden rounded-2xl p-8 border transition-all duration-300 hover:-translate-y-1 ${
                    isPlat
                      ? 'bg-gradient-to-br from-[#100f00] to-[#0a0800] border-amber-500/25 hover:border-amber-400/50 hover:shadow-xl hover:shadow-amber-500/8'
                      : 'bg-gradient-to-br from-[#001018] to-[#000d18] border-sky-500/25 hover:border-sky-400/50 hover:shadow-xl hover:shadow-sky-500/8'
                  }`}
                >
                  {/* Ambient glow */}
                  <div
                    className={`pointer-events-none absolute -top-8 -right-8 w-40 h-40 rounded-full blur-3xl opacity-15 ${
                      isPlat ? 'bg-amber-400' : 'bg-sky-400'
                    }`}
                  />

                  <div className="relative">
                    {/* Icon and year */}
                    <div className="flex items-start justify-between mb-5">
                      <span className="text-4xl leading-none">{award.icon}</span>
                      <span
                        className={`text-xs font-mono px-3 py-1 rounded-full border ${
                          isPlat
                            ? 'text-amber-400 border-amber-400/30 bg-amber-400/5'
                            : 'text-sky-400 border-sky-400/30 bg-sky-400/5'
                        }`}
                      >
                        {award.year}
                      </span>
                    </div>

                    {/* Title */}
                    <h3
                      className={`font-display text-xl font-bold mb-1 ${
                        isPlat ? 'text-amber-300' : 'text-sky-300'
                      }`}
                    >
                      {award.title}
                    </h3>
                    <p className="text-slate-500 text-sm font-medium mb-4">
                      {award.organization}
                    </p>
                    <p className="text-slate-400 text-sm leading-relaxed">{award.description}</p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
}
