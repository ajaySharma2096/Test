import React from 'react';
import { FiBookOpen } from 'react-icons/fi';
import { useScrollAnimation } from '../hooks/useScrollAnimation';
import { education } from '../data/portfolioData';

export default function Education() {
  const { ref, isVisible } = useScrollAnimation();

  return (
    <section id="education" className="py-24 lg:py-36">
      <div className="max-w-7xl mx-auto px-6">
        <div
          ref={ref}
          className={`transition-all duration-700 ease-out ${
            isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
          }`}
        >
          {/* Section header */}
          <div className="mb-16">
            <p className="section-label mb-3">05 / Education</p>
            <h2 className="font-display text-4xl md:text-5xl font-bold text-slate-100">
              Academic <span className="text-gradient">Foundation</span>
            </h2>
          </div>

          <div className="space-y-4 max-w-3xl">
            {education.map((edu, index) => (
              <div
                key={index}
                className={`flex items-start gap-5 rounded-2xl p-6 border transition-colors duration-300 card-glow card-glow-hover ${
                  edu.primary
                    ? 'bg-[#0c1029] border-sky-400/20 hover:border-sky-400/40'
                    : 'bg-[#090d1f] border-slate-800 hover:border-slate-700'
                }`}
              >
                {/* Icon */}
                <div
                  className={`w-12 h-12 rounded-xl flex items-center justify-center shrink-0 ${
                    edu.primary
                      ? 'bg-sky-400/12 border border-sky-400/25'
                      : 'bg-slate-800/80 border border-slate-700/60'
                  }`}
                  style={edu.primary ? { background: 'rgba(56,189,248,0.09)' } : undefined}
                >
                  <FiBookOpen
                    className={`w-5 h-5 ${edu.primary ? 'text-sky-400' : 'text-slate-500'}`}
                  />
                </div>

                {/* Info */}
                <div className="flex-1 min-w-0">
                  <div className="flex flex-wrap items-start justify-between gap-3">
                    <div>
                      <h3
                        className={`font-display font-semibold text-base leading-tight ${
                          edu.primary ? 'text-slate-100' : 'text-slate-300'
                        }`}
                      >
                        {edu.degree}
                      </h3>
                      <p
                        className={`text-sm font-medium mt-0.5 ${
                          edu.primary ? 'text-sky-400' : 'text-slate-400'
                        }`}
                      >
                        {edu.field}
                      </p>
                      <p className="text-slate-500 text-sm mt-1">{edu.institution}</p>
                    </div>
                    <span
                      className={`text-xs font-mono px-3 py-1 rounded-full shrink-0 ${
                        edu.primary
                          ? 'text-sky-400 bg-sky-400/8 border border-sky-400/15'
                          : 'text-slate-500 bg-slate-800/60 border border-slate-700/60'
                      }`}
                      style={edu.primary ? { background: 'rgba(56,189,248,0.06)' } : undefined}
                    >
                      {edu.period}
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
