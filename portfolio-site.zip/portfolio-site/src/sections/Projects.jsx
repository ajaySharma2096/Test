import React from 'react';
import { FiZap } from 'react-icons/fi';
import { useScrollAnimation } from '../hooks/useScrollAnimation';
import { projects } from '../data/portfolioData';

const typeColors = {
  'Enterprise Platform': 'text-sky-400 bg-sky-400/5 border-sky-400/15',
  'Configuration Platform': 'text-violet-400 bg-violet-400/5 border-violet-400/15',
  'AI / Automation': 'text-amber-400 bg-amber-400/5 border-amber-400/15',
};

export default function Projects() {
  const { ref, isVisible } = useScrollAnimation();

  return (
    <section id="projects" className="py-24 lg:py-36 bg-[#090d1f]/40">
      <div className="max-w-7xl mx-auto px-6">
        <div
          ref={ref}
          className={`transition-all duration-700 ease-out ${
            isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
          }`}
        >
          {/* Section header */}
          <div className="mb-16">
            <p className="section-label mb-3">04 / Projects</p>
            <h2 className="font-display text-4xl md:text-5xl font-bold text-slate-100">
              Signature <span className="text-gradient">Work</span>
            </h2>
          </div>

          <div className="grid lg:grid-cols-3 gap-6">
            {projects.map((project, index) => (
              <article
                key={index}
                className="group relative flex flex-col bg-[#0c0f1e] border border-slate-800/80 hover:border-sky-400/35 rounded-2xl p-6 transition-all duration-300 hover:-translate-y-1 card-glow card-glow-hover overflow-hidden"
              >
                {/* Top glow on hover */}
                <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-sky-400/0 to-transparent group-hover:via-sky-400/40 transition-all duration-500" />

                {/* Header */}
                <div className="flex items-start justify-between gap-3 mb-4">
                  <span
                    className={`px-3 py-1 text-[11px] font-mono rounded-full border ${
                      typeColors[project.type] ?? 'text-slate-400 bg-slate-400/5 border-slate-400/15'
                    }`}
                  >
                    {project.type}
                  </span>
                  <span className="text-slate-600 text-xs shrink-0">{project.company}</span>
                </div>

                {/* Project name */}
                <h3 className="font-display text-xl font-bold text-slate-100 mb-2 group-hover:text-sky-300 transition-colors duration-200">
                  {project.name}
                </h3>

                <p className="text-slate-400 text-sm font-medium mb-2">{project.summary}</p>
                <p className="text-slate-500 text-sm leading-relaxed mb-6 flex-1">
                  {project.description}
                </p>

                {/* Impact */}
                <div className="mb-5">
                  <div className="flex items-center gap-1.5 mb-2.5">
                    <FiZap className="w-3 h-3 text-amber-400" />
                    <span
                      className="text-[10px] font-mono text-amber-400/80 uppercase tracking-[0.15em]"
                    >
                      Impact
                    </span>
                  </div>
                  <ul className="space-y-1.5">
                    {project.impact.map((item, i) => (
                      <li key={i} className="flex items-start gap-2 text-xs text-slate-400">
                        <span className="text-amber-400 mt-0.5 shrink-0">•</span>
                        {item}
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Tech stack */}
                <div className="flex flex-wrap gap-1.5 pt-4 border-t border-slate-800/80">
                  {project.tech.map((tech) => (
                    <span
                      key={tech}
                      className="px-2.5 py-1 text-[11px] font-mono text-slate-400 bg-slate-800/60 rounded-md"
                    >
                      {tech}
                    </span>
                  ))}
                </div>
              </article>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
