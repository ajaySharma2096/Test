import React from 'react';
import { useScrollAnimation } from '../hooks/useScrollAnimation';

const stats = [
  { value: '~8', label: 'Years Experience', sub: 'Full stack engineering' },
  { value: '25%', label: 'Bundle Reduction', sub: 'Via Webpack optimization' },
  { value: '30%', label: 'Faster Page Loads', sub: 'FCP & LCP optimization' },
  { value: '90%', label: 'TAT Reduction', sub: 'For application changes' },
];

const coreTags = ['React.js', 'TypeScript', 'Node.js', 'Micro Frontend', 'Agentic AI', 'CI/CD'];

export default function About() {
  const { ref, isVisible } = useScrollAnimation();

  return (
    <section id="about" className="py-24 lg:py-36">
      <div className="max-w-7xl mx-auto px-6">
        <div
          ref={ref}
          className={`transition-all duration-700 ease-out ${
            isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
          }`}
        >
          {/* Section header */}
          <div className="mb-16">
            <p className="section-label mb-3">01 / About</p>
            <h2 className="font-display text-4xl md:text-5xl font-bold text-slate-100 leading-tight">
              Engineering Excellence,
              <br />
              <span className="text-gradient">Delivered at Scale</span>
            </h2>
          </div>

          <div className="grid lg:grid-cols-5 gap-12 lg:gap-16 items-center">
            {/* Bio text */}
            <div className="lg:col-span-3 space-y-5">
              <p className="text-slate-300 text-lg leading-relaxed">
                I'm a{' '}
                <span className="text-sky-400 font-semibold">Full Stack Engineer with ~8 years</span>{' '}
                of focused expertise in building and scaling fintech platforms that serve millions of
                users. My work sits at the intersection of frontend architecture, performance
                engineering, and AI-enabled development workflows.
              </p>
              <p className="text-slate-400 leading-relaxed">
                At{' '}
                <span className="text-slate-200 font-medium">Paytm Payments Bank</span>, I've led
                the development of mission-critical systems — from enterprise back-office operations
                panels to AI-powered SDLC tooling — consistently delivering measurable performance
                gains, elevated developer experience, and tangible business outcomes.
              </p>
              <p className="text-slate-400 leading-relaxed">
                I'm deeply passionate about clean architecture, developer productivity, and
                leveraging modern AI tools to accelerate engineering delivery without compromising
                quality, compliance, or team standards.
              </p>

              {/* Tags */}
              <div className="flex flex-wrap gap-2 pt-2">
                {coreTags.map((tag) => (
                  <span
                    key={tag}
                    className="px-3 py-1.5 text-xs font-mono text-sky-300 bg-sky-400/8 border border-sky-400/15 rounded-lg"
                    style={{ background: 'rgba(56,189,248,0.06)' }}
                  >
                    {tag}
                  </span>
                ))}
              </div>
            </div>

            {/* Stats */}
            <div className="lg:col-span-2 grid grid-cols-2 gap-4">
              {stats.map((stat, i) => (
                <div
                  key={i}
                  className="bg-[#090d1f] border border-slate-800 hover:border-sky-400/25 rounded-2xl p-5 transition-colors duration-300 card-glow card-glow-hover"
                >
                  <div className="font-display text-3xl font-bold text-sky-400 mb-1">
                    {stat.value}
                  </div>
                  <div className="text-slate-200 text-sm font-semibold mb-1">{stat.label}</div>
                  <div className="text-slate-500 text-xs leading-snug">{stat.sub}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
