import React from 'react';
import { motion } from 'framer-motion';
import { FiMail, FiLinkedin, FiDownload, FiArrowDown } from 'react-icons/fi';
import { personalInfo, roles } from '../data/portfolioData';
import { useTypingEffect } from '../hooks/useTypingEffect';

const fadeUp = {
  hidden: { opacity: 0, y: 28 },
  visible: (delay) => ({
    opacity: 1,
    y: 0,
    transition: { duration: 0.7, delay: delay ?? 0, ease: [0.16, 1, 0.3, 1] },
  }),
};

export default function Hero() {
  const typed = useTypingEffect(roles, 75, 2400);

  return (
    <section
      id="hero"
      className="relative min-h-screen flex items-center justify-center overflow-hidden"
    >
      {/* Background */}
      <div className="absolute inset-0 bg-[#050816]" />
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_80%_55%_at_50%_-15%,rgba(56,189,248,0.09),transparent)]" />
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_55%_55%_at_85%_85%,rgba(99,102,241,0.05),transparent)]" />

      {/* Subtle grid */}
      <div
        className="absolute inset-0"
        style={{
          opacity: 0.022,
          backgroundImage:
            'linear-gradient(rgba(148,163,184,1) 1px, transparent 1px), linear-gradient(90deg, rgba(148,163,184,1) 1px, transparent 1px)',
          backgroundSize: '72px 72px',
        }}
      />

      {/* Ambient orbs */}
      <div className="pointer-events-none absolute top-1/3 left-1/4 w-96 h-96 rounded-full bg-sky-500/4 blur-[100px]" />
      <div className="pointer-events-none absolute bottom-1/3 right-1/4 w-[500px] h-[500px] rounded-full bg-indigo-600/4 blur-[120px]" />

      {/* Content */}
      <div className="relative z-10 max-w-4xl mx-auto px-6 text-center pt-20 pb-32">
        {/* Status badge */}
        <motion.div
          variants={fadeUp}
          initial="hidden"
          animate="visible"
          custom={0.1}
          className="mb-8"
        >
          <span className="inline-flex items-center gap-2 px-4 py-2 text-[11px] font-mono text-sky-400 border border-sky-400/20 rounded-full bg-sky-400/5 tracking-[0.18em] uppercase">
            <span className="w-1.5 h-1.5 rounded-full bg-sky-400 animate-pulse" />
            Open to Senior Engineering Roles
          </span>
        </motion.div>

        {/* Name */}
        <motion.h1
          variants={fadeUp}
          initial="hidden"
          animate="visible"
          custom={0.25}
          className="font-display font-extrabold leading-[1.08] tracking-tight mb-6 text-slate-100"
          style={{ fontSize: 'clamp(3rem, 9vw, 6rem)' }}
        >
          Ajay Kumar{' '}
          <span className="text-gradient">Sharma</span>
        </motion.h1>

        {/* Typing role */}
        <motion.div
          variants={fadeUp}
          initial="hidden"
          animate="visible"
          custom={0.4}
          className="mb-6 h-10 flex items-center justify-center"
        >
          <span className="font-display text-xl sm:text-2xl text-slate-300 font-light">
            {typed}
            <span className="inline-block w-[2px] h-[1.1em] ml-1 bg-sky-400 align-middle animate-pulse rounded-sm" />
          </span>
        </motion.div>

        {/* Tagline */}
        <motion.p
          variants={fadeUp}
          initial="hidden"
          animate="visible"
          custom={0.55}
          className="text-slate-400 text-base sm:text-lg max-w-2xl mx-auto leading-relaxed mb-12"
        >
          ~8 years engineering high-scale fintech platforms. Deep expertise in React.js, TypeScript,
          and frontend architecture — delivering performance, precision, and measurable business impact.
        </motion.p>

        {/* CTAs */}
        <motion.div
          variants={fadeUp}
          initial="hidden"
          animate="visible"
          custom={0.7}
          className="flex flex-wrap items-center justify-center gap-4 mb-14"
        >
          <a
            href="#projects"
            className="px-7 py-3.5 bg-sky-500 hover:bg-sky-400 text-white font-semibold rounded-xl transition-all duration-200 shadow-lg shadow-sky-500/20 hover:shadow-sky-400/30 hover:-translate-y-0.5"
          >
            View Projects
          </a>
          <a
            href="#contact"
            className="px-7 py-3.5 border border-sky-400/35 text-sky-300 hover:bg-sky-400/10 hover:border-sky-400/60 font-semibold rounded-xl transition-all duration-200 hover:-translate-y-0.5"
          >
            Contact Me
          </a>
          <a
            href="/Ajay%20Kumar%20Sharma.pdf"
            download="Ajay Kumar Sharma.pdf"
            className="flex items-center gap-2 px-5 py-3.5 text-slate-400 hover:text-slate-200 font-medium transition-colors duration-200"
          >
            <FiDownload className="w-4 h-4" />
            Download Resume
          </a>
        </motion.div>

        {/* Social icons */}
        <motion.div
          variants={fadeUp}
          initial="hidden"
          animate="visible"
          custom={0.85}
          className="flex items-center justify-center gap-3"
        >
          <a
            href={personalInfo.linkedin}
            target="_blank"
            rel="noopener noreferrer"
            aria-label="LinkedIn Profile"
            className="w-11 h-11 flex items-center justify-center rounded-xl border border-slate-700/70 text-slate-400 hover:text-sky-400 hover:border-sky-400/50 hover:bg-sky-400/5 transition-all duration-200"
          >
            <FiLinkedin className="w-5 h-5" />
          </a>
          <a
            href={`mailto:${personalInfo.email}`}
            aria-label="Send Email"
            className="w-11 h-11 flex items-center justify-center rounded-xl border border-slate-700/70 text-slate-400 hover:text-sky-400 hover:border-sky-400/50 hover:bg-sky-400/5 transition-all duration-200"
          >
            <FiMail className="w-5 h-5" />
          </a>
        </motion.div>
      </div>

      {/* Scroll cue */}
      <motion.a
        href="#about"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.6, duration: 0.8 }}
        className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 text-slate-500 hover:text-sky-400 transition-colors duration-200"
      >
        <span
          className="text-[10px] font-mono tracking-[0.22em] uppercase"
          style={{ fontFamily: "'JetBrains Mono', monospace" }}
        >
          Scroll
        </span>
        <FiArrowDown className="w-4 h-4 animate-bounce" />
      </motion.a>
    </section>
  );
}
