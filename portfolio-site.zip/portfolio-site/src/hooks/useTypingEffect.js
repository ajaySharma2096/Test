import { useState, useEffect, useCallback } from 'react';

/**
 * Cycles through an array of strings with a typewriter effect.
 * @param {string[]} strings - Strings to cycle through.
 * @param {number} typeSpeed  - ms per character when typing.
 * @param {number} pause      - ms to wait before deleting.
 */
export function useTypingEffect(strings, typeSpeed = 75, pause = 2200) {
  const [display, setDisplay] = useState('');
  const [index, setIndex] = useState(0);
  const [deleting, setDeleting] = useState(false);

  const tick = useCallback(() => {
    const current = strings[index];
    if (!deleting && display === current) {
      setTimeout(() => setDeleting(true), pause);
      return;
    }
    if (deleting && display === '') {
      setDeleting(false);
      setIndex((prev) => (prev + 1) % strings.length);
      return;
    }
    setDisplay((prev) =>
      deleting ? prev.slice(0, -1) : current.slice(0, prev.length + 1)
    );
  }, [display, deleting, index, strings, pause]);

  useEffect(() => {
    const delay = deleting ? typeSpeed / 2 : typeSpeed;
    const timer = setTimeout(tick, delay);
    return () => clearTimeout(timer);
  }, [tick, deleting, typeSpeed]);

  return display;
}
