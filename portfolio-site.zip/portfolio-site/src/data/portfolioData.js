export const personalInfo = {
  name: 'Ajay Kumar Sharma',
  firstName: 'Ajay Kumar',
  lastName: 'Sharma',
  title: 'Senior Full Stack Engineer',
  subtitle: 'Fintech Specialist · Frontend Architect · AI-Enabled Engineering',
  tagline: '~8 Years Building High-Scale Fintech Platforms',
  summary:
    'Full Stack Engineer with around 8 years of experience developing and leading high-scale fintech platforms. Proficient in React.js, TypeScript, Node.js and frontend architecture, with a strong emphasis on performance optimization, scalability, and delivering business-critical solutions in agile environments.',
  email: 'ajaykumarsharma.20196@gmail.com',
  phone: '8077651669',
  linkedin: 'https://linkedin.com/in/ajay-sharma-219b53141',
  location: 'Noida, India',
};

export const roles = [
  'Senior Full Stack Engineer',
  'Frontend Architect',
  'Fintech Engineering Lead',
  'AI-Enabled Developer',
  'Performance Engineering Expert',
];

export const skills = {
  Frontend: ['React.js', 'Redux', 'TypeScript', 'JavaScript (ES6+)', 'HTML5', 'CSS3', 'Bootstrap', 'Webpack'],
  Backend: ['Node.js', 'Express.js', 'REST APIs'],
  Databases: ['MySQL', 'MongoDB'],
  'Tools & Platforms': ['Git', 'Kibana', 'Grafana', 'Prometheus', 'Thanos', 'SonarQube', 'Lighthouse', 'Jenkins', 'Docker'],
  Architecture: ['Micro Frontend Architecture', 'System Design', 'CI/CD', 'Agentic AI', 'Unit Testing'],
};

export const skillMeta = {
  Frontend: { icon: '⚡', colorClasses: 'border-sky-500/25 from-sky-500/8 to-sky-500/3', badgeClasses: 'bg-sky-400/10 text-sky-300 border-sky-400/20 hover:bg-sky-400/18', labelClass: 'text-sky-400' },
  Backend: { icon: '🔧', colorClasses: 'border-emerald-500/25 from-emerald-500/8 to-emerald-500/3', badgeClasses: 'bg-emerald-400/10 text-emerald-300 border-emerald-400/20 hover:bg-emerald-400/18', labelClass: 'text-emerald-400' },
  Databases: { icon: '🗄️', colorClasses: 'border-violet-500/25 from-violet-500/8 to-violet-500/3', badgeClasses: 'bg-violet-400/10 text-violet-300 border-violet-400/20 hover:bg-violet-400/18', labelClass: 'text-violet-400' },
  'Tools & Platforms': { icon: '🛠️', colorClasses: 'border-amber-500/25 from-amber-500/8 to-amber-500/3', badgeClasses: 'bg-amber-400/10 text-amber-300 border-amber-400/20 hover:bg-amber-400/18', labelClass: 'text-amber-400' },
  Architecture: { icon: '🏗️', colorClasses: 'border-rose-500/25 from-rose-500/8 to-rose-500/3', badgeClasses: 'bg-rose-400/10 text-rose-300 border-rose-400/20 hover:bg-rose-400/18', labelClass: 'text-rose-400' },
};

export const experience = [
  {
    company: 'Paytm Payments Bank',
    shortCompany: 'PPBL',
    location: 'Noida',
    role: 'Senior Software Engineer',
    period: 'Mar 2021 – Present',
    duration: '4+ Years',
    current: true,
    highlights: [
      'Developed and maintained BOP and NBP, reducing bundle size by 25% through Webpack optimization.',
      'Designed and implemented an AI-enabled SDLC delivery workflow that converts Jira requirements into a controlled Planning → Review → Execute pipeline, improving consistency and standards compliance.',
      'Built an AI-readiness assessment framework for code repositories that evaluates current AI compatibility and generates improvement recommendations.',
      'Enhanced PPBL Website accessibility (a11y) by implementing WCAG-compliant practices.',
      'Enhanced monitoring using Kibana, Grafana and SonarQube, reducing downtime by 15%.',
      'Led team of BOP and mentored 5 junior developers, ensuring scalable and high-performance solutions.',
      'Leveraged AI tools (GitHub Copilot) in daily development to accelerate delivery timelines.',
    ],
  },
  {
    company: 'Polestar Solutions & Services India Pvt. Ltd.',
    shortCompany: 'Polestar',
    location: 'Noida',
    role: 'Software Engineer',
    period: 'Apr 2018 – Feb 2021',
    duration: '~3 Years',
    current: false,
    highlights: [
      'Developed data visualization applications using React.js, Node.js, MySQL, and Qlik Sense.',
      'Collaborated with clients and backend teams to deliver scalable UI components and finalize API contracts.',
    ],
  },
];

export const projects = [
  {
    name: 'Back Office Panel',
    company: 'Paytm Payments Bank',
    type: 'Enterprise Platform',
    summary:
      'Mission-critical web application for CST, Operations, and Product teams powering full-scale banking operations.',
    description:
      'Developed and maintained the enterprise web application enabling transaction history, account management, ATM/UPI reconciliation, notification management, and cross-team operational actions for Paytm Payments Bank.',
    tech: ['React.js', 'TypeScript', 'Redux', 'Webpack', 'Lighthouse', 'REST APIs'],
    impact: [
      '30% improvement in page load speed',
      'FCP and LCP optimized via Lighthouse',
      'Improved cross-team process efficiency',
    ],
  },
  {
    name: 'App Manager',
    company: 'Paytm Payments Bank',
    type: 'Configuration Platform',
    summary:
      'Node.js-based configuration management platform for PPBL and OCL integrated applications.',
    description:
      'Developed a configuration management application with CRUD operations, Maker-Checker approval workflows, and delta response optimization — reducing release friction across integrated banking applications.',
    tech: ['Node.js', 'Express.js', 'MySQL', 'REST APIs'],
    impact: [
      '90% reduction in TAT for application changes',
      'Improved scalability and compliance posture',
      'Streamlined Maker-Checker approval workflows',
    ],
  },
  {
    name: 'AI-Enabled SDLC Workflow',
    company: 'Paytm Payments Bank',
    type: 'AI / Automation',
    summary:
      'Intelligent delivery pipeline that converts Jira requirements into a structured engineering workflow.',
    description:
      'Designed and implemented an AI-enabled SDLC delivery workflow that converts Jira requirements into a controlled Planning → Review → Execute pipeline, enabling consistent delivery and standards compliance across engineering teams.',
    tech: ['Agentic AI', 'GitHub Copilot', 'Jira', 'CI/CD'],
    impact: [
      'Improved delivery consistency across cycles',
      'Enhanced engineering standards compliance',
      'Accelerated planning-to-execution pipeline',
    ],
  },
];

export const education = [
  {
    degree: 'Bachelor of Technology',
    field: 'Computer Science & Engineering',
    institution: 'RKGIT Ghaziabad',
    period: '2014 – 2018',
    primary: true,
  },
  {
    degree: 'Intermediate (Class XII)',
    field: 'Science',
    institution: 'Jawahar Navodaya Vidyalaya, Meerut',
    period: '2012 – 2013',
    primary: false,
  },
  {
    degree: 'High School (Class X)',
    field: 'General Studies',
    institution: 'Jawahar Navodaya Vidyalaya, Meerut',
    period: '2010 – 2011',
    primary: false,
  },
];

export const awards = [
  {
    title: 'Rising Star Award',
    year: '2021',
    organization: 'Paytm Payments Bank',
    description:
      'Recognized for exceptional contributions during the 24-hour DR Drill, demonstrating technical leadership, crisis management excellence, and deep ownership of critical banking systems.',
    icon: '⭐',
    tier: 'gold',
  },
  {
    title: 'Rock Star Award',
    year: '2022, 2024 & 2025',
    organization: 'Paytm Payments Bank',
    description:
      'Awarded three times for being a consistent high performer — delivering impactful engineering solutions, mentoring team members, and driving measurable business outcomes across multiple years.',
    icon: '🏆',
    tier: 'platinum',
  },
];
