import React from 'react';
import { FiLinkedin, FiMail, FiPhone } from 'react-icons/fi';
import { personalInfo } from '../data/portfolioData';

export default function Footer() {
  return (
    <footer className="border-t border-slate-800/60 bg-[#050816]">
      <div className="max-w-7xl mx-auto px-6 py-10 flex flex-col sm:flex-row items-center justify-between gap-6">
        {/* Brand */}
        <div>
          <p className="font-display font-bold text-base text-slate-100">
            <span className="text-sky-400">Ajay Kumar Sharma</span> 
          </p>
          <p className="text-slate-500 text-xs font-mono mt-0.5">Senior Full Stack Engineer</p>
        </div>

        {/* Center copy */}
        <p className="text-slate-600 text-xs font-mono order-last sm:order-none text-center">
          © {new Date().getFullYear()} Ajay Kumar Sharma
        </p>

        {/* Social links */}
        <div className="flex items-center gap-3">
          <a
            href={personalInfo.linkedin}
            target="_blank"
            rel="noopener noreferrer"
            aria-label="LinkedIn"
            className="w-9 h-9 flex items-center justify-center rounded-lg border border-slate-800 text-slate-500 hover:text-sky-400 hover:border-sky-400/40 hover:bg-sky-400/5 transition-all duration-200"
          >
            <FiLinkedin className="w-4 h-4" />
          </a>
          <a
            href={`mailto:${personalInfo.email}`}
            aria-label="Email"
            className="w-9 h-9 flex items-center justify-center rounded-lg border border-slate-800 text-slate-500 hover:text-sky-400 hover:border-sky-400/40 hover:bg-sky-400/5 transition-all duration-200"
          >
            <FiMail className="w-4 h-4" />
          </a>
          <a
            href={`tel:${personalInfo.phone}`}
            aria-label="Phone"
            className="w-9 h-9 flex items-center justify-center rounded-lg border border-slate-800 text-slate-500 hover:text-sky-400 hover:border-sky-400/40 hover:bg-sky-400/5 transition-all duration-200"
          >
            <FiPhone className="w-4 h-4" />
          </a>
        </div>
      </div>
    </footer>
  );
}
