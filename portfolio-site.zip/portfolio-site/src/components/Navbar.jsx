import React, { useState, useEffect } from 'react';
import { FiMenu, FiX, FiDownload } from 'react-icons/fi';

const navLinks = [
  { label: 'About', href: '#about' },
  { label: 'Skills', href: '#skills' },
  { label: 'Experience', href: '#experience' },
  { label: 'Projects', href: '#projects' },
  { label: 'Education', href: '#education' },
  { label: 'Awards', href: '#awards' },
  { label: 'Contact', href: '#contact' },
];

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 60);
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled
          ? 'bg-[#050816]/90 backdrop-blur-xl border-b border-slate-800/80 shadow-xl shadow-black/20'
          : 'bg-transparent'
      }`}
    >
      <div className="max-w-7xl mx-auto px-6 h-16 flex items-center justify-between">
        {/* Logo */}
        <a href="#hero" className="font-display font-bold text-lg tracking-tight shrink-0">
          <span className="text-sky-400">AKS</span>
          <span className="ml-1.5 text-slate-500 text-xs font-mono font-normal hidden sm:inline">
            / portfolio
          </span>
        </a>

        {/* Desktop nav */}
        <nav className="hidden md:flex items-center gap-1">
          {navLinks.map((link) => (
            <a
              key={link.href}
              href={link.href}
              className="px-3 py-2 text-sm text-slate-400 hover:text-sky-400 transition-colors duration-200 font-medium rounded-md hover:bg-sky-400/5"
            >
              {link.label}
            </a>
          ))}
          <a
            href="/Ajay%20Kumar%20Sharma.pdf"
            download="Ajay Kumar Sharma.pdf"
            className="ml-3 flex items-center gap-1.5 px-4 py-2 text-sm font-semibold text-sky-400 border border-sky-400/40 rounded-lg hover:bg-sky-400/10 hover:border-sky-400/70 transition-all duration-200"
          >
            <FiDownload className="w-3.5 h-3.5" />
            Resume
          </a>
        </nav>

        {/* Mobile hamburger */}
        <button
          className="md:hidden w-9 h-9 flex items-center justify-center text-slate-300 hover:text-sky-400 transition-colors rounded-lg hover:bg-slate-800/60"
          onClick={() => setMenuOpen((o) => !o)}
          aria-label={menuOpen ? 'Close menu' : 'Open menu'}
          aria-expanded={menuOpen}
        >
          {menuOpen ? <FiX className="w-5 h-5" /> : <FiMenu className="w-5 h-5" />}
        </button>
      </div>

      {/* Mobile menu */}
      <div
        className={`md:hidden overflow-hidden transition-all duration-300 ${
          menuOpen ? 'max-h-96 opacity-100' : 'max-h-0 opacity-0'
        }`}
      >
        <nav className="bg-[#090d1f]/98 backdrop-blur-xl border-b border-slate-800/80 px-6 py-4">
          <ul className="space-y-1">
            {navLinks.map((link) => (
              <li key={link.href}>
                <a
                  href={link.href}
                  className="block px-3 py-2.5 text-sm text-slate-400 hover:text-sky-400 hover:bg-sky-400/5 rounded-md transition-colors duration-200 font-medium"
                  onClick={() => setMenuOpen(false)}
                >
                  {link.label}
                </a>
              </li>
            ))}
            <li className="pt-2">
              <a
                href="/Ajay%20Kumar%20Sharma.pdf"
                download="Ajay Kumar Sharma.pdf"
                className="flex items-center gap-2 px-3 py-2.5 text-sm font-semibold text-sky-400 border border-sky-400/40 rounded-lg hover:bg-sky-400/10 transition-all"
                onClick={() => setMenuOpen(false)}
              >
                <FiDownload className="w-3.5 h-3.5" />
                Download Resume
              </a>
            </li>
          </ul>
        </nav>
      </div>
    </header>
  );
}
