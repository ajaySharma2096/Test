#!/usr/bin/env bash
. docker/utils.sh
if commandExecutor  ". docker/getversion.sh";then
  commandExecutor "sudo docker build -f docker/Dockerfile --build-arg MIDDLEWARE_APP_MANAGER_VERSION=${version} -t dockerregistry.paytmpb.io/paytmbank/middleware-app-manager:${version}_${1} ."
else
  ret 1
fi