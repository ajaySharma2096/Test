#!/usr/bin/env bash
. docker/utils.sh
search './docker' 'Dockerfile' && search './app-manager/' 'package.json'