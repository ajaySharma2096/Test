case "$MIDDLEWARE_APP_MANAGER_ENV" in
   "eks-mwite1") npm run server:${MIDDLEWARE_APP_MANAGER_ENV}
   ;;
   "mwprod") npm run server:${MIDDLEWARE_APP_MANAGER_ENV}
   ;;
   "prod") npm run server:${MIDDLEWARE_APP_MANAGER_ENV}
   ;;
esac