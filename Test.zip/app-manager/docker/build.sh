#!/usr/bin/env bash
apt-get update && apt-get install build-essential make -y
. docker/utils.sh
npm install -g increase-memory-limit
export NODE_OPTIONS=--max_old_space_size=2048
cd ./app-manager
echo RUNNING NPM INSTALL
npm install
echo NPM INSTALL FINISHED
npm run build
cd ..
tar --exclude="app-manager/src" -czvf bank-web.tar app-manager/