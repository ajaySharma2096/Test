#!/bin/bash

`sed -i "s/APP_MANAGER_ENV/${APP_MANAGER_ENV}/g" /etc/nginx/nginx.conf`
`sed -i "s/APP_MANAGER_IMAGE_TAG/${APP_MANAGER_IMAGE_TAG}/g" /etc/nginx/nginx.conf`

`nginx -g 'daemon off;'`

exec "$@"
