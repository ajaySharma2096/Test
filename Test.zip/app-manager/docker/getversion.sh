#!/usr/bin/env bash
# meant to be included by another script
# queries version and puts in variable
. docker/utils.sh
PROJECT_DIR="$( pwd )"

if search $PROJECT_DIR/app-manager package.json;then
  version=$(cat ./app-manager/package.json |python -c 'import sys, json; print json.load(sys.stdin)["version"]')
else
  return 1
fi