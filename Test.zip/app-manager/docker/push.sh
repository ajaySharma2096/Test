#!/usr/bin/env bash
. docker/utils.sh
commandExecutor "sudo docker images dockerregistry.paytmpb.io/paytmbank/app-manager:${1}" "sudo docker push dockerregistry.paytmpb.io/paytmbank/app-manager:${1}"
