# AGENTS.md — Canonical Project Guidelines

> **For AI coding agents** (GitHub Copilot, Cursor, Claude, Codex, Gemini, and any other AI assistant):  
> Read this file first, before every task in this repository.

---

## What This Repository Is

**App Manager** is a TypeScript/Express.js middleware service for Paytm Payments Bank mobile and web applications. It provides:

- **Configuration management** — stores, serves, and invalidates key-value configuration pairs scoped to specific mobile client types (Android, iOS, Bank Android, Bank iOS).
- **JWT authentication gateway** — validates signed tokens on every protected request, enforcing claim alignment between the token and the API version.

The service sits between mobile clients and a MongoDB configuration store, with NodeCache providing read-path acceleration.

**Technology stack**: TypeScript 5.8.3 (strict mode) · Express.js 4.18.2 · MongoDB 5+ (Mongoose) · JWT · Helmet · XSS · NodeCache · Bunyan · Webpack · Docker · Jenkins

---

## 📚 Documentation Suite

### 🎯 Primary Hub: `docs/ai/`

**Core Foundation:**
1. **[Repository Overview](docs/ai/repo-overview.md)** — Purpose, full tech stack, project structure, getting started, key features
2. **[System Architecture](docs/ai/architecture.md)** — Request flows, middleware order, DB schema, caching strategy, security layer diagram
3. **[Coding Standards](docs/ai/coding-standards.md)** — TypeScript rules, naming conventions, error/logging/response patterns, Prettier

**Implementation & Security:**
4. **[API & Error Handling](docs/ai/api-error-handling.md)** — All routes with middleware chains, params, error codes (1000–1012), response shapes
5. **[Security Implementation](docs/ai/security.md)** — JWT verification steps, XSS middleware logic, Helmet directives, input validation, known limitations

**Development & Operations:**
6. **[Build & Validation](docs/ai/build-validation.md)** — Install, build, run commands, Docker, Jenkins pipeline, TypeScript validation
7. **[Agent Workflow](docs/ai/agent-workflow.md)** — Definition of done, how to add endpoints/clients/versions, debugging guides
8. **[Contribution Checklist](docs/ai/contribution-checklist.md)** — Pre-merge checklist, change-type → doc-to-update matrix, ADR template

**Architectural Decisions:**
- **[ADR-001 — Versioned Routes, JWT Claims, Cache Strategy](docs/ai/adr-versioned-routes-jwt-and-cache.md)** — Why v1/v2/v3 exist, why JWT claims differ, why NodeCache was chosen

---

## 🤖 MANDATORY: Read Before Any Task

| Priority | Document | When to read |
|---|---|---|
| **Always** | [Repository Overview](docs/ai/repo-overview.md) | Before every task — understand what this service does |
| **Always** | [Coding Standards](docs/ai/coding-standards.md) | Before writing or modifying any TypeScript |
| **Always** | [Agent Workflow](docs/ai/agent-workflow.md) | Before starting — understand definition of done |
| API work | [API & Error Handling](docs/ai/api-error-handling.md) | Before adding or changing any route or error code |
| Security work | [Security Implementation](docs/ai/security.md) | Before touching auth, middleware, or input validation |
| Architecture questions | [System Architecture](docs/ai/architecture.md) | Before modifying request flow or middleware order |
| Build/CI work | [Build & Validation](docs/ai/build-validation.md) | Before changing build scripts, Docker config, or CI |
| Documentation changes | [Contribution Checklist](docs/ai/contribution-checklist.md) | Before closing any PR or task |
| Architecture decisions | [ADR-001](docs/ai/adr-versioned-routes-jwt-and-cache.md) | Before modifying versioned routes, JWT claims, or cache |

---

## 🏗️ Architecture Quick Reference

### Route Versioning (Do Not Break These Rules)

| Route generation | Prefix | Token claim | Purpose |
|---|---|---|---|
| v1 external | `/v1/api/app-manager` | `client` | Read configs by client |
| v1 internal | `/internal/v1/api/app-manager` | `namespace` | Write configs (add/update/delete) |
| v2 | `/ext/v2/api/app-manager` | `namespace` | Read configs by namespace |
| v3 | `/ext/v3/api/app-manager` | `namespace` | Delta reads via `lastUpdatedAt` |

**Do not modify existing route versions to add new behavior.** Create a new version instead. See [ADR-001](docs/ai/adr-versioned-routes-jwt-and-cache.md) for the rationale.

### Middleware Execution Order (Never Reorder)

```
body-parser → Morgan → checkAllowedMethods → xssMiddleware → Helmet
   → [route] → logRequest → validate* → verifyToken* → controller
   → [on error] → globalErrorHandler
```

### Key Directories

```
app-manager/src/
├── server.ts              # Express bootstrap, middleware wiring, route mounting
├── config/               # Config loader (env var injection), Bunyan logger
└── app-manager/
    ├── constants.ts      # Error codes, client IDs, JWT constants — all magic strings live here
    ├── cache/            # NodeCache singleton (TTL from config)
    ├── common/models/    # ErrorWrapper class, JWT payload interfaces
    ├── controllers/      # Route handler business logic
    ├── database/         # MongoDB connection + Mongoose models
    ├── middleware/       # Auth (XSS), JWT verification, validators, error handler
    ├── routes/           # v1, v2, v3 route definitions
    └── utils/            # successResponse, errorResponse, cache helpers, monitoring
environment/              # Per-environment JSON config files (no secrets)
```

### Environment Configurations

| File | Target |
|---|---|
| `dev-config.json` | Local development |
| `eks-mwite1-config.json` | Staging (EKS) |
| `prod-config.json` | Production |
| `mwprod-config.json` | Alternate production |

---

## 💻 Code Quality Requirements

### Imports — always use path aliases

```typescript
// ✅ Correct
import logger from '@config/logger';
import { ErrorWrapper } from '@app-manager/common/models/error';
import { appManagerCache } from '@app-manager/cache';

// ❌ Never use relative chains
import logger from '../../../config/logger';
```

### Error handling — always use ErrorWrapper + next()

```typescript
// ✅ Required pattern in all middleware and controllers
export const myMiddleware = (req: Request, res: Response, next: NextFunction) => {
  const clientRequestId = req.header('requestId') as string;
  try {
    // ... logic
    next();
  } catch (error) {
    return next(new ErrorWrapper(
      error?.message || ERROR_STATUS.INTERNAL_ERROR.RESPONSE.MESSAGE,
      error?.status  || ERROR_STATUS.INTERNAL_ERROR.HTTP_RESPONSE,
      clientRequestId,
      error?.code    || ERROR_STATUS.INTERNAL_ERROR.RESPONSE.ERROR_CODE,
    ));
  }
};

// ❌ Never: res.json() or res.send() for error cases in middleware/controllers
```

### Logging — always include requestId

```typescript
// ✅ Correct
logger.info({ requestId: clientRequestId, response: data });
logger.error({ requestId: clientRequestId, error: err });

// ❌ Never: plain strings or logs without requestId in request-scoped code
```

### Constants — never hardcode strings or error codes

```typescript
// ✅ Use constants.ts
throw new ErrorWrapper(
  ERROR_STATUS.ACCESS_DENIED.RESPONSE.MESSAGE,
  ERROR_STATUS.ACCESS_DENIED.HTTP_RESPONSE,
  clientRequestId,
  ERROR_STATUS.ACCESS_DENIED.RESPONSE.ERROR_CODE.MISSING_TOKEN, // 1001
);

// ❌ Never inline magic values
throw new ErrorWrapper('Access Denied', 401, reqId, 1001);
```

### No `any` without justification

```typescript
// ✅ Acceptable only with an explanatory comment on the same line
const pipeline: any = [{ $match }, { $sort }]; // mongoose aggregate requires any[]

// ❌ Never without justification
const data: any = fetchFromDB();
```

---

## 🔐 Security Rules — Non-Negotiable

1. **Never bypass `xssMiddleware`** — applied globally in `server.ts`; do not restrict to specific routes.
2. **Never bypass `verifyToken`/`verifyTokenV2`** on any route that touches configuration data.
3. **Never commit secrets** — JWT keys and DB credentials come from environment variables only.
4. **Never log secrets** — log only `requestId`, `client`, `namespace`, and safe identifiers.
5. **Always validate query parameters** before they reach controllers — use a route-specific validator.
6. **Always add new allowed values** (clients, namespaces, referrers) to `constants.ts`, not inline.

### JWT Authentication Flow
1. Client provides signed JWT in `Authorization` header
2. `verifyToken` (v1) or `verifyTokenV2` (v2/v3) validates: signature → `iss` → `iat` window → `requestId` → claim alignment (`client`/`namespace`)
3. Any failure returns HTTP 401 with a specific error code (1000–1012 in `constants.ts`)

### Required Environment Variables (secrets — never in config files)

| Variable | Purpose |
|---|---|
| `MIDDLEWARE_APP_MANAGER_MOBILE_JWT_SECRET_KEY` | v1 JWT verification |
| `MIDDLEWARE_APP_MANAGER_PPBLAPP_MOBILE_JWT_SECRET_KEY` | v2/v3 JWT verification |
| `MIDDLEWARE_APP_MANAGER_MONGO_USER` | MongoDB username |
| `MIDDLEWARE_APP_MANAGER_MONGO_PASSWORD` | MongoDB password |

---

## 📊 Definition of Done (Every Task)

- [ ] `yarn build:dev` exits 0 (TypeScript compiles without errors)
- [ ] `npx prettier --check "src/**/*.ts"` exits 0
- [ ] No `any` without justification comment
- [ ] All errors use `ErrorWrapper` and are passed to `next()`
- [ ] All logs include `requestId`
- [ ] No new string literals — constants added to `constants.ts`
- [ ] Import paths use `@app-manager/*` / `@config/*`
- [ ] New routes have a validator registered before `verifyToken`
- [ ] Documentation updated as required by [contribution-checklist.md](docs/ai/contribution-checklist.md)

### Performance Standards
- API response time: < 500ms for configuration endpoints
- Database query time: < 100ms for indexed queries
- Cache hit paths: < 10ms

### Testing Requirements (Future Implementation)
- Unit test coverage: 80% minimum
- Integration tests for all API endpoints
- Security testing for authentication flows

---

## 🎯 Files to Give AI as Context

For general feature work:
- `src/app-manager/constants.ts`
- `src/app-manager/common/models/error.ts`
- `src/app-manager/middleware/validations.ts`
- `src/app-manager/middleware/jwt-token.ts`
- `src/app-manager/utils/index.ts`
- The relevant `routes/<version>/config.routes.ts`

For cache-related work, also include:
- `src/app-manager/cache/index.ts`
- `src/app-manager/utils/keys.ts`

For security/auth work, also include:
- `src/app-manager/middleware/auth.ts`
- `src/config/index.ts`

---

## �️ Module Ownership

Module ownership is defined in [`CODEOWNERS`](CODEOWNERS) at the repository root. Owners are automatically requested for review on any PR touching their paths.

| Risk level | Modules | Owner team |
|---|---|---|
| **Security-critical** | `middleware/jwt-token.ts`, `middleware/auth.ts`, `config/index.ts` | `@paytmbank/security-team` |
| **API contract** | `constants.ts`, `common/models/` | `@paytmbank/middleware-team` + security |
| **Entry point** | `server.ts` | middleware + security |
| **Route definitions** | `routes/v1`, `routes/v2`, `routes/v3` | `@paytmbank/middleware-team` |
| **Shared utilities** | `utils/`, `cache/` | `@paytmbank/middleware-team` |
| **Database layer** | `database/` | `@paytmbank/middleware-team` |
| **CI/CD & Docker** | `Jenkinsfile`, `docker/` | `@paytmbank/devops-team` |
| **Documentation** | `docs/ai/`, `AGENTS.md` | `@paytmbank/middleware-team` |

> Any AI-generated change to a **Security-critical** module must be reviewed by a human from `@paytmbank/security-team` before merge — do not self-approve.

---

## �🚫 What AI Agents Must NOT Do

- Do not add new dependencies without discussing the rationale
- Do not modify routes in an existing version (v1/v2/v3) to accommodate new behavior — create v4+
- Do not remove or scope-restrict Helmet or XSS middleware
- Do not generate or hardcode JWT secrets, database passwords, or any credentials
- Do not use `res.json()`/`res.send()` directly for error responses in controllers or middleware
- Do not skip writing a validator for a new route
- Do not leave `docs/ai/` documentation out of date after a change

---

## 🔄 Change Management

### For any code change:
1. Read the relevant docs from `docs/ai/` first
2. Follow established patterns from the existing codebase
3. Implement security measures (JWT validation, XSS, input validation)
4. Add structured logging with `requestId`
5. Update `docs/ai/` if any API contract, security rule, or architecture changes
6. Verify the full Definition of Done checklist above

### For documentation changes:
1. Follow [Contribution Checklist](docs/ai/contribution-checklist.md) standards
2. Validate all code examples against the actual codebase
3. Significant architectural decisions → create a new ADR in `docs/ai/`

---

## 📞 Quick Navigation

| Need | Link |
|---|---|
| Getting started / project structure | [Repository Overview](docs/ai/repo-overview.md) |
| How request flows work | [System Architecture](docs/ai/architecture.md) |
| Naming, patterns, TypeScript rules | [Coding Standards](docs/ai/coding-standards.md) |
| Routes, error codes, response shapes | [API & Error Handling](docs/ai/api-error-handling.md) |
| JWT, XSS, Helmet, secrets | [Security Implementation](docs/ai/security.md) |
| Build, Docker, CI commands | [Build & Validation](docs/ai/build-validation.md) |
| How to add features, debug, work rules | [Agent Workflow](docs/ai/agent-workflow.md) |
| Pre-merge checklist, doc update rules | [Contribution Checklist](docs/ai/contribution-checklist.md) |
| Why versioned routes / JWT / cache | [ADR-001](docs/ai/adr-versioned-routes-jwt-and-cache.md) |
| AI Readiness Score | [AI Readiness Report](docs/ai-readiness-report-app-manager.html) |
| Module ownership / PR routing | [CODEOWNERS](CODEOWNERS) |
| Production deployment topology | [System Architecture — Deployment](docs/ai/architecture.md#deployment-topology) |

---

**This file is the single source of truth for all development conventions. Reference it before making any significant change to the codebase.**