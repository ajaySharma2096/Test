# App Manager

A TypeScript/Express.js middleware service for **Paytm Payments Bank** mobile and web applications. It provides configuration management (key-value store scoped to client types) and JWT-based authentication for downstream consumers.

---

## Technology Stack

| Layer | Technology |
|---|---|
| Language | TypeScript 5.8.3 (strict mode) |
| Framework | Express.js 4.18.2 |
| Database | MongoDB 5+ via Mongoose |
| Authentication | JSON Web Tokens (`jsonwebtoken` 9.0.2) |
| Security | Helmet, XSS middleware |
| In-memory cache | NodeCache |
| Logging | Bunyan |
| Build | Webpack 5 + ts-loader |
| Container | Docker (multi-stage) |
| CI/CD | Jenkins |

---

## Getting Started

### Prerequisites

- Node.js 16.15.1 LTS
- Yarn 1.x
- MongoDB 5+ (local or accessible instance)

### Install

```bash
cd app-manager
yarn install
```

### Environment Variables

```bash
export MIDDLEWARE_APP_MANAGER_MOBILE_JWT_SECRET_KEY=<v1-jwt-secret>
export MIDDLEWARE_APP_MANAGER_PPBLAPP_MOBILE_JWT_SECRET_KEY=<v2v3-jwt-secret>
export MIDDLEWARE_APP_MANAGER_MONGO_USER=<username>       # non-dev environments
export MIDDLEWARE_APP_MANAGER_MONGO_PASSWORD=<password>   # non-dev environments
```

### Run (development)

```bash
yarn server:dev
```

Server starts on **port 4000**.

---

## API Overview

| Version | Prefix | Contract | Purpose |
|---|---|---|---|
| v1 | `/v1/api/app-manager` | `client`-keyed | External config reads |
| v1 internal | `/internal/v1/api/app-manager` | `namespace`-keyed | Config writes (add/update/delete) |
| v2 | `/ext/v2/api/app-manager` | `namespace`-keyed | External config reads |
| v3 | `/ext/v3/api/app-manager` | `namespace`-keyed + delta | External config reads with delta support |

All protected routes require:
- `Authorization` header — signed JWT
- `requestId` header — UUID v4

---

## Build Commands

| Command | Description |
|---|---|
| `yarn server:dev` | Build (dev mode) + run with `dev-config.json` |
| `yarn build` | Production Webpack build |
| `yarn build:dev` | Development Webpack build |
| `yarn server:prod` | Run production build with `prod-config.json` |
| `yarn bump` | Interactive version bump + commit + tag + push |

---

## Project Structure

```
src/
├── server.ts              ← Express bootstrap, middleware wiring, route mounting
├── config/                ← Config loader, Bunyan logger
└── app-manager/
    ├── constants.ts       ← Error codes, client IDs, JWT constants
    ├── cache/             ← NodeCache singleton
    ├── common/models/     ← ErrorWrapper, JWT payload interfaces
    ├── controllers/       ← Route handler business logic
    ├── database/          ← MongoDB connection + Mongoose models
    ├── middleware/         ← Auth, XSS, validation, error handling
    ├── routes/            ← v1, v2, v3 route definitions
    └── utils/             ← Response helpers, cache helpers, monitoring
environment/               ← Per-environment JSON config files
tools/                     ← Webpack build helpers, Docker boot scripts
```

---

## Documentation

Full documentation for AI agents, senior developers, and contributors is in [`docs/ai/`](../docs/ai/):

| Document | Purpose |
|---|---|
| [Repository Overview](../docs/ai/repo-overview.md) | Purpose, stack, structure, getting started |
| [System Architecture](../docs/ai/architecture.md) | Request flows, middleware order, DB design, caching |
| [Coding Standards](../docs/ai/coding-standards.md) | TypeScript rules, naming, error handling, logging patterns |
| [API & Error Handling](../docs/ai/api-error-handling.md) | All routes, parameters, error codes, response shapes |
| [Security Implementation](../docs/ai/security.md) | JWT flow, XSS protection, Helmet, input validation |
| [Build & Validation](../docs/ai/build-validation.md) | Install/build/run commands, CI/CD, Docker |
| [Agent Workflow](../docs/ai/agent-workflow.md) | Definition of done, how to add endpoints, debugging guide |
| [Contribution Checklist](../docs/ai/contribution-checklist.md) | Pre-merge checklist, doc update rules, ADR template |
| [ADR-001 — Versioned Routes, JWT Claims, Cache Strategy](../docs/ai/adr-versioned-routes-jwt-and-cache.md) | Architectural decision record |

For AI agent context, see [`AGENTS.md`](../AGENTS.md) at the repository root.
