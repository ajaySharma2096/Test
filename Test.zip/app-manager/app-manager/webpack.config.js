const path = require('path');
const TsconfigPathsPlugin = require('tsconfig-paths-webpack-plugin');

module.exports = {
  name: 'server',
  target: 'node',
  entry: {
    server: ['./src/server.ts'],
  },
  module: {
    rules: [
      {
        test: /\.js$/,
        exclude: /node_modules/,
        use: {
          loader: 'babel-loader',
          options: {
            presets: ['@babel/preset-env'],
          },
        },
      },
      {
        test: /\.ts?$/,
        use: 'ts-loader',
        exclude: /node_modules/,
      },
      {
        test: /\.node$/,
        use: 'node-loader',
      }
    ],
  },
  resolve: {
    modules: ['node_modules', '.'],
    extensions: ['.ts', '.js'],
    symlinks: false,
    plugins: [new TsconfigPathsPlugin()],
  },
  output: {
    path: path.resolve('./build'),
    filename: '[name].js',
    chunkFilename: 'chunks/[name].js',
    libraryTarget: 'commonjs2',
  },
};
