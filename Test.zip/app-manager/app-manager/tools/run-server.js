const exec = require('child_process').exec;
const fs = require('fs');
const path = require('path');

// Launch or restart the Node.js server
(function runServer() {
  const args = process.argv.slice(2).reduce((result, arg) => {
    const tmp = arg.split('=');
    result[tmp[0]] = tmp[1];
    return result;
  }, {});

  let configPath;

  if (args.config) {
    configPath = args.config;
  } else {
    throw new Error('Config Path not found');
  }

  let cmdLine;
  if (configPath === '../environment/dev-config.json') {
    const dotEnv = fs.readFileSync(path.resolve(__dirname, './test.env'))
                    .toString()
                    .split('\n')
                    .filter(x => x)
                    .join(' ')

    cmdLine = `${dotEnv} nodemon -- config=${configPath}`;
  } else {
    cmdLine =`pm2-runtime build/server.js -- config=${configPath}`;
  }

  const command = exec(cmdLine);

  command.stdout.on('data', (data) => {
    process.stderr.write(data);
  });
  command.stderr.on('data', (data) => {
    process.stderr.write(data);
  });
  command.on('error', (err) => {
    process.stderr.write(err);
  });
})();
