/* eslint no-var: 0 */
const { exec } = require('child_process');
const path = require('path');
const fs = require('fs');
const packageJson = require('./../../package.json');

const { scripts } = packageJson;

const COMMANDS = {
    DEV_BUILD: {
        SERVER: scripts['build:dev'],
    },
    PROD_BUILD: {
        SERVER: scripts['build'],
    },
    INSTALL: 'yarn install',
    RUN: {
        DEVELOPMENT: scripts['server:dev'],
        PRODUCTION: scripts['server:prod'],
    },
};

const argsObj = process.argv
    .filter((arg) => arg.startsWith('-'))
    .reduce((accumulator, arg) => {
        const tmp = arg.replace('-', '');
        accumulator[tmp] = true;
        return accumulator;
    }, {});

const backend = argsObj.b;

const PORT_ENV = 'PORT=4000';

const dotEnv = fs
    .readFileSync(path.resolve(__dirname, '../test.env'))
    .toString()
    .split('\n')
    .filter((x) => x)
    .filter((x) => !x.startsWith('#'))
    .join(' ');

// const buildUI = frontend
//     ? COMMANDS.DEV_BUILD.CLIENT
//     : COMMANDS.PROD_BUILD.CLIENT;

const buildBackend = backend
    ? COMMANDS.DEV_BUILD.SERVER
    : COMMANDS.PROD_BUILD.SERVER;

const buildTask = `${buildBackend}`;
const serverTask = `${dotEnv} ${PORT_ENV} ${
    backend ? COMMANDS.RUN.DEVELOPMENT : COMMANDS.RUN.PRODUCTION
}`;
function execute(cmd) {
    console.log("cmd: ", cmd);
    const child = exec(cmd);

    child.stdout.on('data', (data) => {
        process.stdout.write(data);
    });
    child.stderr.on('data', (data) => {
        process.stderr.write(data);
    });
    child.on('error', (err) => {
        process.stderr.write(err);
    });
    return child;
}

function runBuildAndServer() {
    execute(`${buildTask} && ${serverTask}`);
}

runBuildAndServer();
