/* eslint no-var: 0 */
const { exec } = require('child_process');

const dockerCommand = 'docker-compose up';
const killDockerCmd = 'docker rm -f $(docker ps -q -a)';

function exitHandler(error) {
    console.log('rolling back', error);
    exec(killDockerCmd);
    process.exit();
}

function startDocker() {
    const dockerProcess = exec(dockerCommand);

    dockerProcess.stdout.on('data', (data) => {
        process.stdout.write(data);
    });
    dockerProcess.stderr.on('data', (data) => {
        process.stderr.write(data);
    });
    dockerProcess.on('error', (err) => {
        process.stderr.write(err);
    });
    dockerProcess.on('exit', (args) => {
        console.log('dockerProcess: exit', ...args);
    });
    dockerProcess.on('SIGINT', (args) => {
        console.log('dockerProcess: SIGINT', ...args);
    });
    dockerProcess.on('uncaughtException', (args) => {
        console.log('dockerProcess: uncaughtException', ...args);
    });
    return dockerProcess;
}

function run() {
    startDocker();
    process.on('exit', (args) => {
        console.log('process: exit', ...args);
        exitHandler(args);
    });
    process.on('SIGINT', (args) => {
        console.log("args: ", args);
        console.log('process: SIGINT', ...args);
        exitHandler(args);
    });
    process.on('uncaughtException', (args) => {
        console.log('process: uncaughtException', ...args);
        exitHandler(args);
    });
}

run();
