import bodyParser from 'body-parser';
import express, { Application } from 'express';
import helmet from 'helmet';
import mongoose from '@app-manager/database/mongodb';
import { xssMiddleware } from '@app-manager/middleware/auth';
import { checkAllowedMethods, logRequest } from '@app-manager/middleware/common';
import { globalErrorHandler } from '@app-manager/middleware/error';
import { dependency } from '@app-manager/routes/dependency';
import { health } from '@app-manager/routes/health';
import { ping } from '@app-manager/routes/ping';
import appManager, { internalAppManagerRouter } from '@app-manager/routes/v1/index.routes';
import v2Router from '@app-manager/routes/v2/index.routes';
import v3Router from '@app-manager/routes/v3/index.routes';
import { accessLogMiddleware } from '@config/logger';

// @ts-ignore
const usedMongo = mongoose;
const app: Application = express();

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

app.use(accessLogMiddleware);

app.use(checkAllowedMethods);

app.use(xssMiddleware);

app.use(helmet());

app.use(
  helmet.contentSecurityPolicy({
    useDefaults: true,
  }),
  helmet.referrerPolicy({
    policy: "no-referrer",
  }),
  helmet.frameguard({
    action: "deny",
  })
);

app.get('/ping', ping);
app.get('/health', health);
app.get('/dependency', dependency);

app.use(
  '/internal',
  logRequest,
  internalAppManagerRouter
);

app.use(
  '/',
  logRequest,
  appManager
);

app.use(
  '/ext/v2',
  logRequest,
  v2Router
);

app.use(
  '/ext/v3',
  logRequest,
  v3Router
);

app.use(globalErrorHandler);

app.listen(4000, () => {
  console.log('Server is listening on Port: 4000');
});

export default app;