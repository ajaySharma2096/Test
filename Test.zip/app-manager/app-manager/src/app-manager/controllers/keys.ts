import { Request, Response, NextFunction } from 'express';
import logger from '@config/logger';
import { 
  SUCCESS_MESSAGE,
  KEYS_STATUS,
  GET_CONFIG_VALUES_CACHE_KEY,
  BOP_REFERRER,
  KEYS_DISPLAY_ATTRIBUTES,
  CONFIG_CREATE_SUCCESS_MESSAGE,
  CONFIG_DELETE_SUCCESS_MESSAGE,
  ERROR_STATUS,
  CONFIG_VALUE_OPERATIONS,
  CONFIG_UPDATE_SUCCESS_MESSAGE,
  ReqQuery,
  ConfigKeysResponse,
} from '@app-manager/constants';
import Keys from '@app-manager/database/models/keys.model';
import { appManagerCache } from '@app-manager/cache';
import { IRequestIAT } from '@app-manager/common/models/jwt-payload';
import { ErrorWrapper } from '@app-manager/common/models/error';
import { errorResponse, successResponse } from '@app-manager/utils';
import { checkExistingKeys, checkPresentKeys, checkPresentValues, getCacheKey, getConfigKeysFromCacheValue, getDataFromCache, getDataFromDB, setDataToCache, validateUpdatedAt } from '@app-manager/utils/keys';

/**
 * 
 * @param _req
 * @param _res
 * @param _next
 * 
 * It is the v1 API handler to serve all the config keys based on the available params
 * 
 */
export const fetchKeys = async (
  _req: Request,
  _res: Response,
  _next: NextFunction,
) => {
  const clientRequestId = _req.header('requestId') as string;
  const client: string = _req?.query?.client as string;
  try {
    const clientResponse = {
      status: "SUCCESS",
      message: SUCCESS_MESSAGE,
      response: {
        list: [] as any,
        total: 0
      }
    }

    let cacheKey = GET_CONFIG_VALUES_CACHE_KEY;
    let referrer;
    let limit, offset, search;
    if (_req?.query?.referrer) {
      referrer = _req?.query?.referrer as string;
      offset = _req?.query?.offset as string;
      limit = _req?.query?.limit as string;
      search = _req?.query?.search as string;
    }

    const client: string = _req?.query?.client as string;
    cacheKey += client;
    const cachedData = appManagerCache.get<{ list: Object[], total: number }>(cacheKey);
    if (_req?.query?.referrer || !cachedData?.list?.length) {
      const $project = referrer === BOP_REFERRER ? {} : KEYS_DISPLAY_ATTRIBUTES;
      const $match: Record<string, any> = { clientType: client.toLowerCase(), status: KEYS_STATUS.ACTIVE };

      if (search) {
        $match.key = { $regex: search, $options: 'i' };
      }

      const pipeline: any = [
        { $match },
        { $sort: { updatedAt: -1 } }
      ]

      if (Object.values($project)?.length) {
        pipeline.push({ $project });
      }

      if (offset) {
        pipeline.push({ $skip: parseInt(offset) })
      }

      if (limit) {
        pipeline.push({ $limit: parseInt(limit) })
      }

      logger.info({
        requestId: clientRequestId,
        message: "Fetching Data From DB"
      })

      const [list, total] = await Promise.all([
        Keys.aggregate(pipeline)
          .then(results => results?.map(key => new Keys(key).toJSON()))
          .catch(error => {
            logger.error({
              requestId: clientRequestId,
              error
            });
          }),
        Keys.countDocuments($match)
      ])

      clientResponse.response = {
        list,
        total,
      };

      if (!_req?.query?.referrer) {
        appManagerCache.set(cacheKey, clientResponse.response);
      }
    } else {
      clientResponse.response = cachedData;
    }

    return successResponse(clientResponse, _res, clientRequestId);
  } catch (error) {
    const err = new ErrorWrapper(
      error?.message || ERROR_STATUS.INTERNAL_ERROR.RESPONSE.MESSAGE,
      error?.status || ERROR_STATUS.INTERNAL_ERROR.HTTP_RESPONSE,
      error?.requestId || clientRequestId,
      error?.code || ERROR_STATUS.INTERNAL_ERROR.RESPONSE.ERROR_CODE,
      error?.uri || _req?.originalUrl,
      error?.method || _req?.method,
      error?.client || client,
    );

    return errorResponse(err, _res, clientRequestId, err?.code);
  }
};

/**
 * 
 * @param _req
 * @param _res
 * 
 * It is the API v2 handler to serve all the config keys based on the available params which supports for different namespace
 * 
 */
export const fetchKeysV2 = async (
  _req: Request,
  _res: Response,
) => {
  const clientRequestId = _req.header('requestId') as string;
  const { namespace, referrer, offset, limit, search } = _req?.query;
  try {
    const clientResponse = {
      status: "SUCCESS",
      message: SUCCESS_MESSAGE,
      response: {
        list: [] as any,
        total: 0
      }
    }

    // unique key to store the data in cache
    const cacheKey = GET_CONFIG_VALUES_CACHE_KEY + namespace;

    // fetch the value of particular namespace using its key
    const cachedData = appManagerCache.get<{ list: Object[], total: number }>(cacheKey);

    // if cache data is not present then fetch from the DB
    if (referrer || !cachedData?.list?.length) {
      const $project = referrer === BOP_REFERRER ? {} : KEYS_DISPLAY_ATTRIBUTES;
      const $match: Record<string, any> = { clientType: namespace, status: KEYS_STATUS.ACTIVE };

      if (referrer && search) {
        $match.key = { $regex: search, $options: 'i' };
      }

      const pipeline: any = [
        { $match },
        { $sort: { updatedAt: -1 } }
      ]

      if (Object.values($project)?.length) {
        pipeline.push({ $project });
      }

      if (referrer && offset) {
        pipeline.push({ $skip: parseInt(String(offset)) })
      }

      if (referrer && limit) {
        pipeline.push({ $limit: parseInt(String(limit)) })
      }

      logger.info({
        requestId: clientRequestId,
        message: "Fetching Data From DB"
      })

      const [list, total] = await Promise.all([
        Keys.aggregate(pipeline)
          .then(results => results?.map(key => new Keys(key).toJSON()))
          .catch(error => {
            logger.error({
              requestId: clientRequestId,
              error
            });
          }),
        Keys.countDocuments($match)
      ])

      clientResponse.response = {
        list,
        total,
      };

      if (!referrer) {
        appManagerCache.set(cacheKey, clientResponse.response);
      }
    } else {
      clientResponse.response = cachedData;
    }

    return successResponse(clientResponse, _res, clientRequestId);
  } catch (error) {
    const err = new ErrorWrapper(
      error?.message || ERROR_STATUS.INTERNAL_ERROR.RESPONSE.MESSAGE,
      error?.status || ERROR_STATUS.INTERNAL_ERROR.HTTP_RESPONSE,
      error?.requestId || clientRequestId,
      error?.code || ERROR_STATUS.INTERNAL_ERROR.RESPONSE.ERROR_CODE,
      error?.uri || _req?.originalUrl,
      error?.method || _req?.method,
      error?.client || namespace,
    );

    return errorResponse(err, _res, clientRequestId, err?.code);
  }
};

/**
 * 
 * @param _req
 * @param _res
 * 
 * It is the API v3 handler to serve all the config keys based on the available params which supports config delta
 * 
 */
export const fetchKeysV3 = async (
  _req: Request,
  _res: Response,
) => {
  const clientRequestId = _req.header('requestId') as string;
  const { namespace, referrer, offset, limit, search, lastUpdatedAt } = _req?.query as ReqQuery;
  try {
    const clientResponse = {
      status: "SUCCESS",
      message: SUCCESS_MESSAGE,
      response: {
        list: [] as any,
        deletedList: [] as any,
        lastUpdatedAt: Number(lastUpdatedAt || 0),
        // total in list
        total: 0
      } as ConfigKeysResponse
    }

    const cacheKey = getCacheKey(namespace, "V3");

    let cachedData = getDataFromCache(cacheKey);

    // referrer is BOP, and we don't look for cache in case of referrer
    if (referrer || !cachedData) {
      const [configKeysFromDB, totalActiveKeys] = await getDataFromDB(namespace, clientRequestId, referrer, search, offset, limit);
      
      let { list, deletedList, lastUpdatedAt } = configKeysFromDB;
      
      clientResponse.response = {
        list,
        deletedList,
        lastUpdatedAt,
        total: totalActiveKeys,
      };

      if (!referrer) {
        cachedData = setDataToCache(cacheKey, clientResponse.response);
      }
    }

    if (!referrer) {
      clientResponse.response = getConfigKeysFromCacheValue(clientResponse.response, lastUpdatedAt, cachedData);
    }

    return successResponse(clientResponse, _res, clientRequestId);
  } catch (error) {
    const err = new ErrorWrapper(
      error?.message || ERROR_STATUS.INTERNAL_ERROR.RESPONSE.MESSAGE,
      error?.status || ERROR_STATUS.INTERNAL_ERROR.HTTP_RESPONSE,
      error?.requestId || clientRequestId,
      error?.code || ERROR_STATUS.INTERNAL_ERROR.RESPONSE.ERROR_CODE,
      error?.uri || _req?.originalUrl,
      error?.method || _req?.method,
      error?.client || namespace,
    );

    return errorResponse(err, _res, clientRequestId, err?.code);
  }
};

/**
 * 
 * @param _req
 * @param _res
 * @param _next
 * 
 * It is the API handler to add/update the config keys
 * 
 */
export const addOrUpdateKeys = async (
  _req: IRequestIAT,
  _res: Response,
  _next: NextFunction,
) => {
  
  const clientRequestId = _req.header('requestId') as string;
  const namespace: string = _req.header('namespace') as string;
  try {
    const keys = _req?.body?.keys;
    const operation = _req?.body?.operation;
    if (keys?.length) {
      const onlyKeys = keys.map((key: any) => key?.key);

      const clientResponse = {
        status: "SUCCESS",
        message: CONFIG_CREATE_SUCCESS_MESSAGE,
        response: onlyKeys,
      }

      if (operation === CONFIG_VALUE_OPERATIONS.UPDATE) {
        // to check whether the requested key exists in the DB or not
        await checkPresentKeys(
          { key: { $in: onlyKeys }, status: KEYS_STATUS.ACTIVE, clientType: namespace },
          onlyKeys,
          clientRequestId,
        )

        // to check whether the requested key/values has some new value or not
        await checkPresentValues(keys, clientRequestId);

        clientResponse.message = CONFIG_UPDATE_SUCCESS_MESSAGE;
      } else if (operation === CONFIG_VALUE_OPERATIONS.ADD) {
        // to check whether the requested key exists in the DB or not
        await checkExistingKeys(
          { key: { $in: onlyKeys }, status: KEYS_STATUS.ACTIVE, clientType: namespace },
          clientRequestId,
        )
      }

      const iat = _req?.iat! * 1000;
      await validateUpdatedAt(onlyKeys, iat, namespace, clientRequestId);

      const updatedKeys = await Promise.allSettled(keys.map(async (item: any) => {
        // query to check whether requested key have some active value in the DB
        const query = { key: item.key, status: KEYS_STATUS.ACTIVE, clientType: item?.clientType };

        // if there is some active present then update it and set the value inactive
        const key = await Keys.findOneAndUpdate(query, { status: KEYS_STATUS.INACTIVE }, { new: true });

        if(key) {
          item.createdAt = new Date(key?.createdAt);
        } else {
          item.createdAt = new Date(iat);
        }

        item.updatedAt = new Date(iat);

        // add the new value in the DB
        return await Keys.findOneAndUpdate(query, {...item, status: KEYS_STATUS.ACTIVE}, { new: true, upsert: true });
      }));

      clientResponse.response = updatedKeys.map((key: any) => key.value);

      return successResponse(clientResponse, _res, clientRequestId);
    }
  } catch (error) {
    const err = new ErrorWrapper(
      error?.message || ERROR_STATUS.INTERNAL_ERROR.RESPONSE.MESSAGE,
      error?.status || ERROR_STATUS.INTERNAL_ERROR.HTTP_RESPONSE,
      error?.requestId || clientRequestId,
      error?.code || ERROR_STATUS.INTERNAL_ERROR.RESPONSE.ERROR_CODE,
      error?.uri || _req?.originalUrl,
      error?.method || _req?.method,
      error?.client || namespace,
    );

    return errorResponse(err, _res, clientRequestId, err?.code);
  }
};

/**
 * 
 * @param _req
 * @param _res
 * @param _next
 * 
 * It is the API handler to delete the config keys
 * 
 */
export const deleteKeys = async (
  _req: IRequestIAT,
  _res: Response,
  _next: NextFunction,
) => {
  
  const clientRequestId = _req.header('requestId') as string;
  const namespace: string = _req.header('namespace') as string;
  try {
    const keys = _req?.body?.keys;
    const updatedBy = _req?.body?.updatedBy;

    const clientResponse = {
      status: "SUCCESS",
      message: CONFIG_DELETE_SUCCESS_MESSAGE,
      response: [] as any,
    }

    const iat = _req?.iat! * 1000;

    const query = { key: { $in: keys }, status: KEYS_STATUS.ACTIVE, clientType: namespace };

    // to check whether the requested key exists in the DB or not
    await checkPresentKeys(
      query,
      keys,
      clientRequestId,
    )

    await validateUpdatedAt(keys, iat, namespace, clientRequestId);
    
    // update the status of the keys to inactive
    const result = await Keys.updateMany(
      query,
      { $set: { updatedBy, status: 'inactive', updatedAt: new Date(iat) } }
    );

    clientResponse.response = result;

    return successResponse(clientResponse, _res, clientRequestId);
  } catch (error) {
    const err = new ErrorWrapper(
      error?.message || ERROR_STATUS.INTERNAL_ERROR.RESPONSE.MESSAGE,
      error?.status || ERROR_STATUS.INTERNAL_ERROR.HTTP_RESPONSE,
      error?.requestId || clientRequestId,
      error?.code || ERROR_STATUS.INTERNAL_ERROR.RESPONSE.ERROR_CODE,
      error?.uri || _req?.originalUrl,
      error?.method || _req?.method,
      error?.client || namespace,
    );

    return errorResponse(err, _res, clientRequestId, err?.code);
  }
};
