import { Request, Response, NextFunction } from 'express';
import { 
  CLIENT,
  CLIENT_FETCH_SUCCESS_MESSAGE,
  ERROR_STATUS
} from '@app-manager/constants';
import { ErrorWrapper } from '@app-manager/common/models/error';
import { errorResponse, successResponse } from '@app-manager/utils';

/**
 * 
 * @param _req
 * @param _res
 * @param _next
 * 
 * It is the API handler to return the list of all client/namespace
 * 
 */

export const fetchClient = async (
  _req: Request,
  _res: Response,
  _next: NextFunction,
) => {
  const clientRequestId = _req.header('requestId') as string;
  try {
    const clientResponse = {
      status: "SUCCESS",
      message: CLIENT_FETCH_SUCCESS_MESSAGE,
      response: Object.values(CLIENT),
    }

    return successResponse(clientResponse, _res, clientRequestId);
  } catch (error) {
    const err = new ErrorWrapper(
      error?.message || ERROR_STATUS.INTERNAL_ERROR.RESPONSE.MESSAGE,
      error?.status || ERROR_STATUS.INTERNAL_ERROR.HTTP_RESPONSE,
      error?.requestId || clientRequestId,
      error?.code || ERROR_STATUS.INTERNAL_ERROR.RESPONSE.ERROR_CODE,
      error?.uri || _req?.originalUrl,
      error?.method || _req?.method,
    );

    return errorResponse(err, _res, clientRequestId, err?.code);
  }
};
