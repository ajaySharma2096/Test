import mongoose from 'mongoose';
import { connectToMongoDB } from '@app-manager/database/mongodb';
import logger from '@config/logger';

export const mongoService = async () => {
  let data = {};
  let dbMode = 'Unknown';
  let databaseVersion = '';
  const startTime = Date.now();

  try {
    // Ensure mongoose is connected
    if (mongoose?.connection?.readyState !== 1) {
      await connectToMongoDB();
    }

    // Get database version
    const admin = mongoose?.connection?.db?.admin();
    
    const buildInfo = await admin.command({ buildInfo: 1 });
    databaseVersion = buildInfo.version;

    // MongoDB doesn't have a direct read-only flag like MySQL,
    // but we can infer it from the current user's roles
    const currentUser = await admin?.command({ connectionStatus: 1 });
    const roles = currentUser?.authInfo?.authenticatedUserRoles || [];

    const isReadOnly = roles?.some((role: { role: string; }) =>
      role?.role?.toLowerCase()?.includes('read')
    ) && !roles.some((role: { role: string; }) =>
      role?.role?.toLowerCase()?.includes('write')
    );

    dbMode = isReadOnly ? 'Read Only' : 'Read/Write';

    const duration = Date.now() - startTime;
    data = {
      program: 'app-manager',
      status: 'success',
      code: 200,
      message: 'service is healthy',
      duration,
      dbMode,
      serviceName: 'MongoDB',
      databaseVersion,
    };
  } catch (err) {

    logger.error({
      errMessage: "Dependency MongoDB Error!!!",
      error: err,
    });

    const duration = Date.now() - startTime;
    data = {
      program: 'app-manager',
      status: 'failure',
      code: 503,
      message: 'service is not working',
      duration,
      serviceName: 'MongoDB',
      dbMode,
      databaseVersion,
    };
  }

  return data;
};
