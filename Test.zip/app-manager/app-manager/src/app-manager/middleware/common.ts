import express from 'express';
import { ErrorWrapper } from '@app-manager/common/models/error';
import logger from '@config/logger';
import { ERROR_STATUS } from '@app-manager/constants';

/**
 * 
 * @param _req
 * @param _res
 * @param next
 * 
 * It is a common validator used to check if the method of the request is allowed by service or not
 * 
 */
export const checkAllowedMethods = (
    _req: express.Request,
    _res: express.Response,
    next: express.NextFunction,
  ) => {
    const clientRequestId = _req.header('requestId')
    const whiteListedMethods = new Set(['GET', 'POST']);
    const client: string = _req?.query?.client as string;
    if (whiteListedMethods.has(_req.method?.toUpperCase())) {
      return next();
    }
    const err = new ErrorWrapper(
      ERROR_STATUS.METHOD_NOT_ALLOWED.RESPONSE.MESSAGE,
      ERROR_STATUS.METHOD_NOT_ALLOWED.HTTP_RESPONSE,
      clientRequestId,
      ERROR_STATUS.METHOD_NOT_ALLOWED.RESPONSE.ERROR_CODE,
      _req?.originalUrl,
      _req?.method,
      client,
    );
    logger.error({
      requestId: clientRequestId,
      error: err
  });
    return next(err);
  };

/**
 * 
 * @param _req
 * @param _res
 * @param next
 * 
 * It is used to log the incoming request
 * 
 */
export const logRequest = (
  _req: express.Request,
  _res: express.Response,
  next: express.NextFunction
  ) => {
    const clientRequestId = _req.header('requestId')
    logger.info({
        requestId: clientRequestId,
        req: _req,
    });
    return next();
  };