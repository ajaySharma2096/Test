import express from 'express';
import { validate as isValidUUID } from 'uuid';
import { ErrorWrapper } from '@app-manager/common/models/error';
import logger from '@config/logger';
import { 
    CLIENT,
    CONFIG_VALUE_OPERATIONS,
    ERROR_STATUS,
    METRIX,
    BOP_REFERRER,
  } from '@app-manager/constants';
import {appMonitoringMatrixIncrement} from '@app-manager/utils/app-monitoring';
import { getConfigClientIds, isValidConfigKey, notNullUndefinedOrEmpty } from '@app-manager/utils';

/**
 * 
 * @param _req
 * @param _res
 * @param _next
 * 
 * It is used to validate the request for get config keys API
 * 
 */
export const validateKeysRequest = (
    _req: express.Request,
    _res: express.Response,
    _next: express.NextFunction
) => {
    appMonitoringMatrixIncrement(METRIX.API_TOTAL, 1);

    const client: string = _req?.query?.client as string;
    const clientRequestId = _req.header('requestId') as string;

    try {
        verifyReferrer(_req, clientRequestId);

        const err = isValidClient(client, clientRequestId, _req);
        if (err) {
            return _next(err);
        }

        return _next();
    } catch (error) {
        const err = new ErrorWrapper(
            error?.message || ERROR_STATUS.INTERNAL_ERROR.RESPONSE.MESSAGE,
            error?.status || ERROR_STATUS.INTERNAL_ERROR.HTTP_RESPONSE,
            error?.requestId || clientRequestId,
            error?.code || ERROR_STATUS.INTERNAL_ERROR.RESPONSE.ERROR_CODE,
            error?.uri || _req?.originalUrl,
            error?.method || _req?.method,
            error?.client || client,
        )

        return _next(err);
    }

};

/**
 * 
 * @param _req
 * @param _res
 * @param _next
 * 
 * It is used to validate the v2 request for get config keys API
 * 
 */
export const validateKeysRequestV2 = (
    _req: express.Request,
    _res: express.Response,
    _next: express.NextFunction
) => {
    appMonitoringMatrixIncrement(METRIX.API_TOTAL, 1);

    const namespace: string = _req?.query?.namespace as string;
    const clientRequestId = _req.header('requestId') as string;
    try {
        verifyReferrer(_req, clientRequestId);

        const err = isValidNamespace(namespace, clientRequestId, _req);
        if (err) {
            return _next(err);
        }

        return _next();
    } catch (error) {
        const err = new ErrorWrapper(
            error?.message || ERROR_STATUS.INTERNAL_ERROR.RESPONSE.MESSAGE,
            error?.status || ERROR_STATUS.INTERNAL_ERROR.HTTP_RESPONSE,
            error?.requestId || clientRequestId,
            error?.code || ERROR_STATUS.INTERNAL_ERROR.RESPONSE.ERROR_CODE,
            error?.uri || _req?.originalUrl,
            error?.method || _req?.method,
            error?.client || namespace,
        )

        return _next(err);
    }
};

/**
 * 
 * @param _req
 * @param _res
 * @param _next
 * 
 * It is used to validate the v3 request for get config keys API
 * 
 */
export const validateKeysRequestV3 = (
    _req: express.Request,
    _res: express.Response,
    _next: express.NextFunction
) => {
    appMonitoringMatrixIncrement(METRIX.API_TOTAL, 1);

    const namespace: string = _req?.query?.namespace as string;
    const clientRequestId = _req.header('requestId') as string;
    try {
        verifyReferrer(_req, clientRequestId);

        verifyLastUpdatedAt(_req, clientRequestId);

        const err = isValidNamespace(namespace, clientRequestId, _req);
        if (err) {
            return _next(err);
        }

        return _next();
    } catch (error) {
        const err = new ErrorWrapper(
            error?.message || ERROR_STATUS.INTERNAL_ERROR.RESPONSE.MESSAGE,
            error?.status || ERROR_STATUS.INTERNAL_ERROR.HTTP_RESPONSE,
            error?.requestId || clientRequestId,
            error?.code || ERROR_STATUS.INTERNAL_ERROR.RESPONSE.ERROR_CODE,
            error?.uri || _req?.originalUrl,
            error?.method || _req?.method,
            error?.client || namespace,
        )

        return _next(err);
    }
};

/**
 * 
 * @param _req
 * @param _res
 * @param _next
 * 
 * It is used to validate the request for add/update config keys API
 * 
 */
export const validateAddOrUpdateKeys = (
    _req: express.Request,
    _res: express.Response,
    _next: express.NextFunction
) => {
    appMonitoringMatrixIncrement(METRIX.API_TOTAL, 1);

    const clientRequestId = _req.header('requestId') as string;
    const namespace: string = _req.header('namespace') as string;

    const err = isValidNamespace(namespace, clientRequestId, _req);
    if (err) {
        return _next(err);
    }

	const keys = _req?.body?.keys;

	const operation = _req?.body?.operation;

    const key = keys?.find((item: any) => !isValidConfigKey(item, namespace))

    if ( !Array.isArray(keys) || !keys?.length || key || !operation|| !Object.values(CONFIG_VALUE_OPERATIONS).includes(operation) ) {
        const err = new ErrorWrapper(
            ERROR_STATUS.INVALID_BODY_PARAMS.RESPONSE.MESSAGE,
            ERROR_STATUS.INVALID_BODY_PARAMS.HTTP_RESPONSE,
            clientRequestId,
            ERROR_STATUS.INVALID_BODY_PARAMS.RESPONSE.ERROR_CODE,
            _req?.originalUrl,
            _req?.method,
            namespace,
        );

        logger.error({
            requestId: clientRequestId,
            error: err
        });

        return _next(err);
    }
    return _next();
};

/**
 * 
 * @param _req
 * @param _res
 * @param _next
 * 
 * It is used to validate the request for delete config keys API
 * 
 */
export const validateDeleteKeys = (
    _req: express.Request,
    _res: express.Response,
    _next: express.NextFunction
) => {
    appMonitoringMatrixIncrement(METRIX.API_TOTAL, 1);

    const clientRequestId = _req.header('requestId') as string;
    const namespace: string = _req.header('namespace') as string;

    const err = isValidNamespace(namespace, clientRequestId, _req);
    if (err) {
        return _next(err);
    }

	const keys = _req?.body?.keys;
    const updatedBy = _req?.body?.updatedBy;

    if ( !Array.isArray(keys) || !keys?.length || !notNullUndefinedOrEmpty(updatedBy) ) {
        const err = new ErrorWrapper(
            ERROR_STATUS.INVALID_BODY_PARAMS.RESPONSE.MESSAGE,
            ERROR_STATUS.INVALID_BODY_PARAMS.HTTP_RESPONSE,
            clientRequestId,
            ERROR_STATUS.INVALID_BODY_PARAMS.RESPONSE.ERROR_CODE,
            _req?.originalUrl,
            _req?.method,
            namespace,
        );

        logger.error({
            requestId: clientRequestId,
            error: err
        });

        return _next(err);
    }

    return _next();
};

/**
 * 
 * @param _req
 * @param _res
 * @param _next
 * 
 * It is used to validate the request for get clients API
 * 
 */
export const validateGetClientRequest = (
    _req: express.Request,
    _res: express.Response,
    _next: express.NextFunction
) => {
    appMonitoringMatrixIncrement(METRIX.API_TOTAL, 1);

    const clientRequestId = _req.header('requestId') as string;

    if ( Object.keys(_req?.query)?.length != 1 || _req?.query?.referrer !== BOP_REFERRER ) {
        const err = new ErrorWrapper(
            ERROR_STATUS.INVALID_QUERY_PARAMS.RESPONSE.MESSAGE,
            ERROR_STATUS.INVALID_QUERY_PARAMS.HTTP_RESPONSE,
            clientRequestId,
            ERROR_STATUS.INVALID_QUERY_PARAMS.RESPONSE.ERROR_CODE
        );

        logger.error({
            requestId: clientRequestId,
            error: err
        });

        return _next(err);
    }

    return _next();
};


/**
 * 
 * @param client
 * @param clientRequestId
 * @param _req
 * 
 * It is used to validate the allowed clients
 * 
 */
const isValidClient = (client: string, clientRequestId: string, _req: express.Request) => {
    if (!(
        client?.toLowerCase() === CLIENT.ANDROIDAPP.ID ||
        client?.toLowerCase() === CLIENT.IOSAPP.ID) ||
        !isValidUUID(clientRequestId)
    ) {
        const err = new ErrorWrapper(
            ERROR_STATUS.INVALID_QUERY_PARAMS.RESPONSE.MESSAGE,
            ERROR_STATUS.INVALID_QUERY_PARAMS.HTTP_RESPONSE,
            clientRequestId,
            ERROR_STATUS.INVALID_QUERY_PARAMS.RESPONSE.ERROR_CODE,
            _req?.originalUrl,
            _req?.method,
            client,
        );

        logger.error({
            requestId: clientRequestId,
            error: err
        });

        return err;
    }
}

/**
 * 
 * @param namespace
 * @param clientRequestId
 * @param _req
 * 
 * It is used to validate the allowed namespaces
 * 
 */
const isValidNamespace = (namespace: string, clientRequestId: string, _req: express.Request) => {
    if (
        !getConfigClientIds().includes(namespace) ||
        !isValidUUID(clientRequestId)
    ) {
        const err = new ErrorWrapper(
            ERROR_STATUS.INVALID_QUERY_PARAMS.RESPONSE.MESSAGE,
            ERROR_STATUS.INVALID_QUERY_PARAMS.HTTP_RESPONSE,
            clientRequestId,
            ERROR_STATUS.INVALID_QUERY_PARAMS.RESPONSE.ERROR_CODE,
            _req?.originalUrl,
            _req?.method,
            namespace,
        );

        logger.error({
            requestId: clientRequestId,
            error: err
        });

        return err;
    }
}

/**
 * 
 * @param _req
 * @param clientRequestId
 * 
 * It is used to verify the referrer present in query params
 * 
 */
const verifyReferrer = (_req: express.Request, clientRequestId: string) => {

    if (
        _req?.query?.referrer
        && (
            _req?.query?.referrer !== BOP_REFERRER
            || !_req?.query?.offset
            || !_req?.query?.limit
        )
    ) {
        const err = new ErrorWrapper(
            ERROR_STATUS.INVALID_QUERY_PARAMS.RESPONSE.MESSAGE,
            ERROR_STATUS.INVALID_QUERY_PARAMS.HTTP_RESPONSE,
            clientRequestId,
            ERROR_STATUS.INVALID_QUERY_PARAMS.RESPONSE.ERROR_CODE,
        );

        throw err;
    }

}

/**
 * 
 * @param _req
 * @param clientRequestId
 * 
 * It is used to verify the lastUpdatedAt present in query params
 * 
 */
const verifyLastUpdatedAt = (_req: express.Request, clientRequestId: string) => {

    if (_req?.query?.lastUpdatedAt) {
        const lastUpdatedAt: number = parseInt(_req?.query?.lastUpdatedAt as string);
        
        if (typeof lastUpdatedAt !== 'number') {
            const err = new ErrorWrapper(
                ERROR_STATUS.INVALID_QUERY_PARAMS.RESPONSE.MESSAGE,
                ERROR_STATUS.INVALID_QUERY_PARAMS.HTTP_RESPONSE,
                clientRequestId,
                ERROR_STATUS.INVALID_QUERY_PARAMS.RESPONSE.ERROR_CODE,
            );
    
            throw err;
        }
    }

}
