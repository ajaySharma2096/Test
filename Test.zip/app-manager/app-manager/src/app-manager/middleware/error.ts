import express from 'express';
import logger from '@config/logger';
import { ErrorWrapper } from '@app-manager/common/models/error';
import {
  ERROR_STATUS} from '@app-manager/constants';
import { errorResponse } from '@app-manager/utils';

/**
 * 
 * @param err
 * @param _req
 * @param _res
 * @param _next
 * 
 * It is the global error handler where all the unhandled exceptions will be covered
 * 
 */
export const globalErrorHandler = async (
  err: ErrorWrapper,
  _req: express.Request,
  _res: express.Response,
  _next: express.NextFunction) => {
    let globalError = {};
    const clientRequestId = _req.header('requestId') as string;
    const client: string = _req?.query?.client as string;

    const error = new ErrorWrapper(
      err?.message || ERROR_STATUS.INTERNAL_ERROR.RESPONSE.MESSAGE,
      err?.status || ERROR_STATUS.INTERNAL_ERROR.HTTP_RESPONSE,
      err?.requestId || clientRequestId,
      err?.code || ERROR_STATUS.INTERNAL_ERROR.RESPONSE.ERROR_CODE,
      err?.uri || _req?.originalUrl,
      err?.method || _req?.method,
      err?.client || client,
    )

    globalError = { message: 'GLOBAL_ERROR', err, _req };
    logger.info({
      requestId: clientRequestId,
      error: globalError
    });

    return errorResponse(error, _res, clientRequestId, 'GLOBAL_ERROR');
  };

/**
 * 
 * @param _err
 * @param _req
 * @param _res
 * @param next
 * 
 * It is the 404(not found) handler
 * 
 */
  export const notFoundHandler = (
    _err: Error,
    _req: express.Request,
    _res: express.Response,
    next: express.NextFunction,
  ) => {
    const clientRequestId = _req.header('requestId');
    const client: string = _req?.query?.client as string;

    const err = new ErrorWrapper(
      ERROR_STATUS.NOT_FOUND.RESPONSE.MESSAGE,
      ERROR_STATUS.NOT_FOUND.HTTP_RESPONSE,
      clientRequestId,
      ERROR_STATUS.NOT_FOUND.RESPONSE.ERROR_CODE,
      _req?.originalUrl,
      _req?.method,
      client,
    );
    logger.error({ error: err, url: _req.path, requestId: clientRequestId });
    return next(err);
  };