import jwt from 'jsonwebtoken';
import express from 'express';
import { validate as isValidUUID } from 'uuid';
import logger from '@config/logger';
import { ErrorWrapper } from '@app-manager/common/models/error';
import { IRequestIAT, JwtTokenPayload, JwtTokenPayloadV2 } from '@app-manager/common/models/jwt-payload';
import { getConfigurationValue } from '@config/index';
import {
  JWT,
  ERROR_STATUS,
  CLIENT,
  JWT_TOKEN_EXPIRY
} from '../constants';
import { errorResponse } from '@app-manager/utils';

/**
 * 
 * @param requestId
 * @param errorCode
 * @param uri
 * @param method
 * @param client
 * 
 * It is used to throw error based on given parameters
 * 
 */
const throwError = (
    requestId: string,
    errorCode: number | string = '',
    uri: string = '',
    method: string = '',
    client: string = '',
) => {

  // to handle the client check on get client call
  if (uri === '/internal/v1/api/app-manager/client?referrer=BOP' && errorCode === ERROR_STATUS.ACCESS_DENIED.RESPONSE.ERROR_CODE.INVALID_CLIENT) {
    return;
  }

  const err = new ErrorWrapper(
    ERROR_STATUS.ACCESS_DENIED.RESPONSE.MESSAGE,
    ERROR_STATUS.ACCESS_DENIED.HTTP_RESPONSE,
    requestId,
    errorCode,
    uri,
    method,
    client
  );
  throw err;
};

/**
 * 
 * @param _req
 * @param _res
 * @param next
 * 
 * It verifies the JWT token for authentication
 * 
 */
export const verifyToken = (
    _req: IRequestIAT,
    _res: express.Response,
    next: express.NextFunction
    ) => {

      const token = _req.header('Authorization');
      const clientRequestId = _req.header('requestId') as string;
      const queryParamsClient: string = (_req?.query?.client || _req.header('client')) as string;

      try {
        if (!token) {
          const err = new ErrorWrapper(
            ERROR_STATUS.ACCESS_DENIED.RESPONSE.MESSAGE,
            ERROR_STATUS.ACCESS_DENIED.HTTP_RESPONSE,
            clientRequestId,
            ERROR_STATUS.ACCESS_DENIED.RESPONSE.ERROR_CODE.MISSING_TOKEN,
            _req?.originalUrl,
            _req?.method,
            queryParamsClient,
          );
          logger.error({
            requestId: clientRequestId,
            error: err
          });
          throw err;
        }
   
        const decodedToken = jwt.verify(token, getConfigurationValue(JWT.SECRET_KEY_CONFIG_PATH)) as JwtTokenPayload;
        const { 
          client,
          iss, 
          iat, 
          requestId 
        } = decodedToken;

        const currentTime = Math.floor(Date.now() / 1000);
        if (Math.abs(currentTime - iat) > JWT_TOKEN_EXPIRY) {
          throwError(
            clientRequestId || requestId,
            ERROR_STATUS.ACCESS_DENIED.RESPONSE.ERROR_CODE.IAT_EXPIRED,
            _req?.originalUrl,
            _req?.method,
            queryParamsClient,
          );
        } else if (iss.toLowerCase() !== JWT.ISSUER.toLowerCase()) {
          throwError(
            clientRequestId || requestId,
            ERROR_STATUS.ACCESS_DENIED.RESPONSE.ERROR_CODE.INVALID_ISS,
            _req?.originalUrl,
            _req?.method,
            queryParamsClient,
          );
        } else if ( !isValidUUID(requestId) || requestId !== clientRequestId) {
          throwError(
            clientRequestId || requestId,
            ERROR_STATUS.ACCESS_DENIED.RESPONSE.ERROR_CODE.INVALID_REQUEST_ID,
            _req?.originalUrl,
            _req?.method,
            queryParamsClient,
          );
        } else if ( !isValidUUID(requestId) ||
          requestId !== clientRequestId) {
            throwError(
              clientRequestId || requestId,
              ERROR_STATUS.ACCESS_DENIED.RESPONSE.ERROR_CODE.INVALID_REQUEST_ID,
            );
        } else if (client?.toLowerCase() !== queryParamsClient?.toLowerCase()) {
          throwError(
            clientRequestId || requestId,
            ERROR_STATUS.ACCESS_DENIED.RESPONSE.ERROR_CODE.INVALID_CLIENT,
            _req?.originalUrl,
            _req?.method,
            queryParamsClient,
          );
        }

        _req.iat = iat;
        next();
     } catch (error) {
      const err = new ErrorWrapper(
        error.message || ERROR_STATUS.ACCESS_DENIED.RESPONSE.MESSAGE,
        error.status || ERROR_STATUS.ACCESS_DENIED.HTTP_RESPONSE,
        error?.requestId || clientRequestId,
        error.code || ERROR_STATUS.ACCESS_DENIED.RESPONSE.ERROR_CODE.INVALID_SIGNATURE,
        error?.uri || _req?.originalUrl,
        error?.method || _req?.method,
        error?.client || queryParamsClient,
      );

      return errorResponse(err, _res, clientRequestId, err?.code);
     }
  };

/**
 * 
 * @param _req
 * @param _res
 * @param next
 * 
 * It verifies the v2 JWT token for authentication
 * 
 */
export const verifyTokenV2 = (
    _req: IRequestIAT,
    _res: express.Response,
    next: express.NextFunction
) => {
    const token = _req.header('Authorization');
    const clientRequestId = _req.header('requestId') as string;
    let namespaceParam;

    try {
      namespaceParam = (_req?.query?.namespace || getNamespaceFromHeaders(_req?.rawHeaders, clientRequestId)) as string;
      
      if (!token) {
        const err = new ErrorWrapper(
          ERROR_STATUS.ACCESS_DENIED.RESPONSE.MESSAGE,
          ERROR_STATUS.ACCESS_DENIED.HTTP_RESPONSE,
          clientRequestId,
          ERROR_STATUS.ACCESS_DENIED.RESPONSE.ERROR_CODE.MISSING_TOKEN,
          _req?.originalUrl,
          _req?.method,
          namespaceParam,
        );
        logger.error({
          requestId: clientRequestId,
          error: err
        });
        throw err;
      }
      const decodedToken = jwt.verify(token, getConfigurationValue(getJwtKeyConfigPath(namespaceParam))) as JwtTokenPayloadV2;
      const { 
        namespace,
        iss, 
        iat, 
        requestId 
      } = decodedToken;

      const currentTime = Math.floor(Date.now() / 1000);
      if (Math.abs(currentTime - iat) > JWT_TOKEN_EXPIRY) {
        throwError(
          clientRequestId || requestId,
          ERROR_STATUS.ACCESS_DENIED.RESPONSE.ERROR_CODE.IAT_EXPIRED,
          _req?.originalUrl,
          _req?.method,
          namespaceParam,
        );
      } else if (iss.toLowerCase() !== JWT.ISSUER.toLowerCase()) {
        throwError(
          clientRequestId || requestId,
          ERROR_STATUS.ACCESS_DENIED.RESPONSE.ERROR_CODE.INVALID_ISS,
          _req?.originalUrl,
          _req?.method,
          namespaceParam,
        );
      } else if (namespace !== namespaceParam) {
        throwError(
          clientRequestId || requestId,
          ERROR_STATUS.ACCESS_DENIED.RESPONSE.ERROR_CODE.INVALID_NAMESPACE,
          _req?.originalUrl,
          _req?.method,
          namespaceParam,
        );
      } else if ( !isValidUUID(requestId) || requestId !== clientRequestId) {
        throwError(
          clientRequestId || requestId,
          ERROR_STATUS.ACCESS_DENIED.RESPONSE.ERROR_CODE.INVALID_REQUEST_ID,
          _req?.originalUrl,
          _req?.method,
          namespaceParam,
        );
      } else if ( !isValidUUID(requestId) ||
        requestId !== clientRequestId) {
          throwError(
            clientRequestId || requestId,
            ERROR_STATUS.ACCESS_DENIED.RESPONSE.ERROR_CODE.INVALID_REQUEST_ID,
          );
      } else {
        _req.iat = iat;
        next();
      }
    } catch (error) {
      const err = new ErrorWrapper(
        error.message || ERROR_STATUS.ACCESS_DENIED.RESPONSE.MESSAGE,
        error.status || ERROR_STATUS.ACCESS_DENIED.HTTP_RESPONSE,
        error?.requestId || clientRequestId,
        error.code || ERROR_STATUS.ACCESS_DENIED.RESPONSE.ERROR_CODE.INVALID_SIGNATURE,
        error?.uri || _req?.originalUrl,
        error?.method || _req?.method,
        error?.client || namespaceParam,
      );

      return errorResponse(err, _res, clientRequestId, err?.code);
    }
};

/**
 * 
 * @param headers
 * @param requestId
 * 
 * It is used to extract namespace from request headers
 * 
 */
const getNamespaceFromHeaders = (headers: string[], requestId: string) => {
  const index = headers.indexOf('namespace');
  if (index > -1) {
    return headers[index + 1];
  }

  throwError(requestId, ERROR_STATUS.INVALID_QUERY_PARAMS.RESPONSE.ERROR_CODE);
}

/**
 * 
 * @param namespace
 * 
 * It is usd to get the JWT Key Path based on the namespace/client
 * 
 */
const getJwtKeyConfigPath = (namespace: string) => {
  switch (namespace) {
    case CLIENT.ANDROIDAPP.ID:
    case CLIENT.IOSAPP.ID:
      return JWT.SECRET_KEY_CONFIG_PATH;

    case CLIENT.PPBLAPPCLIENTANDROID.ID:
    case CLIENT.PPBLAPPCLIENTIOS.ID:
      return JWT.PPBL_SECRET_KEY_CONFIG_PATH;

    default:
      return JWT.SECRET_KEY_CONFIG_PATH;
  }
}