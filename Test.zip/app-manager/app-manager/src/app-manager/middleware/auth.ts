import { Request, Response, NextFunction } from 'express';
import { ErrorWrapper } from '@app-manager/common/models/error';
import logger from '@config/logger';
import { ERROR_STATUS } from '@app-manager/constants';

const xss = require('xss');

export const xssMiddleware = (
    _req: Request,
    _res: Response,
    _next: NextFunction,
  ) => {

    const clientRequestId = _req?.header('requestId') as string;
    try {
      if (_req?.originalUrl && _req?.originalUrl?.length !== xss(_req?.originalUrl)?.length) {
        throw new ErrorWrapper(
            `XSS: ${ERROR_STATUS.ACCESS_DENIED.RESPONSE.MESSAGE} due to reqOriginalUrl`,
            ERROR_STATUS.ACCESS_DENIED.HTTP_RESPONSE,
            clientRequestId,
            ERROR_STATUS.ACCESS_DENIED.RESPONSE.ERROR_CODE.XSS
        );
      }
      const params = JSON.stringify(_req?.params);
      if (params && params?.length !== xss(params)?.length) {
        throw new ErrorWrapper(
            `XSS: ${ERROR_STATUS.ACCESS_DENIED.RESPONSE.MESSAGE} due to params`,
            ERROR_STATUS.ACCESS_DENIED.HTTP_RESPONSE,
            clientRequestId,
            ERROR_STATUS.ACCESS_DENIED.RESPONSE.ERROR_CODE.XSS
        );
      }
  
      const query = JSON.stringify(_req?.query);
  
      if (query && query?.length !== xss(query)?.length) {
        throw new ErrorWrapper(
            `XSS: ${ERROR_STATUS.ACCESS_DENIED.RESPONSE.MESSAGE} due to query`,
            ERROR_STATUS.ACCESS_DENIED.HTTP_RESPONSE,
            clientRequestId,
            ERROR_STATUS.ACCESS_DENIED.RESPONSE.ERROR_CODE.XSS
        );
      }
  
      const cookies = JSON.stringify(_req?.cookies);
      if (cookies && cookies?.length !== xss(cookies)?.length) {
        throw new ErrorWrapper(
            `XSS: ${ERROR_STATUS.ACCESS_DENIED.RESPONSE.MESSAGE} due to cookies`,
            ERROR_STATUS.ACCESS_DENIED.HTTP_RESPONSE,
            clientRequestId,
            ERROR_STATUS.ACCESS_DENIED.RESPONSE.ERROR_CODE.XSS
        );
      }

      const body = JSON.stringify(_req?.body);
  
      if (body && body?.length !== xss(body)?.length) {
        throw new ErrorWrapper(
            `XSS: ${ERROR_STATUS.ACCESS_DENIED.RESPONSE.MESSAGE} due to body`,
            ERROR_STATUS.ACCESS_DENIED.HTTP_RESPONSE,
            clientRequestId,
            ERROR_STATUS.ACCESS_DENIED.RESPONSE.ERROR_CODE.XSS
        );
      }
  
      _next();
    } catch (error) {
        logger.error({
            requestId: clientRequestId,
            error: error,
          });
        return _next(error);
    }
  }