import mongoose from 'mongoose';
import { DATE_FORMAT, KEYS_STATUS } from '@app-manager/constants';
import moment from 'moment';
import { getConfigClientIds } from '@app-manager/utils';

interface IKeys extends mongoose.Document {
    id: string | mongoose.Types.ObjectId;
    key: string;
    value: string;
    clientType: string;
    status: string;
    updatedBy: string;
    createdAt: string;
    updatedAt: string;
}

const keysSchema = new mongoose.Schema({
    key: {
        type: String,
        required: true,
    },
    value: {
        type: String,
        required: true
    },
    clientType: {
        type: String,
        enum: getConfigClientIds(),
        required: true
    },
    status: {
        type: String,
        enum: Object.values(KEYS_STATUS),
        required: true
    },
    updatedBy: {
        type: String,
        required: true
    },
    createdAt: {
        type: Date,
        default: () => null,
    },
    updatedAt: {
        type: Date,
        default: () => null,
    },
},
{
    toJSON: {
      transform: (_doc, data) => {
        data.id = data._id;
        data.createdAt = data.createdAt ? moment(data.createdAt).format(DATE_FORMAT) : undefined;
        data.updatedAt = data.updatedAt ? moment(data.updatedAt).format(DATE_FORMAT) : undefined;
        data.namespace = data.clientType;
        delete data._id;
        delete data.clientType;
        delete data.__v;
        return data;
      }
    },
    toObject: {
      transform: (_doc, data) => {
        data.id = data._id;
        data.createdAt = data.createdAt ? moment(data.createdAt).format(DATE_FORMAT) : undefined;
        data.updatedAt = data.updatedAt ? moment(data.updatedAt).format(DATE_FORMAT) : undefined;
        data.namespace = data.clientType;
        delete data._id;
        delete data.clientType;
        delete data.__v;
        return data;
      }
    }
});

const Keys = mongoose.model<IKeys>('config_values', keysSchema);

export default Keys;
