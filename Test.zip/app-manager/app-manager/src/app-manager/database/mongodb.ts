import mongoose from 'mongoose';
import { DATABASE } from "@app-manager/constants";
import { getConfigurationValue } from "@config/index";
import logger from "@config/logger";


mongoose.Promise = global.Promise;

const connectToMongoDB = async () => {
    const options = {
        useUnifiedTopology: true,
        useNewUrlParser: true,
        useFindAndModify: false,
        connectTimeoutMS: 10000,
    };
    
    const MONGO_USERNAME = getConfigurationValue('database.username');
    const MONGO_PASSWORD = getConfigurationValue('database.password');
    const MONGO_HOSTNAME1 = getConfigurationValue('database.host1');
    const MONGO_HOSTNAME2 = getConfigurationValue('database.host2');
    const MONGO_HOSTNAME3 = getConfigurationValue('database.host3');
    const MONGO_PORT = getConfigurationValue('database.port');
    const MONGO_DB = getConfigurationValue('database.database');
    const MONGO_NAME = getConfigurationValue('database.name');
    const MONGO_REPLICA = getConfigurationValue('database.replicaSet');
    
    let url = '';
    if (process.env.NODE_ENV === 'development') {
        url = `${MONGO_DB}://${MONGO_HOSTNAME1}:${MONGO_PORT}/${MONGO_NAME}`;
    } else {
        url = `${MONGO_DB}://${MONGO_USERNAME}:${MONGO_PASSWORD}@${MONGO_HOSTNAME1}:${MONGO_PORT},${MONGO_HOSTNAME2}:${MONGO_PORT},${MONGO_HOSTNAME3}:${MONGO_PORT}/${MONGO_NAME}?${DATABASE.DATABASE_REPLICA}=${MONGO_REPLICA}`;
    }
    
    // Retry connection
    const connectWithRetry = () => {
        return mongoose.connect(url, options);
    };
    
    mongoose.connect(url, options);

    return {
        connectWithRetry,
        connection: mongoose.connection,
    };
}

connectToMongoDB().then(mongo => {
    const { connection: db, connectWithRetry } = mongo;

    db.on('error', (_err: any) => {
        logger.error(_err);
        setTimeout(connectWithRetry, 5000);
    });

    db.once('open', () => {
        console.log('Succesfully Connected to the Mongodb Database..');
        logger.info('Succesfully Connected to the Mongodb Database..');
    });
}).catch(error => {
    console.log({
        error,
    });
});

export default mongoose;
export { connectToMongoDB };