import NodeCache from 'node-cache';
import { getConfigurationValue } from "@config/index";

const GET_CONFIG_VALUES_CACHE_TTL = getConfigurationValue('cache.ttl') || '5';
const GET_CONFIG_VALUES_CACHE_CHECKPERIOD = getConfigurationValue('cache.checkperiod') || '5';

export const appManagerCache = new NodeCache({
    // standard time to live in seconds. 0 = infinity
    stdTTL: parseInt(GET_CONFIG_VALUES_CACHE_TTL) * 60,                     //in mins and it is converted into seconds

    // time in seconds to check all data and delete expired keys
    checkperiod: parseInt(GET_CONFIG_VALUES_CACHE_CHECKPERIOD) * 60,        //in mins and it is converted into seconds
});