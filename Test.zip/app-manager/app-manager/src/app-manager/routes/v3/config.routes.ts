import { Router } from "express";
import { fetchKeysV3 } from '@app-manager/controllers/keys';
import { validateKeysRequestV3 } from "@app-manager/middleware/validations";
import { verifyTokenV2 } from "@app-manager/middleware/jwt-token";

const router = Router();

router.get('/', validateKeysRequestV3, verifyTokenV2, fetchKeysV3);

export default router;