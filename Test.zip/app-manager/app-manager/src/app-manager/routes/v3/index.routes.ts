import * as express from 'express';
import config from '@app-manager/routes/v3/config.routes';

const apiRoute = '/api/app-manager';

const router: express.Router = express.Router();

router.use(`${apiRoute}/config`, config);

export default router;
