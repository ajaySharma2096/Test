import express from 'express';
import { checkSync } from 'diskusage';
import { mongoService } from '@app-manager/controllers/dependency';
import { getConfigurationValue } from "@config/index";
import logger from '@config/logger';


/**
 * 
 * @param req
 * @param res
 * 
 * It is the API handler for Application Diagnostics API to Check Readiness/Liveness, Verification of Critical Dependency
 * 
 */
export const dependency = async (
    req: express.Request,
    res: express.Response,
) => {
    if (req?.headers?.host === 'app-manager.paytmbank.com') {
      res.json({});
    }

    const clientRequestId = req.header('requestId')
    logger.info({
      req,
      requestId: clientRequestId,
    });

    const healthCheck: Record<string, any> = {
      program: 'app-manager',
      version: process.env.VERSION || '',
      release: process.env.RELEASE || '',
      datetime: new Date(),
      timestamp: Date.now(),
      status: 'success',
      code: 200,
      message: 'OK',
      data: {
        duration: 5,
        message: 'The service is healthy',
      },
      diskspace: {
        totalspace: '0',
        freespace: '0',
        usedspace: '0',
      },
      env: getConfigurationValue('env'),
    };

    try {
      // Synchronous
      const info = checkSync('/');
      if (info?.total || info?.free) {
        const gbValue = (bytesValue: number) => `${(bytesValue / (1024 * 1024 * 1024)).toFixed(3)} GB`;
        healthCheck.diskspace.totalspace = gbValue(info.total);
        healthCheck.diskspace.freespace = gbValue(info.free);
        healthCheck.diskspace.usedspace = gbValue(info.total - info.free);
      }
    } catch (err) {
      // do nothing
    }

    const dbHealthData: Record<string, any> = await mongoService();
    
    const allServices = [
      dbHealthData,
    ]

    allServices.forEach(service => {
      if (service?.serviceName) {
        healthCheck[service.serviceName] = service;
      }
    })

    res.json(healthCheck);
};