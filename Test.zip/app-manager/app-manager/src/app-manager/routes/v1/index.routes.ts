import * as express from 'express';
import config, { internalConfigRouter } from '@app-manager/routes/v1/config.routes';
import { internalClientRouter } from '@app-manager/routes/v1/client.routes';

const apiRoute = '/v1/api/app-manager';
const router: express.Router = express.Router();
const internalAppManagerRouter: express.Router = express.Router();

router.use(`${apiRoute}/config`, config);

internalAppManagerRouter.use(`${apiRoute}/config`, internalConfigRouter);

internalAppManagerRouter.use(`${apiRoute}/client`, internalClientRouter);

export default router;
export { internalAppManagerRouter };
