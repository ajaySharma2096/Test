import { Router } from "express";
import { fetchClient } from '@app-manager/controllers/client';
import { validateGetClientRequest } from "@app-manager/middleware/validations";
import { verifyToken } from "@app-manager/middleware/jwt-token";

const internalClientRouter = Router();

internalClientRouter.get('/', validateGetClientRequest, verifyToken, fetchClient);

export {
    internalClientRouter,
}
