import { Router } from "express";
import { fetchKeys, addOrUpdateKeys, deleteKeys } from '@app-manager/controllers/keys';
import { validateKeysRequest, validateAddOrUpdateKeys, validateDeleteKeys } from "@app-manager/middleware/validations";
import { verifyToken, verifyTokenV2 } from "@app-manager/middleware/jwt-token";

const router = Router();

router.get('/', validateKeysRequest, verifyToken, fetchKeys);

export default router;

const internalConfigRouter = Router();

internalConfigRouter.post('/add-update-key', validateAddOrUpdateKeys, verifyTokenV2, addOrUpdateKeys);

internalConfigRouter.post('/delete-key', validateDeleteKeys, verifyTokenV2, deleteKeys);

export {
    internalConfigRouter,
}
