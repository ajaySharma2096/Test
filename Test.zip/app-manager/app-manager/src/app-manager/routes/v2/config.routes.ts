import { Router } from "express";
import { fetchKeysV2 } from '@app-manager/controllers/keys';
import { validateKeysRequestV2 } from "@app-manager/middleware/validations";
import { verifyTokenV2 } from "@app-manager/middleware/jwt-token";

const router = Router();

router.get('/', validateKeysRequestV2, verifyTokenV2, fetchKeysV2);

export default router;