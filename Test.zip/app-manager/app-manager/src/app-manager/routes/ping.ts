import express from 'express';
import logger from '@config/logger';

/**
 * 
 * @param _req
 * @param _res
 * 
 * It is the API handler to serve the ping API
 * 
 */
export const ping = (
    _req: express.Request,
    _res: express.Response,
    ) => {
      const clientRequestId = _req.header('requestId')
      logger.info({
          requestId: clientRequestId,
          req: _req
      });
      _res.json({
        program: 'app-manager',
        version: process.env.VERSION || '',
        release: process.env.RELEASE || '',
        datetime: new Date(),
        timestamp: Date.now(),
        status: 'success',
        code: 200,
        message: 'OK',
        data: {
          duration: 5,
          message: 'The service is healthy',
        },
      });
};