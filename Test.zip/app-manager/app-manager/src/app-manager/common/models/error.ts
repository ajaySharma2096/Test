import { ERROR_STATUS } from '@app-manager/constants';
export class ErrorWrapper {
  public message: string;
  public status?: number;
  public requestId?: string;
  public code?: number | string;
  public uri?: string;
  public method?: string;
  public client?: string;
 
  constructor(
    message?: string,
    status?: number,
    requestId?: string,
    code?: number | string,
    uri?: string,
    method?: string,
    client?: string,
  ) {
    this.message = message || ERROR_STATUS.INTERNAL_ERROR.RESPONSE.MESSAGE;
    this.status = status || 500;
    this.requestId = requestId;
    this.code = code;
    this.uri = uri;
    this.method = method;
    this.client = client;
  }
}