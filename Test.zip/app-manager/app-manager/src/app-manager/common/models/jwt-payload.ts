import { Request } from "express";

export interface JwtTokenPayload {
    client: string;
    iss: string;
    iat: number;
    requestId: string
}

export interface JwtTokenPayloadV2 {
    namespace: string;
    iss: string;
    iat: number;
    requestId: string
}

export interface IRequestIAT extends Request {
  iat?: number;
}