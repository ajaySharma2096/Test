export const CONFIG_ROOT_PATH = 'src/app-manager/data';

export const JWT = {
      ISSUER: 'app-manager-service',
      SECRET_KEY_CONFIG_PATH: 'jwt.secretKey',
      PPBL_SECRET_KEY_CONFIG_PATH: 'jwt.ppblSecretKey',
};

export const SUCCESS_MESSAGE = "Data is successfully fetched";

export const CONFIG_CREATE_SUCCESS_MESSAGE = "Keys created successfully";

export const CONFIG_UPDATE_SUCCESS_MESSAGE = "Keys updated successfully";

export const CONFIG_DELETE_SUCCESS_MESSAGE = "Keys deleted successfully";

export const CLIENT_FETCH_SUCCESS_MESSAGE = "Client fetched successfully";

export const CLIENT = {
    ANDROIDAPP: {
        ID: "androidapp",
        TITLE: "Paytm App Android",     // client used for OCL/Paytm Android App
    },
    IOSAPP: {
        ID: "iosapp",
        TITLE: "Paytm App iOS",        // client used for OCL/Paytm iOS App
    },
    PPBLAPPCLIENTIOS: {
        ID: "ppblAppClientIos",
        TITLE: "Bank App iOS",          // client used for Bank iOS App
    },
    PPBLAPPCLIENTANDROID: {
        ID: "ppblAppClientAndroid",
        TITLE: "Bank App Android",      // client used for Bank Android App
    },
};

export const ERROR_STATUS = {
    ACCESS_DENIED: {
        HTTP_RESPONSE: 401,
        RESPONSE: {
            STATUS: "FAILURE",
            MESSAGE: "Access Denied",
            ERROR_CODE: {
                INVALID_SIGNATURE: 1000, // Invalid Signature
                MISSING_TOKEN: 1001, // Missing Token
                INVALID_ISS: 1002, // Invalid Token (Incorrect iss)
                INVALID_CLIENT : 1003, // Invalid Token (Incorrect Client)
                IAT_EXPIRED: 1004, // Invalid Token (iat expired)
                INVALID_REQUEST_ID: 1005, // Invalid Token (Incorrect requestId)
                INVALID_NAMESPACE : 1011, // Invalid Token (Incorrect namespace)
                XSS : 1012, // XSS
            }
        }
    },
    INVALID_QUERY_PARAMS: {
        HTTP_RESPONSE: 400,
        RESPONSE: {
            STATUS: "FAILURE",
            /**
             * 
             * This error may occur when
             *  - Invalid referrer is present
             *  - Invalid client is present
             *  - Invalid requestId is present
             *  - offset is not present ( in case of valid referrer )
             *  - limit is not present ( in case of valid referrer )
             *  - lastUpdatedAt is not valid
             * 
             */
            MESSAGE: "Invalid Params/Headers",
            ERROR_CODE: 1006,
        }
    },
    INTERNAL_ERROR: {
        HTTP_RESPONSE: 500,
        RESPONSE: {
            STATUS: "FAILURE",
            MESSAGE: "Something went wrong. Please try again",
            ERROR_CODE: 1007
        }
    },
    NOT_FOUND: {
        HTTP_RESPONSE: 404,
        RESPONSE: {
            STATUS: "FAILURE",
            MESSAGE: "Not Found",
            ERROR_CODE: 1008
        }
    },
    METHOD_NOT_ALLOWED: {
        HTTP_RESPONSE: 405,
        RESPONSE: {
            STATUS: "FAILURE",
            MESSAGE: "Method not allowed",
            ERROR_CODE: 1009
        }
    },
    INVALID_BODY_PARAMS: {
        HTTP_RESPONSE: 400,
        RESPONSE: {
            STATUS: "FAILURE",
            MESSAGE: "Invalid Body",
            ERROR_CODE: 1010 // Invalid keys/operation in body
        }
    }
};

export const METRIX = {
    LATENCY: 'Latency',
    API_TOTAL: 'Api.total',
    API_SUCCESS: 'Api.success',
    API_FAILURE: 'Api.failure',
};

export const DATABASE = {
    DATABASE_USERNAME_PATH: 'database.username',
    DATABASE_PASSWORD_PATH: 'database.password',
    DATABASE_REPLICA: 'replicaSet',
};

export const KEYS_STATUS = {
    ACTIVE: 'active',
    INACTIVE: 'inactive',
};

export const KEYS_DISPLAY_ATTRIBUTES = {
    _id: 1,
    id: 1,
    key: 1,
    value: 1,
};

export const BOP_REFERRER = 'BOP';

export const GET_CONFIG_VALUES_CACHE_KEY = "getConfigValuesCacheKey";

export const CONFIG_VALUE_OPERATIONS = {
    UPDATE: 'update',
    ADD: 'add'
}

export const JWT_TOKEN_EXPIRY = 120;                // in seconds

export const DATE_FORMAT = "DD-MM-YYYY hh:mm A";

export type ReqQuery = {
    namespace: string,
    referrer?: string,
    offset?: string,
    limit?: string,
    search?: string,
    lastUpdatedAt?: string
}

export type ConfigKeysResponse = {
    list: Object[],
    deletedList?: Object[],
    lastUpdatedAt?: any,
    total: number
}