import moment from "moment";
import { appManagerCache } from "@app-manager/cache";
import { GET_CONFIG_VALUES_CACHE_KEY, ConfigKeysResponse, KEYS_STATUS, DATE_FORMAT, KEYS_DISPLAY_ATTRIBUTES, ERROR_STATUS } from "@app-manager/constants";
import { ErrorWrapper } from '@app-manager/common/models/error';
import Keys from "@app-manager/database/models/keys.model";
import logger from "@config/logger";

/**
 * 
 * @param query
 * @param keys
 * @param clientRequestId
 * 
 * It takes a query and check for the keys if all exists, else throw an error
 * 
 */
export const checkPresentKeys = async (query: Object, keys: string[], clientRequestId: string) => {

  const keysInDB = await Keys.find(query).select('key');
  if (keysInDB?.length !== keys?.length) {
    throw new ErrorWrapper(
      'key does not exist',
      ERROR_STATUS.INVALID_BODY_PARAMS.HTTP_RESPONSE,
      clientRequestId,
      ERROR_STATUS.INVALID_BODY_PARAMS.RESPONSE.ERROR_CODE,
    );
  }

}

/**
 * 
 * @param keys
 * @param clientRequestId
 * 
 * It takes keys[] and check whether the requested key/values has some new value or not
 * 
 */
export const checkPresentValues = async (keys: { key: string, value: string, clientType: string }[], clientRequestId: string) => {

  const presentValues = await Keys?.find({
    $or: keys?.map(key => ({ key: key?.key, value: key?.value, status: KEYS_STATUS.ACTIVE, clientType: key?.clientType }))
  }).count();

  if (presentValues) {
    throw new ErrorWrapper(
      'Please provide different value',
      ERROR_STATUS.INVALID_BODY_PARAMS.HTTP_RESPONSE,
      clientRequestId,
      ERROR_STATUS.INVALID_BODY_PARAMS.RESPONSE.ERROR_CODE,
    );
  }

}

/**
 * 
 * @param query
 * @param clientRequestId
 * 
 * It takes a query and check no key exists else throws an error
 * 
 */
export const checkExistingKeys = async (query: Object, clientRequestId: string) => {

  const keysInDB = await Keys.find(query).select('key');
  if (keysInDB?.length > 0) {
    throw new ErrorWrapper(
      'key already exists',
      ERROR_STATUS.INVALID_BODY_PARAMS.HTTP_RESPONSE,
      clientRequestId,
      ERROR_STATUS.INVALID_BODY_PARAMS.RESPONSE.ERROR_CODE,
    );
  }

}

/**
 * 
 * @param namespace
 * @param version
 * 
 * It takes a namespace and version and returns cache key
 * 
 */
export const getCacheKey = (namespace: string, version = "") => GET_CONFIG_VALUES_CACHE_KEY + namespace + version

/**
 * 
 * @param cacheKey
 * 
 * It takes a cacheKey and returns data from cache
 * 
 */
export const getDataFromCache = (cacheKey: string) => appManagerCache.get<ConfigKeysResponse>(cacheKey);

/**
 * 
 * @param key
 * @param data
 * 
 * It takes a key & data, sets the data in cache and returns data
 * 
 */
export const setDataToCache = (key: string, data: ConfigKeysResponse) => {
  appManagerCache.set(key, data);

  return data;
}

/**
 * 
 * @param namespace
 * @param referrer
 * @param search
 * @param offset
 * @param limit
 * 
 * It takes above params and returns pipeline & match to get config values from DB
 * 
 */
export const getConfigKeysPipelineAndMatch = (namespace: string, referrer?: string, search?: string, offset?: string, limit?: string) => {
  const $match: Record<string, any> = { clientType: namespace };

  let pipeline: any;
  if (referrer) {
    $match.status = KEYS_STATUS.ACTIVE;

    if (search) {
      $match.key = { $regex: search, $options: 'i' };
    }

    pipeline = [
      { $match },
      { $sort: { updatedAt: -1, _id: -1 } },
    ]

    if (offset) {
      pipeline.push({ $skip: parseInt(offset) })
    }

    if (limit) {
      pipeline.push({ $limit: parseInt(limit) })
    }
  } else {
    pipeline = [
      { $match: { ...$match } },
      // sort in descending order
      { $sort: { updatedAt: -1, _id: -1 } },
      // group to get latest value of any key
      {
        $group: {
          _id: "$key",
          config: { $first: "$$ROOT" },
        }
      },
      // take in config to root
      { $replaceRoot: { newRoot: "$config" } },
      // add field namespace
      {
        $addFields: {
          namespace: "$clientType"
        }
      },
      // sort in descending order
      {
        $sort: { updatedAt: -1, _id: -1 }
      },
      // group to get list of active/inactive config
      {
        $group: {
          _id: null,
          lastUpdatedAt: { $first: "$updatedAt" },
          list: {
            // accumulate active keys
            $push: {
              $cond: [
                { $eq: [ "$status", KEYS_STATUS.ACTIVE ] },
                "$$ROOT",
                "$$REMOVE"
              ]
            }
          },
          deletedList: {
            // accumulate inactive keys
            $push: {
              $cond: [
                { $eq: [ "$status", KEYS_STATUS.INACTIVE ] },
                "$$ROOT",
                "$$REMOVE"
              ]
            }
          }
        }
      },
      {
        $project: {
          _id: 0,
          list: 1,
          deletedList: 1,
          lastUpdatedAt: { $toLong: "$lastUpdatedAt" },
        }
      }
    ]

    $match.status = KEYS_STATUS.ACTIVE;
  }

  return {
    pipeline,
    $match,
  };
}

/**
 * 
 * @param namespace
 * @param clientRequestId
 * @param referrer
 * @param search
 * @param offset
 * @param limit
 * 
 * It takes above params and returns config values from DB
 * 
 */
export const getDataFromDB = async (namespace: string, clientRequestId: string, referrer?: string, search?: string, offset?: string, limit?: string) => {
  const { pipeline, $match } = getConfigKeysPipelineAndMatch(namespace, referrer, search, offset, limit);

  logger.info({
    requestId: clientRequestId,
    message: "Fetching Data From DB"
  })

  return Promise.all([
    Keys.aggregate(pipeline)
      .then(results => {
        if (!referrer) {
          results[0].list = results[0]?.list?.map((key: any) => new Keys(key).toJSON()) || [];
          results[0].deletedList = results[0]?.deletedList?.map((key: any) => new Keys(key).toJSON()) || [];

          return results[0];
        } else {
          return {
            list: results?.map(key => new Keys(key).toJSON()),
          };
        }
      })
      .catch(error => {
        logger.error({
          requestId: clientRequestId,
          error
        });
      }),
    Keys.countDocuments($match),
  ])
}

/**
 * 
 * @param dataList
 * @param lastUpdatedAtMoment
 * 
 * It takes dataList & lastUpdatedAtMoment and returns filtered list based on lastUpdatedAtMoment
 * 
 */
export const filterConfigKeysByLastUpdatedAt = (dataList?: Object[], lastUpdatedAtMoment?: moment.Moment) => {
  return dataList?.reduce((list: Object[], data: any) => {
    const dataUpdatedAtMoment = moment(data.updatedAt, DATE_FORMAT);
    if (lastUpdatedAtMoment && !dataUpdatedAtMoment.isAfter(lastUpdatedAtMoment)) {
      return list;
    }

    const newData: any = {};
    Object.keys(KEYS_DISPLAY_ATTRIBUTES).forEach(attr => {
      newData[attr] = data[attr];
    })

    list.push(newData);

    return list;
  }, []) as Object[];
}

/**
 * 
 * @param response
 * @param lastUpdatedAt
 * @param cachedData
 * 
 * It takes response, lastUpdatedAt & cachedData and returns data from Cache value
 * 
 */
export const getConfigKeysFromCacheValue = (response: ConfigKeysResponse, lastUpdatedAt?: string, cachedData?: ConfigKeysResponse) => {
  let lastUpdatedAtMoment = lastUpdatedAt ? moment(Number(lastUpdatedAt)) : undefined;

  response.lastUpdatedAt = cachedData?.lastUpdatedAt;

  response.list = filterConfigKeysByLastUpdatedAt(cachedData?.list, lastUpdatedAtMoment);

  response.total = response?.list?.length;

  if (lastUpdatedAtMoment) {
    response.deletedList = filterConfigKeysByLastUpdatedAt(cachedData?.deletedList, lastUpdatedAtMoment);
  } else {
    delete response.deletedList;
  }

  return response;
}

/**
 * 
 * @param onlyKeys
 * @param updatedAt
 * @param namespace
 * @param clientRequestId
 * 
 * It checks no key exists with createdAt greater than updatedAt received for given namespace else throws an error
 * 
 */
export const validateUpdatedAt = async (onlyKeys: string[], updatedAt: number, namespace: string, clientRequestId: string) => {
  const invalidKeys = await Keys.find({
    key: { $in: onlyKeys },
    status: KEYS_STATUS.ACTIVE,
    clientType: namespace,
    createdAt: { $ne: null, $gt: updatedAt },
  }).select('key').then(configs => configs.map(config => config.key));

  if (invalidKeys?.length > 0) {
    throw new ErrorWrapper(
      `Invalid timestamp for ${invalidKeys.join(',')}`,
      ERROR_STATUS.INVALID_BODY_PARAMS.HTTP_RESPONSE,
      clientRequestId,
      ERROR_STATUS.INVALID_BODY_PARAMS.RESPONSE.ERROR_CODE,
    );
  }
}