import { getConfigurationValue } from '@config/index';
import logger from '@config/logger';

const StatsD = require('hot-shots');

const client = new StatsD({
  host: getConfigurationValue('appMonitoring.host'),
  port: getConfigurationValue('appMonitoring.port'),
  prefix: getConfigurationValue('appMonitoring.prefix'),
  globalTags: [
    `release:${process.env.RELEASE}`,
    `version:${process.env.VERSION}`,
  ],
  // bufferFlushInterval: getConfigurationValue('AppMonitoring.bufferFlushInterval'),
});

export const errorMethod = () => {
    // logger.error({ type: 'Bank App-Managers appmonitoring error', error });
};

client.socket.on('error', errorMethod);

export const getCategoryTag = (tags: string[], category: string) =>
  tags.concat(`category:${category}`);


export const appMonitoringMatrixIncrement = (
  matrixName: string,
  counter: number,
  tags: string[] = [],
) => {
  try {
    client.increment(matrixName, counter, null, tags);
  } catch (error) {
    logger.error({
      type: `Bank App-Managers appmonitoring error ${matrixName}`,
      error,
    });
  }
};

export const appMonitoringMatrixTiming = (
  matrixName: string,
  responseTime: number,
  tags: string[],
) => {
  try {
    client.timing(matrixName, responseTime, null, tags);
  } catch (error) {
    logger.error({
      type: `Bank App-Managers appmonitoring error ${matrixName}`,
      error,
    });
  }
};

export default client;
