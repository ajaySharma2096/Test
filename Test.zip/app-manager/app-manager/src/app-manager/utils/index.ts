import { Response } from "express";
import { CLIENT, ERROR_STATUS, METRIX } from "@app-manager/constants";
import { ErrorWrapper } from "@app-manager/common/models/error";
import logger from "@config/logger";
import { appMonitoringMatrixIncrement } from '@app-manager/utils/app-monitoring';

/**
 * 
 * @param item
 * 
 * It is used check if the given item is not a empty(i.e. undefined, null, '')
 * 
 */
export const notNullUndefinedOrEmpty = (item: any) => item !== undefined && item !== null && item !== "";

/**
 * 
 * @param key
 * @param client
 * 
 * It is used to validate the config keys
 * 
 */
export const isValidConfigKey = (key: any, client: string) => (notNullUndefinedOrEmpty(key?.key) && notNullUndefinedOrEmpty(key?.value) && notNullUndefinedOrEmpty(key?.updatedBy) && notNullUndefinedOrEmpty(key?.clientType) && key?.clientType == client);

/**
 * 
 * It is used to get all the Clients allowed
 * 
 */
export const getConfigClientIds = () => Object.values(CLIENT).map(client => client.ID);

/**
 * 
 * @param data
 * @param res
 * 
 * It is the success handler to return a success response to APIs
 * 
 */
export const successResponse = (data: any, res: Response, clientRequestId: string) => {
    logger.info({
        requestId: clientRequestId,
        response: data,
    });

    appMonitoringMatrixIncrement(METRIX.API_SUCCESS, 1);

    return res.status(200).send(data);
}

/**
 * 
 * @param error
 * @param res
 * 
 * It is the error handler to return a failure response to APIs
 * 
 */
export const errorResponse = (error: ErrorWrapper, res: Response, clientRequestId: string, errorCode?: string | number) => {
    logger.error({
        requestId: clientRequestId,
        error,
    });

    appMonitoringMatrixIncrement(METRIX.API_FAILURE, 1, [`errorCode:${errorCode}`]);

    return res.status(
        error?.status || ERROR_STATUS.INTERNAL_ERROR.HTTP_RESPONSE
    ).send({
        status: 'FAILURE',
        message: error?.message || ERROR_STATUS.INTERNAL_ERROR.RESPONSE.MESSAGE
    });
}