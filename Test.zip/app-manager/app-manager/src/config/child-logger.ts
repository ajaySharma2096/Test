// @ts-nocheck
import * as _ from 'lodash';
import * as bunyan from 'bunyan';
import moment from 'moment';
import * as querystring from 'querystring';
import jwt from 'jsonwebtoken';
// import * as URL from 'url';
import {
  MASK_KEYS,
  KEYS_URL_MAP,
  KEYS_URL_REGEX,
  DONT_MASK_KEYS,
  MASK_NESTED_KEYS,
} from '@config/constants';

import { getConfigurationValue } from '@config/index';

import {
  JWT,
} from '@app-manager/constants';

import { JwtTokenPayload } from '@app-manager/common/models/jwt-payload';

const rfs = require('rotating-file-stream');

export const getQueryString = (url: string): string => {
  const queryStart = url.indexOf('?');
  if (queryStart === -1) {
    return '';
  }
  return url.slice(queryStart + 1);
};

const parseUrl = (
  url: string,
): { baseUrl: string; queryString: string } => {
  return {
    baseUrl: url.split('?')[0] || '',
    queryString: getQueryString(url),
  };
};

function findKey(object: { [key: string]: any }, key: string) {
  if (_.has(object, key)) {
    return object[key];
  }
  for (const objKey in object) {
    if (_.isPlainObject(object[objKey])) {
      const o: any = findKey(object[objKey], key);
      if (o !== null) {
        return o;
      }
    }
  }
  return null;
}

function urlPathMasking(object: any) {
  const url =
    _.get(object, 'req.url') ||
    _.get(object, 'res.config.url') ||
    _.get(object, 'error.config.url');

  if (!!url) {
    const { baseUrl, queryString } = parseUrl(url);
    const maskedUrl = baseUrl + (url.indexOf('?') >= 0 ? `?${queryString}` : '');

    if (_.get(object, 'req.url')) {
      _.set(object, 'req.url', maskedUrl);
    } else if (_.get(object, 'res.config.url')) {
      _.set(object, 'res.config.url', maskedUrl);
    } else {
      _.set(object, 'error.config.url', maskedUrl);
    }
  }
}

function urlBasedMasking(object: any) {
  const url = findKey(object, 'url');
  if (url) {
    const baseUrl = parseUrl(url).baseUrl;
    _.each(KEYS_URL_MAP, (configVal: string[], configKey: string) => {
      let configKeyUrl = parseUrl(configKey).baseUrl;

      if (KEYS_URL_REGEX[configKey]) {
        configKeyUrl = updateUrlWithRegex(
          configKeyUrl,
          KEYS_URL_REGEX[configKey],
        );
      }

      if (new RegExp(configKeyUrl).test(baseUrl)) {
        (configVal || []).forEach(keyPath => {
          if (_.has(object, keyPath)) {
            _.set(object, keyPath, 'XXXXX');
          }
        });
      }
    });
  }
}

function updateUrlWithRegex(url: string, config: { [key: string]: string }) {
  let returnUrl = url;

  _.each(Object.keys(config), key => {
    returnUrl = returnUrl.replace(key, config[key]);
  });

  return returnUrl;
}

function replaceStringParsing(keyVal: string, valVal: string, data: string) {
  try {
    const queryObject = querystring.parse(data);
    if (queryObject[keyVal]) {
      queryObject[keyVal] = valVal;
    }
    return querystring.stringify(queryObject);
  } catch (e) {
    return data;
  }
}

function replacePropertyValue(keyVal: string, valVal: string, object: any) {
  const newObject = _.clone(object);

  _.each(object, (val: string | { [key: string]: string }, key: string) => {
    if (key === 'data' && _.isString(newObject[key])) {
      newObject[key] = replaceStringParsing(keyVal, valVal, newObject[key]);
    } else if (key === 'url' && typeof newObject[key] === 'string') {
      const {
        queryString,
        baseUrl,
      }: { queryString: string; baseUrl: string } = parseUrl(newObject[key]);
      if (queryString) {
        newObject[key] = `${baseUrl}?${replaceStringParsing(
          keyVal,
          valVal,
          queryString,
        )}`;
      }
    } else if (key === keyVal) {
      newObject[key] = valVal;
    } else if (typeof val === 'object' || Array.isArray(val)) {
      newObject[key] = replacePropertyValue(keyVal, valVal, val);
    }
  });

  return newObject;
}

function parseData(data: { [key: string]: string }) {
  urlBasedMasking(data);
  const url = _.get(data, 'res.config.url');
  const dontMaskKeysList = DONT_MASK_KEYS[url];
  const maskNestedKeysList = MASK_NESTED_KEYS[url];

  const headersDetails = _.get(data, 'req.rawHeaders');
  let token = '', xAppRid = '', xId = '';
  if (headersDetails?.length > 0) {
    if (headersDetails.indexOf('authorization') < 0) {
      token = headersDetails[headersDetails.indexOf('Authorization') + 1];
    } else {
      token = headersDetails[headersDetails.indexOf('authorization') + 1];
    }
    if (headersDetails.indexOf('x-app-rid') >= 0) {
      xAppRid = headersDetails[headersDetails.indexOf('x-app-rid') + 1] 
    }
    if (headersDetails.indexOf('x-id') >= 0) {
      xId = headersDetails[headersDetails.indexOf('x-id') + 1] 
    }
  }

  let jwtIat = '', iatTimeDiff = '';
  if (token) {
    const decodedToken = jwt.verify(token, getConfigurationValue(JWT.SECRET_KEY_CONFIG_PATH)) as JwtTokenPayload;
    jwtIat = decodedToken?.iat;
    iatTimeDiff = Math.floor(Date.now() / 1000) - jwtIat;
  }

  MASK_KEYS.forEach(val => {
    data = replacePropertyValue(val, 'XXXXX', data);
  });

  if (maskNestedKeysList) {
    maskNestedKeysList.forEach(keyValue => {
      let parsedObj = {};
      let keyPath = '';
      let jsonPath = '';
      let parseFailed = false;
      const keyPathArr = keyValue.split('.');
      keyPathArr.forEach((key, index) => {
        keyPath = index ? `${keyPath}.${key}` : key;
        if (index !== keyPathArr.length - 1) {
          if (typeof _.get(data, keyPath) === 'object') {
            jsonPath = keyPath;
          } else if (typeof _.get(data, keyPath) === 'string') {
            try {
              parsedObj = JSON.parse(_.get(data, keyPath));
            } catch (e) {
              parseFailed = true;
            }
            jsonPath = keyPath;
          }
        } else if (!dontMaskKeysList?.includes(key)) {
          if (_.isEmpty(parsedObj)) {
            if (parseFailed) {
              if (
                !dontMaskKeysList?.includes(keyPathArr[keyPathArr.length - 2])
              ) {
                _.set(data, jsonPath, 'XXXXX');
              }
            } else {
              _.set(data, keyPath, 'XXXXX');
            }
          } else {
            _.set(parsedObj, key, 'XXXXX');
            parsedObj = JSON.stringify(parsedObj);
            _.set(data, jsonPath, parsedObj);
          }
        }
      });
    });
  }

  if (jwtIat) data.req.iat = jwtIat;
  if (iatTimeDiff) data.req.iatTimeDifference = iatTimeDiff;
  if (xAppRid) data.req.xAppRid = xAppRid;
  if (xId) data.req.xId = xId;

  // keep url path masking in last as unmasked url might be needed in between
  urlPathMasking(data);
  return data;
}

class MaskingStream implements NodeJS.WritableStream {
  public off(
    _event: string | symbol,
    _listener: (...args: any[]) => void,
  ): this {
    throw new Error('Method not implemented.');
  }
  public addListener(): this {
    throw new Error('Method not implemented.');
  }
  public on(): this {
    throw new Error('Method not implemented.');
  }
  public once(): this {
    throw new Error('Method not implemented.');
  }
  public rawListeners(): Function[] {
    throw new Error('Method not implemented.');
  }
  public removeListener(): this {
    throw new Error('Method not implemented.');
  }
  public removeAllListeners(): this {
    throw new Error('Method not implemented.');
  }
  public setMaxListeners(): this {
    throw new Error('Method not implemented.');
  }
  public getMaxListeners(): number {
    throw new Error('Method not implemented.');
  }
  public listeners(): Function[] {
    throw new Error('Method not implemented.');
  }
  public emit(): boolean {
    throw new Error('Method not implemented.');
  }
  public listenerCount(): number {
    throw new Error('Method not implemented.');
  }
  public prependListener(): this {
    throw new Error('Method not implemented.');
  }
  public prependOnceListener(): this {
    throw new Error('Method not implemented.');
  }
  public eventNames(): Array<string | symbol> {
    throw new Error('Method not implemented.');
  }
  public writable: any = true;
  private stream: NodeJS.WritableStream;
  constructor(opts: { stream: NodeJS.WritableStream }) {
    this.stream = opts.stream || process.stdout;
  }
  public async write(data: string): any {
    try {
      const logData = JSON.parse(data);
      const obj: { [key: string]: string } = JSON.parse(data);
      if (typeof obj !== 'object') {
        this.stream.write(`${obj}\n`);
        return true;
      }
      if (typeof _.get(data, 'err.config.data') === 'string') {
        delete logData.err.config.data;
      }
      if (typeof _.get(data, 'error.config.data') === 'string') {
        delete logData.error.config.data;
      }
      if (typeof _.get(data, 'e.config.data') === 'string') {
        delete logData.e.config.data;
      }

      const rawHeaders = _.get(logData, 'req.rawHeaders');

      const headersObj = {};

      if(rawHeaders?.length > 0) {
        rawHeaders.forEach((item, index) => {
          if (index % 2 === 0) {
            headersObj[item] = rawHeaders[index + 1];
          }
        })
      }
      
      const parsedValue = parseData(logData);
      const { req, res, error, err, errorResponse, requestData, sendReq, clientIpInfo, config, action, connection, reqError, e,
        result, timings, globalError, resData, response } = parsedValue;

      const userAgent = _.get(req, 'headers.user-agent');
      const trueClientIp = _.get(req, 'headers.true-client-ip');
      const method =
        _.get(req, 'method') ||
        _.get(res, 'config.method') ||
        _.get(error, 'config.method');

      const status = _.get(res, 'status') || _.get(error, 'status');

      const responseTime =
        _.get(res, 'config.responseTime') ||
        _.get(error, 'config.responseTime');

      const code = _.get(error, 'code');

      const apiDetails: any = {
        ...(userAgent && { userAgent }),
        ...(trueClientIp && { trueClientIp }),
        ...(method && { method: method.toUpperCase() }),
        ...(status && { status }),
        ...(responseTime && { responseTime }),
        ...(code === 'ECONNABORTED' && { code }),
        time: moment(parsedValue.time, 'YYYY-MM-DDTHH:mm:ss.SSSSZ', true).format(
          'YYYY-MM-DDTHH:mm:ss.SSS[Z]'),
      };

      if(headersObj) {
        apiDetails.host = JSON.stringify(headersObj['Host'] || '');
      }

      if (parsedValue?.requestId) {
        apiDetails.requestId = parsedValue.requestId;
      }

      if (req?.originalUrl) {
        apiDetails.uri =  _.get(req, 'originalUrl') || '-';
      }
      
      if (req?.iat) {
        apiDetails.iat = req.iat;
      }
      
      if (req?.iatTimeDifference) {
        apiDetails.iatTimeDifference = req.iatTimeDifference;
      }
      
      if (req?.xId) {
        apiDetails.xId = req.xId;
      }
      
      if (req?.xAppRid) {
        apiDetails.xAppRid = req.xAppRid;
      }

      // if (configUrl) {
      //   const { pathname, protocol, hostname } = URL.parse(configUrl || '');
      //   const uri = `${protocol}//${hostname}${pathname}`;
      //   const hostName = `${protocol}//${hostname}`;
      //   apiDetails.uri = uri || '-';
      //   apiDetails.hostName = hostName || '-';
      // }

      if (error) {
        if (error?.code) parsedValue.errorCode = error.code;
        if (error?.status) parsedValue.status = error.status;
        if (error?.uri) apiDetails.uri = error.uri;
        if (error?.method) apiDetails.method = error.method;
        if (error?.client) apiDetails.client = error.client;
        delete error.code;
        delete error.method;
        delete error.client;
        delete error.uri;
        parsedValue.error = JSON.stringify(error);
      }

      parsedValue.apiDetails = apiDetails;

      if(headersObj) {
        parsedValue.xForwardedFrom = JSON.stringify(headersObj['X-Forwarded-For'] || '');
      }

      if (req) {
        parsedValue.req = JSON.stringify(req);

      }
      if (res) {
        parsedValue.res = JSON.stringify(res);
      }

      if (error?.code) {
        parsedValue.errorCode = JSON.stringify(error?.code);
      }

      if (resData) {
        parsedValue.data = JSON.stringify(resData);
      }

      if (req) {
        if (req?._readableState) {
          delete req._readableState;
        }
        if (req?._parsedUrl) {
          delete req._parsedUrl;
        }
        if (req?.socket) {
          delete req.socket;
        }
        if (req?._events) {
          delete req._events;
        }
        if (req?._eventsCount) {
          delete req._eventsCount;
        }
        if (req?.res) {
          delete req.res;
        }
        delete req.httpVersionMajor;
        delete req.httpVersionMinor;
        delete req.httpVersion;
        delete req.rawTrailers;
        delete req.client;
        delete req.complete;
        delete req.aborted;
        delete req.upgrade;
        delete req.statusCode;
        delete req.statusMessage;
        delete req._consuming;
        delete req._dumped;
        parsedValue.req = JSON.stringify(req);
      }
      if (sendReq) {
        parsedValue.req = JSON.stringify(sendReq);
        delete parsedValue.sendReq;
      }
      if (res) {
        parsedValue.res = JSON.stringify(res);
      }
      if (response) {
        parsedValue.res = JSON.stringify(response);
        delete parsedValue.response;
      }
      if (error) {
        parsedValue.error = JSON.stringify(error);
      }
      if (err) {
        parsedValue.error = JSON.stringify(err);
        delete parsedValue.err;
      }
      if (errorResponse) {
        parsedValue.error = JSON.stringify(errorResponse);
        delete parsedValue.errorResponse;
      }
      if (requestData) {
        parsedValue.apiRequestData = JSON.stringify(requestData);
        delete parsedValue.requestData;
      }
      if (clientIpInfo) {
        parsedValue.clientIpInfo = JSON.stringify(clientIpInfo);
      }
      if (config) {
        delete parsedValue.config;
      }
      if (action) {
        delete parsedValue.action;
      }
      if (connection) {
        delete parsedValue.connection;
      }
      if (reqError) {
        delete parsedValue.reqError;
      }
      if (e) {
        delete parsedValue.e;
      }
      if (result) {
        delete parsedValue.result;
      }
      if (timings) {
        delete parsedValue.timings;
      }
      if (globalError) {
        parsedValue.error = JSON.stringify(globalError);
        delete parsedValue.globalError;
      }
      if (parsedValue && parsedValue['request-id']) {
        parsedValue.requestId = parsedValue['request-id'];
        delete parsedValue['request-id'];
      }
      if (parsedValue?.requestId) {
        parsedValue.requestId = parsedValue.requestId.toString();
        delete parsedValue['request-id'];
      }

      parsedValue.time = moment(parsedValue.time, 'YYYY-MM-DDTHH:mm:ss.SSSSZ', true).format(
        'YYYY-MM-DDTHH:mm:ss.SSS[Z]'
      );

      this.stream.write(`${JSON.stringify(parsedValue)}\n`);
    } catch (err) {
      this.stream.write(`${data}\n`);
    }
    return true;
  }
  public end(): void {
    return;
  }
}

export const createLogger = (
  appname: string,
  errorLogFile: string,
  appLogFile: string,
  logOptions: any,
) => bunyan.createLogger({
  name: appname,
  streams: [
    {
      level: 'info',
      stream: new MaskingStream({
        stream: rfs.createStream(appLogFile, logOptions),
      }),
    },
    {
      level: 'error',
      stream: new MaskingStream({
        stream: rfs.createStream(errorLogFile, logOptions),
      }),
    },
  ],
});
