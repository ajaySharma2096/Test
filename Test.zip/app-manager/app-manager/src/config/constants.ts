export const MASK_KEYS = [
    'Authorization',
    'value',
    'rawHeaders',
];

export const MASK_NESTED_KEYS: { [key: string]: string[] } = {};
  
export const DONT_MASK_KEYS: { [key: string]: string[] } = {};

export let KEYS_URL_MAP: { [key: string]: string[] } = {};

export const KEYS_URL_REGEX: { [key: string]: { [key: string]: string } } = {};