import * as path from 'path';
import * as fs from 'fs';
import * as _ from 'lodash';

const args: any = process.argv
  .slice(2)
  .reduce((result: { [k: string]: string }, arg) => {
    const tmp: string[] = arg.split('=');
    result[tmp[0]] = tmp[1];
    return result;
  }, {});

const configFilePath = path.join(__dirname, args.config);

const config = JSON.parse(fs.readFileSync(configFilePath).toString());

/**
 * 
 * @param key
 * 
 * It is used to extract the config value of the key
 * 
 */
export const getConfigurationValue = (key: string): string =>
  _.get(config, key);

_.set(config, 'jwt.secretKey', process.env.MIDDLEWARE_APP_MANAGER_MOBILE_JWT_SECRET_KEY);

_.set(config, 'jwt.ppblSecretKey', process.env.MIDDLEWARE_APP_MANAGER_PPBLAPP_MOBILE_JWT_SECRET_KEY);

_.set(
  config,
  'database.username',
  process.env.MIDDLEWARE_APP_MANAGER_MONGO_USER
);

_.set(
  config,
  'database.password',
  process.env.MIDDLEWARE_APP_MANAGER_MONGO_PASSWORD
);