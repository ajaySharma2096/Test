import * as fs from 'fs';
import * as path from 'path';
import * as morgan from 'morgan';
import express from 'express';
import { getConfigurationValue } from '@config/index';
import { createLogger } from '@config/child-logger';
const rfs = require('rotating-file-stream');

const logDir = getConfigurationValue('logDir');
const appManagerEnv = getConfigurationValue('env');

const logDirectory = path.join(logDir);
let appLogPath = `middleware-app-manager_application.log`;
let errorLogPath = `middleware-app-manager_error.log`;
let accessLogPath = `middleware-app-manager_access.log`;

if (!fs.existsSync(logDirectory)) fs.mkdirSync(logDirectory);

if (appManagerEnv === 'development' || appManagerEnv === 'mwite1') {
  appLogPath = `${appManagerEnv}_middleware-app-manager_application.log`;
  errorLogPath = `${appManagerEnv}_middleware-app-manager_error.log`;
  accessLogPath = `${appManagerEnv}_middleware-app-manager_access.log`;
}

const logOptions = {
  size: '1G',
  interval: '1d',
  compress: 'gzip',
  path: logDirectory
};

export const logger = createLogger('app-manager', errorLogPath, appLogPath, logOptions);

const accessLogStream = rfs.createStream(accessLogPath, logOptions);

morgan.token(
  'Request-Id',
  (_req: express.Request): any =>
    _req.headers['request-id']
);

export const accessLogMiddleware = morgan(
  '[:date[iso]] :remote-addr ":method :url HTTP/:http-version" :status :res[content-length] :response-time ms ":user-agent" ":referrer"',
  { stream: accessLogStream },
);

export default logger;
