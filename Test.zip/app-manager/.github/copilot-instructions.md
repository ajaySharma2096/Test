# GitHub Copilot Instructions

Use `AGENTS.md` at the repository root as the canonical source of truth for this codebase.

For detailed guidance, follow links from `AGENTS.md` into `docs/ai/`.

If there is any conflict:

1. Follow explicit user chat instructions
2. Then follow this file
3. Then follow `AGENTS.md`

Bridge rule:

- Keep this file minimal and avoid duplicating repo rules here.
