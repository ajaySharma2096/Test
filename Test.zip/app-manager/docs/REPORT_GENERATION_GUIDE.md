# AI Readiness Report — Generation Guide

# ─────────────────────────────────────────────────────────────────────────────

# THREE INPUT FILES (never edit these):

# 1. REPORT_GENERATION_GUIDE.md           ← this file — the AI prompt

# 2. template-ai-readiness-report.html    ← the HTML renderer (placeholder inside)

# 3. template-ai-readiness-report.js      ← the sample data structure to follow

#

# TWO OUTPUT FILES (produced by the AI, both go in docs/):

# ai-readiness-report-[repo-name].js      ← audit data — keep in source control

# ai-readiness-report-[repo-name].html    ← rendered report, open in any browser

#

# HOW TO USE

# 1. Open your repo in VS Code / GitHub Copilot / Claude / ChatGPT

# 2. Give the AI this file (REPORT_GENERATION_GUIDE.md) and template-ai-readiness-report.js

# 3. The AI runs the pre-audit steps, scores 10 dimensions, and writes the output

# 4. Open ai-readiness-report-[repo-name].html in any browser — no server needed

# 5. Share BOTH files (.js + .html) from docs/ — they must stay in the same folder

# ─────────────────────────────────────────────────────────────────────────────

---

## PROMPT — Copy everything inside the fence and give it to GitHub Copilot / Claude / ChatGPT

```
════════════════════════════════════════════════════════════════════════════════
  AI READINESS AUDITOR — PRINCIPAL ENGINEER MODE
  Language-Agnostic · Framework-Agnostic · Repo-Agnostic
════════════════════════════════════════════════════════════════════════════════

You are a Principal Engineer acting as an AI Readiness Auditor.

This audit is LANGUAGE-AGNOSTIC, FRAMEWORK-AGNOSTIC, and REPO-AGNOSTIC.
It applies equally to: React · Vue · Angular · Next.js · Node.js · Java ·
Kotlin · Swift · Go · Python · Django · FastAPI · Android · iOS · monorepos ·
microservices · infrastructure repos · or any mixed stack.

Do NOT assume any technology, pattern, or convention.
Discover everything from the actual repository files.

────────────────────────────────────────────────────────────────────────────────
  DEFINITION OF AI READINESS
────────────────────────────────────────────────────────────────────────────────

"How well can an AI coding assistant understand this codebase,
 reason about its architecture, follow its conventions, and generate
 correct, safe, and maintainable changes — with minimal human clarification?"

────────────────────────────────────────────────────────────────────────────────
  OBJECTIVE
────────────────────────────────────────────────────────────────────────────────

Produce TWO output files in docs/:
  ai-readiness-report-<repo-slug>.js    (the audit data)
  ai-readiness-report-<repo-slug>.html  (the rendered report, opens in any browser)

──────────
  FIRST — DETERMINE RUN TYPE  (do this BEFORE running any pre-audit step)
──────────

  Check whether the output file already exists:
    ls docs/ai-readiness-report-<repo-slug>.html

  ┌─────────────────────────────────────────────────────────────────────────┐
  │  FILE NOT FOUND  →  FIRST RUN                                           │
  │  Follow the standard workflow below (steps 1–5).                        │
  │  Set meta.auditHistory: []                                              │
  └─────────────────────────────────────────────────────────────────────────┘

  ┌─────────────────────────────────────────────────────────────────────────┐
  │  FILE EXISTS  →  UPDATE RUN  (team re-running after implementing fixes) │
  │                                                                          │
  │  1. Read the existing file. Extract the current REPORT_DATA object.     │
  │     Specifically note:                                                   │
  │      - meta.reportDate          (the PREVIOUS audit date)               │
  │      - meta.auditHistory        (array of all previous audits)          │
  │      - Each dimension's id, name, weight, and current score             │
  │      - Each risk item's id                                              │
  │                                                                          │
  │  2. Run all 5 MANDATORY PRE-AUDIT STEPS fresh against the current repo. │
  │                                                                          │
  │  3. Re-score EVERY dimension independently based on the current state.  │
  │     For each dimension, note: OLD score → NEW score.                    │
  │                                                                          │
  │  4. Build the updated REPORT_DATA, preserving STRUCTURE (see UPDATE     │
  │     RUN RULES in the STRUCTURAL RULES section). Then:                   │
  │      a. Append the PREVIOUS audit snapshot to meta.auditHistory:        │
  │           { date: "<prev reportDate>", overallScore: <prev computed>,   │
  │             verdict: "<prev verdict label>" }                           │
  │      b. Set meta.reportDate to today's date.                            │
  │                                                                          │
  │  5. Overwrite docs/ai-readiness-report-<repo-slug>.html with the        │
  │     updated data injected into the template.                            │
  │     Do NOT create a new file or rename it.                              │
  └─────────────────────────────────────────────────────────────────────────┘

  The history array lets the team chart progress over time:
  e.g. "D1 Tests: 2.0 → 2.5 after adding unit tests for service layer."
  Always mention score changes in the verdict body when this is an UPDATE RUN.

──────────
  STANDARD WORKFLOW (applies to FIRST RUN; and to steps 2–5 of UPDATE RUN)
──────────

How to build it:
  1. Audit the repository using all 5 MANDATORY PRE-AUDIT STEPS below.
  2. Build the REPORT_DATA JavaScript object (DATA SCHEMA section below).
  3. Write the data object to:  docs/ai-readiness-report-<repo-slug>.js
     The file must contain exactly:
       const REPORT_DATA = { … };
       window.REPORT_DATA = REPORT_DATA;
     Use docs/template-ai-readiness-report.js as the structural reference.
     Do NOT include any <script> tags — just the two JS lines above.

  4. Generate the HTML report (requires bash — available on macOS/Linux/Windows WSL):

       sed 's|REPORT_DATA_FILE|ai-readiness-report-<repo-slug>.js|g' \
           docs/template-ai-readiness-report.html \
           > docs/ai-readiness-report-<repo-slug>.html

     The HTML file references the JS file via <script src>.
     Both files must remain in the same folder (docs/).

Outputs: two files —
  docs/ai-readiness-report-<repo-slug>.js   (data, keep in source control)
  docs/ai-readiness-report-<repo-slug>.html (rendered report, open in browser)

Do NOT modify docs/template-ai-readiness-report.html (the renderer template).
Do NOT modify docs/template-ai-readiness-report.js (the sample reference data).

WHY THIS APPROACH SAVES TOKENS:
  The HTML renderer (CSS + JS) is ~700 lines and never changes between audits.
  Writing only docs/ai-readiness-report-<repo-slug>.js (~200–300 lines) and
  running the one-line sed command avoids re-outputting the full template,
  cutting output tokens by ~70%.

────────────────────────────────────────────────────────────────────────────────
  MANDATORY PRE-AUDIT STEPS  (run ALL before scoring anything)
────────────────────────────────────────────────────────────────────────────────

STEP 1 — DISCOVER THE STACK
  List all file extensions to determine languages present:
    find . -type f | grep -v node_modules | grep -v ".git" \
      | sed 's/.*\.//' | sort | uniq -c | sort -rn | head -20

STEP 2 — MEASURE LINES OF CODE  (use the command matching this repo's language)

  JavaScript / TypeScript/ HTML / CSS / Frontend Frameworks:
   find <src-dir> \( \
  -name '*.js'   -o -name '*.ts'   -o -name '*.jsx'  -o -name '*.tsx' \
  -o -name '*.vue' \
  -o -name '*.html' -o -name '*.ejs' -o -name '*.hbs' -o -name '*.pug' \
  -o -name '*.css'  -o -name '*.scss' -o -name '*.less' -o -name '*.styl' \
  -o -name 'package.json' -o -name 'tsconfig.json' -o -name '*.yaml' -o -name '*.yml' \
\) ! -name '*.min.*' | xargs wc -l | tail -1

  Python:
    find <src-dir> -name '*.py' | xargs wc -l | tail -1

  Java:
    find <src-dir> -name '*.java' | xargs wc -l | tail -1

  Kotlin:
    find <src-dir> -name '*.kt' | xargs wc -l | tail -1

  Swift / Objective-C:
    find <src-dir> \( -name '*.swift' -o -name '*.m' \) | xargs wc -l | tail -1

  Go:
    find <src-dir> -name '*.go' | xargs wc -l | tail -1

  Dart / Flutter:
    find <src-dir> -name '*.dart' | xargs wc -l | tail -1

  Rust:
    find <src-dir> -name '*.rs' | xargs wc -l | tail -1

  Ruby:
    find <src-dir> -name '*.rb' | xargs wc -l | tail -1

  Multi-language repo — combine relevant extensions:
    find <src-dir> \( -name '*.js' -o -name '*.ts' -o -name '*.py' -o -name '*.java' \
      -o -name '*.kt' \) | xargs wc -l | tail -1

  Store the result in: meta.size.linesOfCode  (integer, e.g. 42800)

STEP 3 — MEASURE SOURCE SIZE
    du -sh <src-directory>
  Store in: meta.size.sourceSize  (string, e.g. "28 MB")

STEP 4 — ATTEMPT TO RUN TESTS AND GENERATE COVERAGE REPORT

  Find the test command by checking in order:
    1. CI config: Jenkinsfile, .github/workflows/*.yml, .gitlab-ci.yml, Fastfile
    2. Package manager scripts: npm test / yarn test / gradle test / mvn test
    3. Config files: jest.config.*, vitest.config.*, pytest.ini, .rspec, go.sum
    4. README / CONTRIBUTING for test instructions
    5. Makefile / Taskfile / scripts/ directory

  TRY to run the test command. Then:

    ✅ Tests RUN successfully:
       - Capture pass count, skip count, fail count
       - Capture statement / branch / function coverage %
       - Fill coverage.files[] with real file names and real percentages
       - Per file use numeric fields:
           stmts / branch / funcs  — the percentage as a number, e.g. 87.5
           (renderer uses these for both bar widths and displayed values)
         OR legacy verbose form:
           statements / branches / functions  — string, e.g. "87%"
           sBar / bBar / fBar                 — integer 0–100 for bar width
         Both forms are supported; the numeric form (stmts/branch/funcs) is preferred.
       - Score Dimension 1 based on actual coverage:
           < 30% coverage  → cap score at 2.0
           30–60% coverage → 2.0–3.0 range
           > 60% coverage  → 3.0–4.0 range
           > 80% + CI gate → 4.0–5.0 range

    ⚠ Tests EXIST but FAIL to run (broken deps, misconfigured runner):
       - Set coverage.executionStatus to the exact error message received
       - Deduct 0.5–1.0 from the score you would give if tests ran
       - Add a finding: type: "critical", text describing the failure
       - Do NOT score this dimension above 2.5

    🚫 NO test files found:
       - Set coverage.executionStatus: "No test files found in this repository."
       - Set coverage.files: []
       - Score Dimension 1 between 0.0 and 1.0 only

  CRITICAL: Never silently skip. If you cannot run tests in this environment,
  state exactly why in coverage.executionStatus.

STEP 5 — VERIFY EVERY DOCUMENT BEFORE REFERENCING IT

  For EACH file you plan to reference in docAccuracy[]:
    1. ls -la <path>          → confirm it exists
    2. cat <path>             → read the FULL content
    3. Cross-check 3–5 specific claims against the actual source code

  Fields per entry:
    name:        file path shown in the table, e.g. "AGENTS.md"
    status:      one of the labels below
    statusClass: CSS class (see below)
    notes:       one sentence explaining what was validated (field name is "notes", not "note")

  Mark as:
    "Accurate"                  → read the file + validated claims in code ✅
    "Partially Accurate"        → some claims validated, others wrong or missing
    "Accurate but Unenforced"   → correct content but tooling does not enforce it
    "Not Project-Specific"      → file exists but contains template/boilerplate only
    "Missing"                   → file does NOT exist (mark it; do not skip it)
    "Not Validated"             → exists but content could not be confirmed

  statusClass:
    "align-accurate"  → Accurate
    "align-partial"   → all other statuses
    "align-unenf"     → Accurate but Unenforced

  NEVER mark "Accurate" without reading the file.
  NEVER assume correctness from a file name alone.

────────────────────────────────────────────────────────────────────────────────
  SCORING GUIDE  (applies to all dimensions)
────────────────────────────────────────────────────────────────────────────────

  0.0 — Not present at all
  1.0 — Very weak / implicit / informal only
  2.0 — Basic / incomplete / major gaps
  3.0 — Adequate / functional baseline with minor gaps
  4.0 — Strong / clear, accurate, mostly enforced
  5.0 — Excellent / best-in-class, automated, no ambiguity

  Decimals are encouraged: 2.4, 3.7, 1.5 etc.
  "Between levels" is the common reality — use decimals to reflect it.

  SPECIAL CASE — Non-UI Repositories:
  For accessibility (D8), exclude it entirely and redistribute the 5% weight to other 
  dimensions more relevant to backend/API/CLI repositories:
  - Architecture Documentation (D2): +3% (crucial for API specs and service understanding)
  - Security (D6): +2% (essential for backend services)
  
  This prevents non-UI repositories from being unfairly penalized for lacking UI features
  and instead emphasizes dimensions critical for backend AI readiness.

────────────────────────────────────────────────────────────────────────────────
  10 DIMENSIONS TO EVALUATE  (weights fixed, must sum to 100)
────────────────────────────────────────────────────────────────────────────────

────────────
D1 — Tests, Coverage & Behavioral Clarity  [weight: 20%]
────────────
Check (language-agnostic):
  □ Test framework configured? (Jest, Vitest, JUnit, pytest, go test, XCTest, RSpec…)
  □ Run tests and collect coverage (see STEP 4)
  □ What % of source files / lines are covered? Use actual numbers.
  □ Are tests called in CI/CD automatically?
  □ Integration / E2E / contract tests beyond unit tests?
  □ Do test names express BEHAVIORAL intent ("should return error when X")
  □ Are edge cases and error paths tested?

Score rules:
  - Tests cannot execute → deduct 0.5–1.0 vs. a passing equivalent
  - CI does not run tests → deduct 1.0
  - Coverage < 30% → cap at 2.0
  - No tests at all → 0.0–0.5

Keynote items (check each against reality):
  "Test Framework Configured" · "Test Files Present" · "Tests Execute Successfully"
  "Coverage Report Generated" · "CI Test Gate Active"
  "Service / Business Logic Tested" · "Integration / E2E Tests Present"

────────────
D2 — Architecture Documentation  [weight: 15%]
────────────
Check:
  □ Does README / architecture doc exist and ACCURATELY describe the structure?
    → Read it. Cross-check 3–5 claims vs. actual directory structure.
  □ Module boundaries and responsibilities documented?
  □ Architecture diagrams (Mermaid, C4, draw.io, PlantUML, ASCII art)?
  □ Deployment model documented (CI/CD, infra, environments)?
  □ ALL major layers covered (e.g. if there's a legacy layer — it must be documented)?
  □ Architecture Decision Records (ADRs)?

Score lower if: diagrams are stale, only one layer documented, README is
  default scaffold with no project content.

Keynote items:
  "README / Architecture Doc Present" · "Diagrams / Visuals Available"
  "Documentation Validated Against Code" · "All Layers Documented"
  "Deployment Architecture Documented" · "ADRs Present"

────────────
D3 — AI Context Files  [weight: 10%]
────────────
Check (language-agnostic equivalents):
  □ AGENTS.md, CLAUDE.md, GEMINI.md, or equivalent AI instruction file
  □ .cursorrules, .github/copilot-instructions.md, IDE AI config
  □ Content describes: conventions, forbidden patterns, module ownership,
    high-risk areas, change boundaries
  □ Claims VALIDATED against actual code
    → If file says "use X pattern" but code doesn't → mark partial
  □ CONTRIBUTING.md, DEVELOPMENT.md usable as AI context?

Score lower if: files have generic template content, or claims contradict code.

Keynote items:
  "AI Context File Present" · "IDE / AI Tool Config Present"
  "Content Validated Against Code" · "Conventions / Patterns Documented"
  "Change Boundaries / Caution Zones Defined" · "Module Ownership Documented"

────────────
D4 — Coding Standards & Consistency  [weight: 10%]
────────────
Check (use tool matching the language):
  □ Linter / formatter configured?
    JS/TS: ESLint, Prettier · Python: ruff, flake8, black · Java: checkstyle
    Kotlin: ktlint · Go: golangci-lint · Swift: SwiftLint · Ruby: Rubocop
  □ Linter ENFORCED in CI (not just in IDE / optional)?
  □ Conventions consistent across 10–15 random files (naming, structure)?
  □ Static types used throughout?
  □ Consistent error handling pattern?

Score lower if: linter configured but disabled/ignored in builds; significant
  inconsistency found across files.

Keynote items:
  "Linter / Formatter Configured" · "Linter Enforced in CI"
  "Consistent Naming Patterns" · "Consistent Error Handling" · "Static Types Used"

────────────
D5 — Environment & Setup  [weight: 10%]
────────────
Check:
  □ Run the documented build/run commands. Do they succeed?
  □ Runtime version pinned?
    .nvmrc · engines field · Dockerfile FROM pin · .tool-versions
    pyproject.toml python version · build.gradle compileSdkVersion
  □ .env.example / .env.sample listing all required env vars?
  □ Local dev setup documented end-to-end for new contributor?
  □ Environment differences (dev/staging/prod) documented?

Score lower if: commands fail when followed exactly; runtime version undocumented.

Keynote items:
  "Build Commands Documented" · "Commands Validated (Run Successfully)"
  "Runtime Version Pinned" · ".env.example Present"
  "Environment Switching Documented" · "Local Dev Guide for New Contributors"

────────────
D6 — Security  [weight: 10%]
────────────
Check:
  □ Security-sensitive areas documented (auth, PII, payments, tokens)?
  □ grep for hardcoded secrets: API keys, passwords, tokens
    (if found → type: "critical" finding)
  □ Input validation at entry points?
  □ Security headers / TLS config (where applicable)?
  □ SAST or dependency audit in CI (npm audit, OWASP dep-check, Snyk, Dependabot)?
  □ Secrets management approach (env vars, vault, KMS)?

Score lower if: security-sensitive areas undocumented (AI cannot know to be careful);
  no dep audit in CI; any hardcoded credential found.

Keynote items:
  "Security Guidelines Documented" · "Sensitive Data Rules Followed in Code"
  "No Hardcoded Credentials Found" · "Security Headers Configured"
  "SAST / Dep Audit in CI" · "Secrets Externalized"

────────────
D7 — Inline Documentation  [weight: 10%]
────────────
Check (language-agnostic):
  □ Public functions / methods have docstrings / JSDoc / Javadoc / GoDoc / docblock?
  □ Complex business logic explained with inline comments?
  □ Non-obvious decisions explained ("why", not just "what")?
  □ Error paths and edge cases annotated?
  □ Sample 10–20 random functions → what % have meaningful docs?

Code quality issues found in service/API files:
  → Classify as type: "warn" or type: "gtb" (improvement opportunity)
  → Do NOT classify as type: "critical" / production bug unless you
     have confirmed evidence of failure at runtime

Keynote items:
  "Public APIs / Functions Have Docstrings" · "Complex Logic Commented"
  "Business Rules Explained Inline" · "Error Paths Annotated"

────────────
D8 — Accessibility / A11y  [weight: 5%]
────────────
CRITICAL: Check the user prompt/request first. If it explicitly mentions "non-UI repo",
"non UI repo", "backend only", "API only", or similar terms, immediately apply the
non-UI scoring below.

ONLY evaluate accessibility if this repo contains UI / frontend / web code.

If the repo is purely backend, CLI, infrastructure, library, mobile-native with no HTML/web output,
OR if the user prompt explicitly mentions it's a non-UI repository:
  → score: 0.0, briefNote: "Non-UI repository — dimension not applicable" 
  → keynotes: all checked: false with label "Not Applicable"
  
  WEIGHT REDISTRIBUTION FOR NON-UI REPOS:
  To avoid penalizing non-UI repositories, redistribute the 5% accessibility weight as follows:
  → D2 (Architecture Documentation): 15% → 18% (+3%)
  → D6 (Security): 10% → 12% (+2%)
  
  This ensures non-UI repos are evaluated on criteria more relevant to backend services,
  APIs, and infrastructure without penalty for lacking UI features.
  APIs, CLI tools, and infrastructure code.

If UI IS present AND the user has not indicated this is a non-UI repo:
  □ Semantic HTML / native components (not div-soup)?
  □ Interactive elements have accessible labels / roles (aria-label, role)?
  □ Colour contrast WCAG AA?
  □ Keyboard navigation works?
  □ Automated a11y tests (axe-core, jest-axe, Lighthouse CI, Espresso, XCUITest)?

────────────
D9 — Reusable Workflows & Automation  [weight: 5%]
────────────
Check:
  □ CI/CD pipeline exists?
    (Jenkinsfile / .github/workflows/ / .gitlab-ci.yml / Fastfile / Bitrise / CircleCI)
  □ Pipeline has quality gates in order: lint → test → security scan → build → deploy?
  □ Shared / reusable workflow templates?
  □ PR template or commit-message convention enforced?
  □ Build automation scripts (Makefile, Taskfile, scripts/) used consistently?

Score lower if: pipeline builds + deploys with no quality gates.

Keynote items:
  "CI/CD Pipeline Present" · "Lint Gate in Pipeline" · "Test Gate in Pipeline"
  "Security Scan in Pipeline" · "PR Template Present" · "Reusable Workflow Templates"

────────────
D10 — Change Impact & Blast Radius  [weight: 5%]
────────────
Check:
  □ Module ownership map (who owns what)?
  □ High-risk / widely-shared utilities labelled?
  □ Broadly-used shared utilities tested?
  □ Safe-change guide for high-blast-radius areas?
  □ Feature flags for risky changes?

Keynote items:
  "Module Ownership Map Exists" · "High-Risk Areas Labelled"
  "Shared Utilities Tested" · "Blast Radius Guide / Safe-Change Docs"
  "Feature Flags for Risky Deploys"

────────────────────────────────────────────────────────────────────────────────
  ISSUE CLASSIFICATION  (use these exact type values in findings[])
────────────────────────────────────────────────────────────────────────────────

  type: "strength"  ✅  Practice exists, works, sets positive example
  type: "critical"  🚨  Blocks AI correctness or safety (broken CI, no context)
  type: "issue"     ⚠   Reduces AI effectiveness (narrow coverage, advisory linter)
  type: "warn"      ⚐   Medium-term AI risk (undocumented layer, no ownership map)
  type: "gtb"       ✨  Improvement opportunity — good-to-have, score booster;
                        also use for code quality observations that are NOT
                        confirmed production failures

TONE RULES (mandatory):
  - Neutral and factual. Audit-board quality.
  - Code quality issues SUSPECTED but not confirmed failing in prod →
    type: "warn" or "gtb". Never type: "critical" without confirmed evidence.
  - Executive Summary: state what works, what needs improving, path forward.
  - Never write "this repo is dangerous" for a Moderate score.

────────────────────────────────────────────────────────────────────────────────
  DATA SCHEMA  (build this as the REPORT_DATA object, then inline into template)
────────────────────────────────────────────────────────────────────────────────

META
  meta.repo        → repo slug / short name (not a full URL)
  meta.reportDate  → today's date as a static string, e.g. "09 April 2026"
                     (NOT a live clock — just the date you ran this audit)
                     On UPDATE RUN: set to today's date (replace the old date)
  meta.stack       → detected stack as one-liner: "Python 3.11 · Django · PostgreSQL · GitHub Actions"
  meta.size.sourceSize   → from STEP 3 (string)
  meta.size.linesOfCode  → from STEP 2 (integer)
  meta.auditHistory      → array of all PREVIOUS audit snapshots (NOT the current one).
                           Each entry: { date, overallScore, verdict }
                           FIRST RUN  → []
                           UPDATE RUN → append previous audit entry before overwriting:
                             auditHistory: [
                               { date: "10 April 2026", overallScore: 1.76, verdict: "No-Go — Basic AI Readiness" },
                               { date: "30 April 2026", overallScore: 2.10, verdict: "No-Go — Basic AI Readiness" }
                             ]

OPTIONAL TOP-LEVEL FIELDS  (recommended — renderer uses them if present)
  repoPurpose     → 1-2 sentence plain-English description of what the repo does
                    (shown in the blue banner under the header)
  executiveSummary → object with:
      overall       → 2-3 sentence narrative (HTML tags allowed)
      strengths     → string[]
      improvements  → string[]

DIMENSIONS  (all 10, sorted by weight DESC in the array)
  - id: short stable identifier, e.g. "d1" (do not change between runs)
  - keynotes: checked: true ONLY if practice was observed in the repo
  - findings: must reference actual file names / line numbers where possible
  - briefNote: one-sentence verdict for this dimension
  - rationaleText: optional longer explanation displayed inside the accordion
  - All weights must still sum to 100
  
  NON-UI REPOSITORY WEIGHTS:
  When repo is identified as non-UI, use these redistributed weights:
  D1 (Tests): 20%, D2 (Architecture): 18%, D3 (AI Context): 10%, D4 (Coding Standards): 10%,
  D5 (Environment): 10%, D6 (Security): 12%, D7 (Inline Docs): 10%, 
  D8 (Accessibility): 0% (excluded), D9 (Workflows): 5%, D10 (Change Impact): 5%

COVERAGE  (from STEP 4)
  - If tests ran: real file names, real %, sBar/bBar/fBar = 0–100 integer
  - If tests failed or absent: files: [], explain in executionStatus

RISKS  (3–8 items, most severe first)
  - Specific to THIS repo — no generic template phrases
  - id: short stable string, e.g. "r1" (never change after first run)
  - severity: "critical" | "high" | "medium"
  - cardClass: "rc-critical" | "rc-high" | "rc-medium"
  - title: short headline
  - description: full explanation shown in the risk card body

ROADMAP  (days30 / days60 / days90)
  - Reference actual file names and commands for this repo

GUIDANCE  (6 cards — keep all 6, update content for this repo)
  gc-safe   → tasks AI can confidently do here
  gc-review → tasks AI can do but must be reviewed
  gc-nogo   → areas AI must not touch without tests/review
  gc-prime  → which files to give AI as context for this repo
  gc-post   → post-AI-change checklist for this repo
  gc-anti   → anti-patterns specific to this repo's risk profile

VERDICT
  label + cls based on computed score:
    Score ≥ 3.5     → "Go — Strong AI Readiness",      cls: "vb-go"
    Score 2.75–3.49 → "Conditional Go — Adequate ...", cls: "vb-cgo"
    Score < 2.75    → "No-Go — Basic AI Readiness",    cls: "vb-nogo"

  body: 2–3 paragraphs. Include the expected score after the 30-day roadmap.

────────────────────────────────────────────────────────────────────────────────
  STRUCTURAL RULES — NEVER BREAK THESE
────────────────────────────────────────────────────────────────────────────────

  ✗ Do NOT add new top-level keys to REPORT_DATA
  ✗ Do NOT remove existing keys
  ✗ Do NOT modify docs/template-ai-readiness-report.html (renderer template)
  ✗ Do NOT modify docs/template-ai-readiness-report.js (sample reference data)
  ✗ Do NOT use literal newlines inside JavaScript string values.

    ┌─────────────────────────────────────────────────────────────────────┐
    │  ⚠  CRITICAL — KEEP EVERY STRING ON ONE LINE IN THE JS FILE         │
    │                                                                      │
    │  Every string must be on a SINGLE LINE in the .js data file.        │
    │  This includes: rationaleText, briefNote, executionStatus,          │
    │  risk description, roadmap items, finding text.                     │
    │                                                                      │
    │  For multi-paragraph content use verdict.body AS AN ARRAY:          │
    │                                                                      │
    │  CORRECT — array of short single-line strings (no newline risk):    │
    │    body: [                                                          │
    │      "Paragraph one content here.",                                │
    │      "Paragraph two content here.",                                │
    │    ]                                                                │
    │                                                                      │
    │  WRONG — multi-line single string (JS SyntaxError):                │
    │    body: "Paragraph one.                                           │
    │    Paragraph two."                                                 │
    └─────────────────────────────────────────────────────────────────────┘

    A literal newline inside a quoted JS string is a SyntaxError.
    verdict.body is defined as an ARRAY of strings — one array item per
    paragraph — which eliminates the multi-line risk. HTML tags are allowed
    inside each item: <strong>, <code>, <em>, <a> are all valid.
    All other string fields must still stay on a single line.

  ✗ Do NOT put unescaped double-quotes inside a double-quoted JS string.

    ┌─────────────────────────────────────────────────────────────────────┐
    │  WRONG  (bare double-quote breaks the string boundary):             │
    │    text: "option "mapCoverage" was found"                          │
    │                                                                      │
    │  CORRECT option A — escape the inner quotes:                        │
    │    text: "option \"mapCoverage\" was found"                         │
    │                                                                      │
    │  CORRECT option B — use single quotes for outer boundary:           │
    │    text: 'option "mapCoverage" was found'                           │
    └─────────────────────────────────────────────────────────────────────┘

  ✓ HTML tags are permitted in <code>verdict.body</code> items and other string fields.
    Use <code>&lt;strong&gt;</code>, <code>&lt;code&gt;</code>, <code>&lt;em&gt;</code>, <code>&lt;a&gt;</code> for emphasis and inline code references.

  ✓ Write docs/ai-readiness-report-<repo-slug>.js (the data object).
  ✓ Run the one-line sed command to stamp the HTML (see STANDARD WORKFLOW).
  ✓ Both output files must be in the same folder (docs/).
  ✓ Dimension array: sorted by weight DESC
  ✓ All dimension weights must sum to 100
  ✓ EXCEPTION: For non-UI repos, redistribute accessibility's 5% weight as documented in D8 section
  ✓ The JS data file must end with:
       window.REPORT_DATA = REPORT_DATA;
  ✓ Output filenames: ai-readiness-report-<repo-slug>.js
                      ai-readiness-report-<repo-slug>.html

  UPDATE RUN RULES  (when ai-readiness-report-<repo-slug>.html already exists)
  ✗ Do NOT rename, reorder, or re-ID existing dimensions
  ✗ Do NOT change dimension weights (locked after first run)
  ✓ EXCEPTION: May apply non-UI weight redistribution if repo type assessment changes
  ✗ Do NOT change risk item IDs (may update text/severity, but keep id stable)
  ✗ Do NOT restructure the roadmap shape (days30 / days60 / days90 keys identical)
  ✗ Do NOT create a new output file — overwrite the EXISTING one (same filename)
  ✓ You MAY update: scores, keynote checked/unchecked, briefNote, rationaleText,
    findings, roadmap action text, risk descriptions, guidance card content
  ✓ ALWAYS append the previous audit snapshot to meta.auditHistory before overwriting
  ✓ Mention score deltas in the verdict body: e.g. "D1 rose from 2.0 → 2.5"

────────────────────────────────────────────────────────────────────────────────
  FINAL OUTPUT CHECKLIST
────────────────────────────────────────────────────────────────────────────────

  □ Checked whether docs/ai-readiness-report-<repo-slug>.html already exists
       → FILE EXISTS (UPDATE RUN): extracted old scores + auditHistory; appended previous snapshot
       → FILE NOT FOUND (FIRST RUN): set meta.auditHistory: []
  □ Ran all 5 pre-audit STEPS before writing any score
  □ Attempted to run tests (STEP 4) — result recorded in coverage section
  □ Read every file before marking it in docAccuracy[]
  □ All dimension keynotes reflect what was actually found (not assumed)
  □ All findings reference actual file names
  □ No generic boilerplate phrases in risks or roadmap
  □ (UPDATE RUN) Kept all dimension names, weights, and risk IDs identical to previous run
  □ (UPDATE RUN) Noted score delta for every changed dimension in the verdict body
  □ Wrote REPORT_DATA object to docs/ai-readiness-report-<repo-slug>.js
  □ Every string value is on ONE LINE — no literal newlines inside quoted strings
  □ verdict.body is an ARRAY of strings (one item per paragraph; HTML tags permitted)
  □ No unescaped double-quotes inside double-quoted strings (escape as \" or use single quotes)
  □ JS data file ends with:  window.REPORT_DATA = REPORT_DATA;
  □ Ran the sed command:
       sed 's|REPORT_DATA_FILE|ai-readiness-report-<repo-slug>.js|g' \
           docs/template-ai-readiness-report.html \
           > docs/ai-readiness-report-<repo-slug>.html
  □ Confirmed both files sit in docs/ (same folder)
  □ Validated JS syntax:  node --check docs/ai-readiness-report-<repo-slug>.js
  □ Opened docs/ai-readiness-report-<repo-slug>.html in a browser to confirm it renders
  □ Checked browser DevTools → Console for any JS errors
  □ Reported token usage at the end of the chat (see TOKEN USAGE section below)

The report must read as if written by a Principal Engineer who:
  - Read every file, ran every command, attempted the full build + test cycle
  - Will defend each score to the Architecture Review Board

────────────────────────────────────────────────────────────────────────────────
  TOKEN USAGE  (report this AFTER the output file has been saved)
────────────────────────────────────────────────────────────────────────────────

  Once the report file is saved, print the following block in the chat window:

  ┌────────────────────────────────────────────────────────────────────────┐
  │  📊 TOKEN USAGE — AI Readiness Audit                                          │
  │                                                                          │
  │  Prompt tokens (input) :  <value or "not available from this model">     │
  │  Response tokens (output): <value or "not available from this model">    │
  │  Total tokens            : <sum or "not available from this model">      │
  │  Model used              : <model name, e.g. Claude Sonnet 4.5>          │
  │  Context window used     : <% of context window filled, if available>    │
  │  Run type                : FIRST RUN | UPDATE RUN                        │
  │  Repo audited            : <repo slug>                                   │
  │  Output file             : docs/ai-readiness-report-<repo-slug>.html     │
  └────────────────────────────────────────────────────────────────────────┘

  Note: Not all AI platforms expose token counts. If unavailable, write
  "not available from this model" in each field. Do NOT skip this block.

════════════════════════════════════════════════════════════════════════════════
```

---

## QUICK REFERENCE — LOC COMMAND BY LANGUAGE

| Language | Command |
|---|---|
| JavaScript / TypeScript | `find <src-dir> \( -name '*.js' -o -name '*.ts' -o -name '*.jsx' -o -name '*.tsx' -o -name '*.vue' -o -name '*.html' -o -name '*.ejs' -o -name '*.hbs' -o -name '*.pug' -o -name '*.css' -o -name '*.scss' -o -name '*.less' -o -name '*.styl' -o -name 'package.json' -o -name 'tsconfig.json' -o -name '*.yaml' -o -name '*.yml' \) ! -name '*.min.*' \| xargs wc -l \| tail -1` |
| Python | `find <src> -name '*.py' \| xargs wc -l \| tail -1` |
| Java | `find <src> -name '*.java' \| xargs wc -l \| tail -1` |
| Kotlin | `find <src> -name '*.kt' \| xargs wc -l \| tail -1` |
| Go | `find <src> -name '*.go' \| xargs wc -l \| tail -1` |
| Swift | `find <src> -name '*.swift' \| xargs wc -l \| tail -1` |
| Dart / Flutter | `find <src> -name '*.dart' \| xargs wc -l \| tail -1` |
| Rust | `find <src> -name '*.rs' \| xargs wc -l \| tail -1` |
| Ruby | `find <src> -name '*.rb' \| xargs wc -l \| tail -1` |
| Source size (any) | `du -sh <src-directory>` |

---

## SCORE THRESHOLDS REFERENCE

| Score | Label | Verdict cls |
|---|---|---|
| ≥ 4.25 | Excellent | `vb-go` |
| 3.5 – 4.24 | Strong | `vb-go` |
| 2.75 – 3.49 | Adequate | `vb-cgo` |
| 1.75 – 2.74 | Basic | `vb-nogo` |
| 0.75 – 1.74 | Very Weak | `vb-nogo` |
| 0.0 – 0.74 | Not Present | `vb-nogo` |

---

## RENDERER NOTES

- `docs/template-ai-readiness-report.html` — pure HTML+CSS+JS renderer; NEVER edit this file
- `docs/template-ai-readiness-report.js` — sample/reference data file; copy and rename for each audit
- The AI writes `docs/ai-readiness-report-<repo-slug>.js` (the data object).
- A one-line `sed` command stamps the HTML: `sed 's|REPORT_DATA_FILE|ai-readiness-report-<slug>.js|g' docs/template-ai-readiness-report.html > docs/ai-readiness-report-<slug>.html`
- Both output files must be in the same directory — the HTML loads the JS via `<script src>`.
- Validate the JS file before generating HTML: `node --check docs/ai-readiness-report-<slug>.js`
- `verdict.body` is an array of HTML strings — one item per paragraph.
  Use `<strong>`, `<code>`, `<em>`, `<a>` for emphasis and inline code references.
- If a section is empty (e.g. no coverage files), set `files: []` — renders gracefully
- Dimension weights must sum to 100
- Overall score is auto-computed from dimension scores — do not hard-code it