/**
 * template-ai-readiness-report.js
 * ────────────────────────────────
 * SAMPLE / REFERENCE data file for the AI Readiness Report.
 *
 * HOW TO USE
 * ──────────
 * 1. Copy this file and rename it:
 *      ai-readiness-report-<repo-slug>.js
 *
 * 2. Replace ALL values below with real findings from your audit.
 *
 * 3. Copy the template HTML and wire up the reference:
 *      sed 's|REPORT_DATA_FILE|ai-readiness-report-<repo-slug>.js|g' \
 *          docs/template-ai-readiness-report.html \
 *          > docs/ai-readiness-report-<repo-slug>.html
 *
 * 4. Open docs/ai-readiness-report-<repo-slug>.html in a browser.
 *    Both files must sit in the same folder.
 *
 * RULES FOR STRING VALUES
 * ───────────────────────
 * • verdict.body must be an ARRAY of strings — one item per paragraph.
 *   Each item may contain HTML: <strong>, <code>, <a>, <em> are all valid.
 * • Other string fields (rationaleText, briefNote, finding text, etc.) may
 *   also include inline HTML where it aids readability.
 * • Every string must stay on ONE LINE in this file.
 *   Multi-sentence content is fine on one line; just do not press Enter
 *   inside a quoted string — that is a JavaScript SyntaxError.
 * • roadmap.days30 / days60 / days90 must be plain string ARRAYS.
 */

const REPORT_DATA = {

  /* ── 1. METADATA ─────────────────────────────────────────────── */
  meta: {
    repo: "my-repo",
    reportDate: "13 April 2026",
    stack: "React 18 · TypeScript · Jest · ESLint",
    size: {
      sourceSize: "8 MB",
      linesOfCode: 42000,
    },
    auditHistory: [],
  },

  /* ── 2. REPO PURPOSE (plain text) ────────────────────────────── */
  repoPurpose: "A sample repository used to demonstrate the AI Readiness Report template. Replace this with a concise description of what the real repo does and who consumes it.",

  /* ── 3. EXECUTIVE SUMMARY ────────────────────────────────────── */
  executiveSummary: {
    overall: "With a computed AI Readiness score of 1.95 / 5.0 (Basic), this repository is not yet suitable for broad AI-assisted development. Core tooling is in place but critical gaps in documentation, coverage, and CI formalisation prevent AI tools from reasoning safely about the codebase.",
    strengths: [
      "ESLint + Prettier + Husky pre-commit: every commit is type-checked and linted before it lands.",
      "TypeScript strict mode enforced across the entire codebase.",
      "No hardcoded credentials found — security hygiene is maintained in source files.",
    ],
    improvements: [
      "No AI context files: No <code>AGENTS.md</code>, no <code>copilot-instructions.md</code>. AI tools have zero repo-level conventions or caution-zone awareness.",
      "Test coverage is low: 35% statements across all files — recommended minimum is 60% for AI-safe development.",
      "No formal CI/CD pipeline — quality gates exist only via bypassable Husky hooks.",
      "Accessibility is near-absent in an application serving real users — no ARIA attributes, no automated a11y testing.",
    ],
  },

  /* ── 4. DIMENSIONS ───────────────────────────────────────────── */
  /*  Weights must sum to 100. Scores are 0 – 5.                   */
  dimensions: [
    {
      id: "d1",
      name: "Tests, Coverage & Behavioral Clarity",
      weight: 20,
      score: 2.5,
      briefNote: "Jest configured; basic coverage present; no E2E tests",
      rationaleText: "Jest is configured and all tests pass on a clean run. Overall statement coverage is 35%, below the recommended 60% threshold. No integration or E2E tests exist.",
      keynotes: [
        { label: "Test Framework Configured",          checked: true  },
        { label: "Test Files Present",                 checked: true  },
        { label: "Tests Execute Successfully",         checked: true  },
        { label: "Coverage Report Generated",          checked: true  },
        { label: "CI Test Gate Active",                checked: false },
        { label: "Service / Business Logic Tested",    checked: false },
        { label: "Integration / E2E Tests Present",    checked: false },
      ],
      findings: [
        { type: "strength", text: "Jest is configured and all tests pass on a clean run." },
        { type: "issue",    text: "Overall statement coverage is 35% — below the recommended 60% threshold for AI-safe development." },
        { type: "warn",     text: "No integration or E2E tests. AI-generated changes to multi-step flows cannot be regression-tested automatically." },
        { type: "gtb",      text: "Add coverage thresholds in <code>jest.config.js</code> (e.g. <code>statements: 60</code>) so CI fails when coverage drops." },
      ],
    },
    {
      id: "d2",
      name: "Architecture Documentation",
      weight: 15,
      score: 2.0,
      briefNote: "README present but no diagrams, no ADRs, no deployment docs",
      rationaleText: "README exists but covers only getting started. No module boundaries, data-flow diagrams, or layer responsibilities are documented. No ADRs exist.",
      keynotes: [
        { label: "README / Architecture Doc Present",       checked: true  },
        { label: "Diagrams / Visuals Available",            checked: false },
        { label: "Documentation Validated Against Code",    checked: false },
        { label: "All Layers Documented",                   checked: false },
        { label: "Deployment Architecture Documented",      checked: false },
        { label: "ADRs Present",                            checked: false },
      ],
      findings: [
        { type: "issue", text: "README exists but covers only getting started. No module boundaries, data-flow diagrams, or layer responsibilities are documented." },
        { type: "gtb",   text: "Create <code>docs/architecture.md</code> with an annotated directory tree and a short deployment model description." },
      ],
    },
    {
      id: "d3",
      name: "AI Context Files",
      weight: 10,
      score: 0.5,
      briefNote: "No AGENTS.md, no Copilot instructions, no CONTRIBUTING.md",
      rationaleText: "No <code>AGENTS.md</code>, <code>CLAUDE.md</code>, <code>.cursorrules</code>, or <code>.github/copilot-instructions.md</code> found. No <code>CONTRIBUTING.md</code>. AI tools have zero repo-level context.",
      keynotes: [
        { label: "AI Context File Present",                   checked: false },
        { label: "IDE / AI Tool Config Present",              checked: false },
        { label: "Content Validated Against Code",            checked: false },
        { label: "Conventions / Patterns Documented",         checked: false },
        { label: "Change Boundaries / Caution Zones Defined", checked: false },
        { label: "Module Ownership Documented",               checked: false },
      ],
      findings: [
        { type: "critical", text: "No <code>AGENTS.md</code>, <code>CLAUDE.md</code>, or <code>.github/copilot-instructions.md</code>. AI tools have zero repo-level context." },
        { type: "gtb",      text: "Create <code>AGENTS.md</code> documenting conventions, high-risk components, and the test-before-change requirement." },
      ],
    },
    {
      id: "d4",
      name: "Coding Standards & Consistency",
      weight: 10,
      score: 3.5,
      briefNote: "ESLint + Prettier via Husky; TypeScript strict mode; no formal CI lint gate",
      rationaleText: "ESLint and Prettier are configured. Husky pre-commit enforces linting on every commit. However the Husky gate is bypassable with <code>--no-verify</code> and there is no CI lint step to catch bypasses.",
      keynotes: [
        { label: "Linter / Formatter Configured",   checked: true  },
        { label: "Linter Enforced in CI",           checked: false },
        { label: "Consistent Naming Patterns",      checked: true  },
        { label: "Consistent Error Handling",       checked: false },
        { label: "Static Types Used",               checked: true  },
      ],
      findings: [
        { type: "strength", text: "ESLint and Prettier are configured. Husky pre-commit enforces linting on every commit." },
        { type: "warn",     text: "Husky gate is bypassable with <code>--no-verify</code>. No CI lint step catches bypasses." },
      ],
    },
    {
      id: "d5",
      name: "Environment & Setup",
      weight: 10,
      score: 2.0,
      briefNote: "<code>.nvmrc</code> present; build commands documented; no <code>.env.example</code>",
      rationaleText: "<code>.nvmrc</code> pins the Node version and build commands are documented in README. However no <code>.env.example</code> file lists required environment variables.",
      keynotes: [
        { label: "Build Commands Documented",             checked: true  },
        { label: "Commands Validated (Run Successfully)", checked: false },
        { label: "Runtime Version Pinned",                checked: true  },
        { label: ".env.example Present",                  checked: false },
        { label: "Environment Switching Documented",      checked: false },
        { label: "Local Dev Guide for New Contributors",  checked: false },
      ],
      findings: [
        { type: "issue", text: "No <code>.env.example</code> file. Environment variables required by the app are undocumented." },
        { type: "gtb",   text: "Add <code>.env.example</code> listing all required variables with placeholder values and descriptions." },
      ],
    },
    {
      id: "d6",
      name: "Security",
      weight: 10,
      score: 2.0,
      briefNote: "No hardcoded credentials; no SAST or dependency audit in CI",
      rationaleText: "No hardcoded API keys, tokens, or passwords found in source files. However npm audit is not run in any CI step and there are no documented security guidelines.",
      keynotes: [
        { label: "Security Guidelines Documented",        checked: false },
        { label: "Sensitive Data Rules Followed in Code", checked: true  },
        { label: "No Hardcoded Credentials Found",        checked: true  },
        { label: "Security Headers Configured",           checked: false },
        { label: "SAST / Dep Audit in CI",                checked: false },
        { label: "Secrets Externalized",                  checked: true  },
      ],
      findings: [
        { type: "strength", text: "No hardcoded API keys, tokens, or passwords found in source files." },
        { type: "issue",    text: "No <code>npm audit</code> step in CI. Known CVEs in transitive dependencies may go undetected." },
        { type: "gtb",      text: "Add <code>npm audit --audit-level=high</code> to CI pipeline." },
      ],
    },
    {
      id: "d7",
      name: "Inline Documentation",
      weight: 10,
      score: 1.5,
      briefNote: "Minimal JSDoc; complex logic uncommented; prop interfaces lack semantic context",
      rationaleText: "Fewer than 10 JSDoc comments exist across all source files. TypeScript types provide correctness but no semantic intent for AI reasoning.",
      keynotes: [
        { label: "Public APIs / Functions Have Docstrings", checked: false },
        { label: "Complex Logic Commented",                 checked: false },
        { label: "Business Rules Explained Inline",         checked: false },
        { label: "Error Paths Annotated",                   checked: false },
      ],
      findings: [
        { type: "issue", text: "Fewer than 10 JSDoc comments exist across all source files. TypeScript types provide correctness but no semantic intent." },
        { type: "gtb",   text: "Add JSDoc to the top-20 most-used exported functions and interfaces." },
      ],
    },
    {
      id: "d8",
      name: "Accessibility / A11y",
      weight: 5,
      score: 1.0,
      briefNote: "Minimal ARIA usage; core a11y lint rules disabled; no automated a11y testing",
      rationaleText: "Interactive components lack ARIA roles and keyboard-event handlers. Three core a11y lint rules are disabled. No automated a11y tests exist.",
      keynotes: [
        { label: "Semantic HTML / Native Components",     checked: false },
        { label: "Interactive Elements Have a11y Labels", checked: false },
        { label: "Colour Contrast WCAG AA",               checked: false },
        { label: "Keyboard Navigation",                   checked: false },
        { label: "Automated A11y Tests",                  checked: false },
      ],
      findings: [
        { type: "critical", text: "Interactive components (Modal, Dropdown) lack ARIA roles and keyboard-event handlers." },
        { type: "gtb",      text: "Install <code>jest-axe</code> and add <code>axe(container)</code> to each component test for baseline a11y regression coverage." },
      ],
    },
    {
      id: "d9",
      name: "Reusable Workflows & Automation",
      weight: 5,
      score: 1.5,
      briefNote: "Husky pre-commit only; no formal CI/CD pipeline",
      rationaleText: "No CI/CD pipeline file found. Quality gates exist only via Husky pre-commit hooks, which are bypassable with <code>--no-verify</code>.",
      keynotes: [
        { label: "CI/CD Pipeline Present",           checked: false },
        { label: "Lint Gate in Pipeline",            checked: false },
        { label: "Test Gate in Pipeline",            checked: false },
        { label: "Security Scan in Pipeline",        checked: false },
        { label: "PR Template Present",              checked: false },
        { label: "Reusable Workflow Templates",      checked: false },
      ],
      findings: [
        { type: "critical", text: "No CI/CD pipeline file found. Quality gates exist only via Husky pre-commit, which is bypassable." },
        { type: "gtb",      text: "Create <code>.github/workflows/ci.yml</code> with stages: lint, type-check, test, security-scan." },
      ],
    },
    {
      id: "d10",
      name: "Change Impact & Blast Radius",
      weight: 5,
      score: 1.0,
      briefNote: "No module ownership map; shared utilities untested; no feature flags",
      rationaleText: "Shared utility functions have 0% test coverage. No CODEOWNERS file exists. No blast radius documentation. No feature flags for risky deploys.",
      keynotes: [
        { label: "Module Ownership Map Exists",           checked: false },
        { label: "High-Risk Areas Labelled",              checked: false },
        { label: "Shared Utilities Tested",               checked: false },
        { label: "Blast Radius Guide / Safe-Change Docs", checked: false },
        { label: "Feature Flags for Risky Deploys",       checked: false },
      ],
      findings: [
        { type: "critical", text: "Shared utility functions have 0% test coverage. AI-generated changes to this layer have an undefined blast radius." },
        { type: "gtb",      text: "Create <code>blast-radius.md</code> classifying modules as High / Medium / Low risk and link it from <code>AGENTS.md</code>." },
      ],
    },
  ],

  /* ── 5. DOCUMENTATION ACCURACY ───────────────────────────────── */
  docAccuracy: [
    { name: "README.md",      status: "Partially Accurate", statusClass: "align-partial",  notes: "Installation and scripts are accurate. Architecture and contribution sections are WIP placeholders." },
    { name: "AGENTS.md",      status: "Missing",            statusClass: "align-partial",  notes: "File does not exist. No AI context source is present in the repository." },
    { name: "CONTRIBUTING.md",status: "Missing",            statusClass: "align-partial",  notes: "File does not exist. No PR process, coding conventions, or component authoring guide documented." },
    { name: ".env.example",   status: "Missing",            statusClass: "align-partial",  notes: "File does not exist. Environment variable requirements are undocumented." },
  ],

  /* ── 6. COVERAGE ─────────────────────────────────────────────── */
  coverage: {
    executionStatus: "Tests execute and all pass. Overall: Statements 35%, Branches 28%, Functions 30%. Shared utilities layer has 0% coverage.",
    files: [
      { name: "src/components/Button/Button.tsx", stmts: 100, branch: 100, funcs: 100 },
      { name: "src/components/Modal/Modal.tsx",   stmts: 42,  branch: 30,  funcs: 38  },
      { name: "src/utils/formatters.ts",          stmts: 0,   branch: 0,   funcs: 0,   note: "Shared utility — zero coverage, high blast radius." },
    ],
  },

  /* ── 7. RISKS ────────────────────────────────────────────────── */
  risks: [
    { id: "r1", severity: "critical", cardClass: "rc-critical", title: "No AI Context or AGENTS.md",              description: "AI assistants have no knowledge of project conventions, security-sensitive code paths, or naming standards. AI suggestions will frequently diverge from team patterns." },
    { id: "r2", severity: "critical", cardClass: "rc-critical", title: "Shared Utilities Have Zero Test Coverage", description: "Utility functions consumed across many components have 0% coverage. AI-generated changes to this layer have an undefined blast radius with no safety net." },
    { id: "r3", severity: "high",     cardClass: "rc-high",     title: "No Formal CI/CD Pipeline",                description: "No GitHub Actions, Jenkins, or equivalent CI file exists. Quality gates are only enforced developer-side via Husky, which is bypassable with <code>--no-verify</code>." },
    { id: "r4", severity: "high",     cardClass: "rc-high",     title: "Accessibility Near-Absent",               description: "Minimal ARIA usage across interactive components. Three core a11y lint rules are disabled. Accessibility regressions from AI-generated UI code will go undetected." },
    { id: "r5", severity: "medium",   cardClass: "rc-medium",   title: "No Dependency Security Audit",            description: "<code>npm audit</code> is not run in any CI step. Known CVEs in transitive dependencies may be present undetected." },
  ],

  /* ── 8. ROADMAP ──────────────────────────────────────────────── */
  /*  days30 / days60 / days90 must be plain string ARRAYS.        */
  roadmap: {
    days30: [
      "Create <code>AGENTS.md</code> documenting architecture, component conventions, security-sensitive areas, and test-before-change requirements.",
      "Create <code>.github/workflows/ci.yml</code> with stages: lint, type-check, test, security-scan.",
      "Add <code>npm audit --audit-level=high</code> to CI as a non-blocking warning step.",
      "Add <code>.env.example</code> documenting all required environment variables.",
    ],
    days60: [
      "Raise statement coverage to at least 50% by adding tests for shared utilities and high-traffic components.",
      "Write <code>docs/architecture.md</code> with annotated directory tree and deployment model.",
      "Create <code>blast-radius.md</code> classifying modules as High / Medium / Low risk.",
      "Re-enable disabled a11y lint rules and triage violations.",
    ],
    days90: [
      "Achieve at least 60% statement coverage across all source files.",
      "Add <code>jest-axe</code> and integrate <code>axe(container)</code> assertions in every component test.",
      "Add ARIA roles and keyboard handlers to all interactive overlay components.",
      "Create <code>CONTRIBUTING.md</code> with PR checklist, test requirements, and component authoring guide.",
    ],
  },

  /* ── 9. AI USAGE GUIDANCE ────────────────────────────────────── */
  guidance: [
    {
      id: "gc-safe", cls: "gc-safe", title: "Safe AI Tasks",
      items: [
        "Adding or updating TypeScript prop interfaces (non-breaking additions)",
        "Writing new unit tests for untested components using the existing test pattern",
        "SCSS / CSS styling changes to individual component stylesheets",
        "Updating static text, labels, or copy within component props",
        "Improving JSDoc comments on existing interfaces",
      ],
    },
    {
      id: "gc-review", cls: "gc-review", title: "AI Tasks Requiring Review",
      items: [
        "Prop interface changes on shared components — check all consumers for breakage",
        "Async patterns (InfiniteScroll, data-fetching hooks) — observer lifecycle edge cases",
        "Build config changes — affects all dist outputs",
        "Any third-party integration changes",
      ],
    },
    {
      id: "gc-nogo", cls: "gc-nogo", title: "AI Must Not Touch",
      items: [
        "Shared utility functions (<code>src/utils/</code>) — zero coverage, high blast radius",
        "Authentication or token-handling code — any regression breaks user sessions",
        "Any component with 0% test coverage — blast radius is undefined",
      ],
    },
    {
      id: "gc-prime", cls: "gc-prime", title: "Prime Context Files for AI",
      items: [
        "<code>README.md</code> — installation, scripts, folder overview",
        "<code>tsconfig.json</code> — path aliases and strict mode config",
        "A well-tested component and its test file — shows expected structure",
        "Once created: <code>AGENTS.md</code> — conventions and caution zones",
      ],
    },
    {
      id: "gc-post", cls: "gc-post", title: "Post-AI Change Checklist",
      items: [
        "Run <code>npm run type-check</code> — confirm zero TypeScript errors",
        "Run <code>npm run lint</code> — confirm zero ESLint violations",
        "Run <code>npm test</code> — confirm no new test failures",
        "If shared component prop interface changed: grep all consumers manually",
        "Review the full <code>git diff</code> for unintended side effects",
      ],
    },
    {
      id: "gc-anti", cls: "gc-anti", title: "Anti-Patterns to Avoid",
      items: [
        "Asking AI to refactor shared utilities without writing tests first",
        "Accepting AI-generated components that omit TypeScript interfaces",
        "Using AI to suppress lint errors with <code>eslint-disable</code> instead of fixing root cause",
        "Using AI to modify auth or payment flows without a human security review",
      ],
    },
  ],

  /* ── 10. VERDICT ─────────────────────────────────────────────── */
  /*  body: array of strings — one item per paragraph.             */
  /*  HTML tags (<strong>, <code>, <a>, <em>) are welcome here.    */
  verdict: {
    label: "No-Go — Basic AI Readiness",
    cls: "vb-nogo",
    body: [
      "This repository scores <strong>1.95 / 5.0</strong> (Basic). AI assistance should be limited to narrow, well-tested atomic components and documentation improvements.",
      "<strong>Path forward:</strong> The foundations are sound — TypeScript strict mode, ESLint, and Husky pre-commit are real quality investments. Completing the 30-day roadmap (<code>AGENTS.md</code>, CI pipeline, <code>.env.example</code>) would raise the estimated score to approximately 2.5 to 2.8. Completing the 60-day roadmap (coverage expansion, architecture docs) would bring it to 3.2 to 3.5 (Conditional Go), enabling confident AI-assisted development with clear guardrails.",
    ],
  },
};

// Required: expose to window so the HTML renderer can read it.
window.REPORT_DATA = REPORT_DATA;
