# Build & Validation — App Manager

## Prerequisites

| Tool | Version | Notes |
|---|---|---|
| Node.js | 16.15.1 LTS | Exact version recommended for production parity |
| Yarn | 1.x | Package manager of choice (`npm` also works) |
| Docker | 20+ | Required for containerised builds and local replica of production |
| MongoDB | 5+ | Required for running the service (dev can use a local instance) |

---

## Environment Variables (required before any run)

Set these in your shell or via a `.env` loader **before** starting the server:

```bash
export MIDDLEWARE_APP_MANAGER_MOBILE_JWT_SECRET_KEY=<v1-jwt-secret>
export MIDDLEWARE_APP_MANAGER_PPBLAPP_MOBILE_JWT_SECRET_KEY=<v2v3-jwt-secret>
export MIDDLEWARE_APP_MANAGER_MONGO_USER=<mongo-username>           # production/staging only
export MIDDLEWARE_APP_MANAGER_MONGO_PASSWORD=<mongo-password>       # production/staging only
```

> In local development (`NODE_ENV=development`) MongoDB connects without credentials using a simpler URL; the credential variables are still required by the config loader but can be set to empty strings.

---

## Install Dependencies

```bash
cd app-manager
yarn install
```

---

## Development Server

The dev workflow compiles TypeScript via Webpack in development mode and then starts the server using `nodemon` with the `dev-config.json` environment file.

```bash
yarn server:dev
```

This is equivalent to:
```bash
yarn build:dev && node tools/run-server config=../environment/dev-config.json
```

The server starts on **port 4000**.

---

## Build Commands

| Command | Description |
|---|---|
| `yarn build:dev` | Webpack bundling in development mode (source maps, faster) |
| `yarn build` | Webpack bundling in production mode (minified, optimised) |

TypeScript is compiled through `ts-loader` in Webpack; the configuration is split across:
- `tools/build/webpack-server-config.js` — server-side Webpack config
- `tools/build/paths.js`, `loaders.js`, `optimization.js`, `env.js` — modular helpers
- `tsconfig.json` — TypeScript compiler options with path aliases

---

## Running in Other Environments

| Command | Config file | Target |
|---|---|---|
| `yarn server:dev` | `dev-config.json` | Local development |
| `yarn server:eks-mwite1` | `eks-mwite1-config.json` | Staging (EKS) |
| `yarn server:mwprod` | `mwprod-config.json` | Production (alternate) |
| `yarn server:prod` | `prod-config.json` | Production |

These commands run the pre-built bundle with the specified environment config. Build the bundle first with `yarn build` before running a production environment command.

---

## Docker

### Build the image

```bash
# From the docker/ directory (repo root)
./docker/build.sh

# Or manually
docker build -f docker/Dockerfile -t app-manager:local .
```

### Run locally with Docker

```bash
./docker/start.sh
```

The Dockerfile uses a multi-stage build:
1. **Build stage** — installs dependencies and compiles TypeScript
2. **Production stage** — copies only the compiled output and runtime dependencies

The entrypoint is `docker/entrypoint.sh`, which sets environment variables from secrets and then executes the Node server.

### docker-compose (dev helpers)

```bash
cd app-manager
yarn docker
```

This runs `tools/docker/docker-boot.js` and `tools/docker/docker-app-boot.js` in parallel, which are development helper scripts for local service wiring.

---

## CI/CD Pipeline (Jenkins)

The `Jenkinsfile` at the repository root defines the pipeline. Stages:

1. **Build** — triggers `./docker/build.sh` (depends on environment/branch)
2. **Package** — runs `./docker/package.sh`
3. **Push** — pushes image to registry via `./docker/push.sh`
4. **Deploy** — executes `./docker/deploy.sh`

> ⚠ The Jenkinsfile does **not** currently define lint, test, or security-scan gates before build/deploy. Any additions to the pipeline (quality gates) should be inserted before the build stage.

---

## TypeScript Validation

Check for TypeScript errors without producing output:

```bash
cd app-manager
npx tsc --noEmit
```

Alternatively, a development build will surface type errors:

```bash
yarn build:dev
```

The project uses `strict: true` in `tsconfig.json`. All type errors are treated as build failures.

---

## Code Formatting

Prettier is configured in `.prettierrc` and enforced via `lint-staged` / `husky` on commit.

To format all TypeScript files manually:
```bash
cd app-manager
npx prettier --write "src/**/*.ts"
```

To check without writing:
```bash
npx prettier --check "src/**/*.ts"
```

---

## Version Bumping

```bash
yarn bump
```

Uses `version-bump-prompt` to interactively bump version, commit, tag, and push.

---

## Path Aliases

Configured in both `tsconfig.json` and `tools/build/webpack-server-config.js` (via `TsconfigPathsPlugin`):

| Alias | Resolves to |
|---|---|
| `@app-manager/*` | `src/app-manager/*` |
| `@config/*` | `src/config/*` |

Always use these aliases in imports; do not use relative `../..` chains.

---

## Related Documentation

- [Repository Overview](repo-overview.md) — environment configs and secrets
- [Agent Workflow](agent-workflow.md) — definition of done and pre-merge checklist
- [Contribution Checklist](contribution-checklist.md) — validation steps for documentation changes
