# Agent Workflow — App Manager

## Definition of Done

Every change — whether made by a human or AI agent — must satisfy all of the following before being considered complete:

- [ ] TypeScript compiles without errors: `yarn build:dev` exits 0
- [ ] Prettier check passes: `npx prettier --check "src/**/*.ts"`
- [ ] No `any` types added without an explanatory comment on the same line
- [ ] All new errors are instances of `ErrorWrapper` and passed to `next()` — never `res.send()` directly
- [ ] All new log statements include `requestId`
- [ ] All new string literals that represent error codes or client IDs are added to `constants.ts` — not inlined
- [ ] Import paths use `@app-manager/*` or `@config/*` aliases — not relative `../../` chains
- [ ] Any new route has a corresponding validator middleware registered before `verifyToken`
- [ ] Any new public endpoint documents its contract in `docs/ai/api-error-handling.md`
- [ ] Any security-relevant change is reviewed against `docs/ai/security.md`

---

## How to Add a New API Endpoint

1. **Define the route** in the appropriate `routes/<version>/config.routes.ts`.
2. **Write a validator middleware** in `middleware/validations.ts`.
   - Validate all query/body parameters.
   - Call `next()` on success; `next(ErrorWrapper)` on failure.
3. **Wire the middleware chain**: validator → `verifyToken` (or `verifyTokenV2`) → controller.
4. **Write the controller** in `controllers/keys.ts` (or a new controller file if the domain is different).
   - Follow the async/await + try-catch pattern.
   - Use `successResponse()` and `errorResponse()` utilities.
5. **Add any new error codes** to `constants.ts` before referencing them.
6. **Update `docs/ai/api-error-handling.md`** with the new route, parameters, and error codes.

---

## How to Modify the Cache

- Cache key patterns live in `constants.ts` (`GET_CONFIG_VALUES_CACHE_KEY`).
- Cache TTL and checkperiod are pulled from the runtime config (`cache.ttl`, `cache.checkperiod`).
- Any code that writes to the database must also invalidate the corresponding cache key.
- Do not add cache to write operations — only read paths should be cached.
- If you add a new read path that should be cached, use the pattern: `GET_CONFIG_<scope>` where `<scope>` uniquely identifies the query contract.

---

## How to Add a New Client Type

1. Add the new client to `constants.ts → CLIENT` with a unique `ID` and `TITLE`.
2. `getConfigClientIds()` in `utils/index.ts` derives the allowed list from `CLIENT` automatically — no other change needed.
3. Update `docs/ai/repo-overview.md` → "Key Features" section with the new client.
4. Update `docs/ai/api-error-handling.md` → "Query Parameters — v1" with the new allowed value.

---

## How to Add a New Route Version

If the request/response contract changes enough to warrant a new route generation:

1. Create `src/app-manager/routes/v4/` with `index.routes.ts` and `config.routes.ts`.
2. Create a new validator in `validations.ts` (e.g. `validateKeysRequestV4`).
3. Mount the new router in `server.ts` under a new prefix (e.g. `/ext/v4`).
4. Add the ADR rationale to `docs/ai/adr-versioned-routes-jwt-and-cache.md` explaining what changed and why.

Do **not** modify v1/v2/v3 routes to accommodate new behavior — this breaks backward compatibility for existing consumers.

---

## Debugging Guidelines

### Authentication errors (401)
- Check that the JWT was minted with the correct secret key for the route version.
- Check that `iss` is exactly `'app-manager-service'`.
- Check that `requestId` in the JWT matches the `requestId` header (must be a valid UUID).
- Check that `client` or `namespace` in the JWT matches the query parameter.
- Check `iat` against current time — tokens expire based on `JWT_TOKEN_EXPIRY`.

### Validation errors (400)
- Confirm `client`/`namespace` is in the allowed list in `constants.ts → CLIENT`.
- Confirm `referrer` is either absent or matches `BOP_REFERRER`.
- If `referrer` is present, ensure `offset` and `limit` are also provided.

### Cache issues
- Use the cache key pattern `GET_CONFIG_<client>` — check if an unexpected value is being cached.
- If stale data is returned, check whether write operations are properly calling cache invalidation.
- For v3 delta reads, confirm `lastUpdatedAt` is provided; it bypasses cache by design.

### MongoDB connection issues
- Confirm `NODE_ENV` is set correctly (affects whether credentials are included in the URL).
- Check that the four environment variables for DB credentials are set.
- The connection code retries every 5 seconds on error (`setTimeout(connectWithRetry, 5000)`).

---

## Module Risk Classification

Use this table to understand the blast radius before making any change. Higher-risk modules require more careful review and ideally test coverage before modification. For PR review routing, see [CODEOWNERS](../../CODEOWNERS).

| Risk | Module / Path | Why | Consumed By |
|---|---|---|---|
| **High** | `middleware/jwt-token.ts` | Implements all JWT verification checks for every route version. A regression breaks authentication for all clients. | Every protected route |
| **High** | `middleware/auth.ts` | Global XSS middleware — inspects all six request surfaces. Restricting coverage breaks the security guarantee. | `server.ts` global mount |
| **High** | `config/index.ts` | Injects secret environment variables. Any change here risks leaking credentials into config files. | Application bootstrap |
| **High** | `constants.ts` | Single source for all error codes, client IDs, JWT claim names, and cache key patterns. Incorrect values propagate to every controller and middleware. | All controllers, middleware, routes |
| **High** | `server.ts` | Express bootstrap and middleware wiring. Reordering middleware breaks the security chain (`body-parser → Morgan → checkAllowedMethods → xssMiddleware → Helmet`). | Application entry point |
| **Medium** | `utils/keys.ts` | Cache helpers and DB query builders consumed by all three versioned controller paths. No test coverage — blast radius is undefined. | `controllers/keys.ts` (all API versions) |
| **Medium** | `utils/index.ts` | `successResponse`, `errorResponse`, `getConfigClientIds`. Shared by all controllers. | All controllers |
| **Medium** | `cache/index.ts` | NodeCache singleton. TTL and invalidation logic affects all read paths. | Controllers, utils |
| **Medium** | `database/models/keys.model.ts` | Mongoose schema. Schema changes require a migration plan — no down-migration tooling exists. | All controllers |
| **Medium** | `routes/<version>/config.routes.ts` | Version-specific middleware chain. Changing chain order (validator → verifyToken → controller) silently removes auth. | Clients on that API version |
| **Low** | `controllers/dependency.ts` | Dependency check endpoint — no auth, no database writes. | Health / ops monitoring |
| **Low** | `middleware/validations.ts` | Input validators. Changes affect only the routes that register them. | Route-specific |
| **Low** | `middleware/error.ts` | Global error handler — serialises `ErrorWrapper` into the HTTP response. Low blast radius but errors here surface as blank 500s. | All error paths |
| **Low** | `common/models/error.ts` | `ErrorWrapper` class definition. Type-only — changes propagate only if the shape changes. | All middleware and controllers |
| **Low** | `environment/*.json` | Per-environment config values (non-secret). Changing a key requires matching update in `config/index.ts`. | Application bootstrap |

> **Caution on "Low" modules**: Low blast radius means a change is unlikely to affect unrelated paths — not that it is safe to skip review. Always run `yarn build:dev` and check the Definition of Done before committing.

---

## Performance Guidelines

- API response target: **< 500ms** for configuration read endpoints.
- MongoDB query target: **< 100ms** for indexed queries on `clientType` + `status` fields.
- Cache hit paths should return comfortably under 10ms.
- Monitor for memory growth if `NodeCache` holds large configuration payloads — `checkperiod` purges expired entries automatically.

---

## Logging Standards

| Situation | Level | Required fields |
|---|---|---|
| Incoming request | `info` | `requestId`, route |
| Successful response | `info` | `requestId`, response payload |
| Caught exception | `error` | `requestId`, error object |
| Authentication failure | `error` | `requestId`, error object |
| MongoDB connection events | `info`/`error` | message only (startup) |

Do not log:
- JWT secret values
- MongoDB passwords
- Full request body when it contains tokens or credentials

---

## AI Agent Working Rules

When an AI agent (GitHub Copilot, Cursor, Claude, Codex, etc.) is assisting with this codebase:

1. **Always read [repo-overview.md](repo-overview.md) first** to understand scope and client types.
2. **Follow [coding-standards.md](coding-standards.md)** for every code change — no exceptions.
3. **Check [security.md](security.md)** before touching any middleware, auth, or input validation code.
4. **Reference [api-error-handling.md](api-error-handling.md)** when adding or modifying routes.
5. **Do not modify existing route versions** — create new versions instead.
6. **Do not hardcode error codes or client IDs** — use `constants.ts`.
7. **Do not bypass `verifyToken`** on any route that touches configuration data.
8. **Do not commit secrets** — all secret values come from environment variables.
9. **Update documentation** (`docs/ai/`) whenever an API contract, security rule, or architectural pattern changes.

---

## Related Documentation

- [Coding Standards](coding-standards.md)
- [API & Error Handling](api-error-handling.md)
- [Security Implementation](security.md)
- [Build & Validation](build-validation.md)
- [Contribution Checklist](contribution-checklist.md)
