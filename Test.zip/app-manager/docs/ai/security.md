# Security Implementation — App Manager

## Security Layers

The service applies security controls at five distinct layers:

```
1. Transport          ← HTTPS (enforced by infrastructure/load balancer)
2. HTTP headers       ← Helmet (CSP, Referrer-Policy, X-Frame-Options)
3. Input sanitation   ← XSS middleware (every request)
4. Authentication     ← JWT verification (all protected routes)
5. Authorisation      ← Claim-to-route alignment (client/namespace binding)
6. Secret management  ← Environment variables; never in config files
```

---

## 1. Helmet Security Headers

`src/server.ts` applies three Helmet directives on every response:

```typescript
app.use(helmet());
app.use(
  helmet.contentSecurityPolicy({ useDefaults: true }),
  helmet.referrerPolicy({ policy: "no-referrer" }),
  helmet.frameguard({ action: "deny" })
);
```

| Directive | Value | Purpose |
|---|---|---|
| Content-Security-Policy | useDefaults | Restricts resource loading origins |
| Referrer-Policy | no-referrer | Prevents referrer leakage in outbound requests |
| X-Frame-Options | DENY | Prevents clickjacking |

---

## 2. XSS Middleware

`src/app-manager/middleware/auth.ts — xssMiddleware`

Applied globally before any route handler, it inspects all six surfaces of an incoming request:

| Surface | Check |
|---|---|
| `originalUrl` | `url.length !== xss(url).length` → reject |
| `params` | Stringify → XSS scan |
| `query` | Stringify → XSS scan |
| `cookies` | Stringify → XSS scan |
| `body` | Stringify → XSS scan |

If any surface fails, the middleware throws `ErrorWrapper` with:
- HTTP 401
- `ERROR_CODE.XSS` (1012)
- Message: `"Access Denied"` with XSS source appended

The XSS library (`xss` npm package) uses a strict whitelist internally. The length-comparison approach means even a single stripped character triggers a rejection — it does not pass through sanitised content to downstream handlers.

---

## 3. JWT Authentication

### Token structure — v1 (`JwtTokenPayload`)

```json
{
  "client": "androidapp",
  "iss": "app-manager-service",
  "iat": 1713787200,
  "requestId": "550e8400-e29b-41d4-a716-446655440000"
}
```

### Token structure — v2/v3 (`JwtTokenPayloadV2`)

```json
{
  "namespace": "androidapp",
  "iss": "app-manager-service",
  "iat": 1713787200,
  "requestId": "550e8400-e29b-41d4-a716-446655440000"
}
```

### Verification steps (`src/app-manager/middleware/jwt-token.ts`)

For `verifyToken` (v1) and `verifyTokenV2` (v2/v3):

1. **Presence check** — reject with error code `1001` (MISSING_TOKEN) if `Authorization` header is absent.
2. **Signature** — `jwt.verify(token, JWT_SECRET)` — reject with `1000` (INVALID_SIGNATURE) on failure.
3. **Issuer** — `iss` must equal `'app-manager-service'` — reject with `1002` (INVALID_ISS).
4. **Time window** — `|now - iat| > JWT_TOKEN_EXPIRY` → reject with `1004` (IAT_EXPIRED). This limits replay window.
5. **Request ID** — JWT `requestId` must be a valid UUID and must match the `requestId` request header — reject with `1005` (INVALID_REQUEST_ID). This ties a token to a specific request context.
6. **Claim alignment** — JWT `client` (v1) or `namespace` (v2/v3) must match the relevant query parameter — reject with `1003`/`1011`.

### Secret key management

Two separate secret keys are used:

| Key purpose | Config path | Env variable |
|---|---|---|
| v1 token verification | `jwt.secretKey` | `MIDDLEWARE_APP_MANAGER_MOBILE_JWT_SECRET_KEY` |
| v2/v3 token verification | `jwt.ppblSecretKey` | `MIDDLEWARE_APP_MANAGER_PPBLAPP_MOBILE_JWT_SECRET_KEY` |

Both are injected at startup in `src/config/index.ts` via `_.set(config, path, process.env.VAR)`. They are never present in committed config JSON files. Anyone who needs to run the service locally must set these variables in their shell or a `.env` loader.

---

## 4. Input Validation

`src/app-manager/middleware/validations.ts` enforces:

- **Client/namespace** — must be one of the allowed values enumerated in `constants.ts → CLIENT`. No free-form strings reach the database.
- **requestId** — validated with `isValidUUID()` (uuid v4 library).
- **Referrer** — must be a known value (e.g. `BOP`) from the `BOP_REFERRER` constant or absent; unknown referrers are rejected.
- **Pagination params** — `offset` and `limit` are required when `referrer` is present.
- **lastUpdatedAt** — format-checked in v3 validation before use in a DB query.

This input validation occurs before JWT verification, meaning malformed requests are rejected cheaply without touching cryptographic operations.

---

## 5. MongoDB Credential Management

MongoDB credentials are also injected at startup:

| Config path | Env variable |
|---|---|
| `database.username` | `MIDDLEWARE_APP_MANAGER_MONGO_USER` |
| `database.password` | `MIDDLEWARE_APP_MANAGER_MONGO_PASSWORD` |

Connection strings are not committed. In development, the code path uses a simpler URL without credentials:

```typescript
if (process.env.NODE_ENV === 'development') {
  url = `mongodb://${host}:${port}/${dbName}`;
} else {
  url = `mongodb://${user}:${password}@${host1},.../${dbName}?replicaSet=${replica}`;
}
```

---

## 6. HTTP Method Restriction

`src/app-manager/middleware/common.ts — checkAllowedMethods`

Applied globally before route handlers. Any request using an HTTP method not in the allowed list is rejected with 405 Method Not Allowed before any processing occurs.

---

## Security Rules for Code Changes

When modifying any security-related code, follow these rules:

### JWT changes
- Do not add new claim types without a corresponding entry in `JwtTokenPayload`/`JwtTokenPayloadV2`.
- Do not skip verification steps — any new route that accepts JWT must call the full verification chain.
- If a new secret key is needed, add it to `constants.ts`, inject it in `config/index.ts`, and document the new environment variable.

### XSS changes
- Do not bypass `xssMiddleware` for any route that accepts user-controlled input.
- The middleware is applied globally in `server.ts` — do not move it to individual routes only.

### Input validation changes
- Any new query parameter must be validated in the route's dedicated validator before reaching controllers.
- Allowed value lists must live in `constants.ts`, not hardcoded in validators.

### Secrets
- Never commit JWT secrets, DB credentials, or API keys.
- Never log secret values — log only safe identifiers (`requestId`, `client`, `namespace`).
- Never return secret values in API responses.

---

## Known Limitations

- **No rate limiting** — the service does not implement request rate limiting at the application layer. This must be handled by the upstream API gateway or load balancer.
- **No distributed cache invalidation** — `NodeCache` is process-local. In multi-instance deployments, a cache miss on one instance will not invalidate stale data on others. Cache coherence relies on TTL expiry.
- **No audit log** — write operations (add/update/delete keys) log the action via Bunyan but there is no dedicated audit trail collection in MongoDB.

---

## Related Documentation

- [System Architecture](architecture.md) — security layer placement in request flow
- [API & Error Handling](api-error-handling.md) — error codes for auth failures
- [ADR-001](adr-versioned-routes-jwt-and-cache.md) — rationale for JWT claim separation between v1 and v2/v3
