# ADR-001: Versioned Routes, JWT Claims, and In-Memory Cache Strategy

## Status

Accepted

## Date

22 April 2026

## Context

The app-manager service serves multiple mobile and bank clients and has to support configuration retrieval and configuration mutation without forcing all consumers to migrate at the same pace. The repository already contains three route generations:

- `v1` mounted through `/v1/api/app-manager/...`
- `v2` mounted through `/ext/v2/api/app-manager/...`
- `v3` mounted through `/ext/v3/api/app-manager/...`

These versions do not represent cosmetic route duplication. They reflect changes in request contract, token shape, and retrieval behavior:

- `v1` uses a `client`-oriented contract and separates internal mutation routes from external retrieval routes.
- `v2` shifts to `namespace`-based access and validates tokens using `namespace` instead of `client`.
- `v3` adds delta-oriented retrieval using `lastUpdatedAt` and `deletedList`, reducing payload size for clients that already hold a prior snapshot.

The service also performs high-frequency configuration reads relative to writes. Reading from MongoDB for every request would add avoidable latency and load, especially for the non-referrer retrieval paths that repeatedly request the latest active configuration set.

Finally, this service is a middleware/API layer, not a user-facing session service. Authentication has to be lightweight and verifiable on every request, and it must bind a request to a specific caller contract to prevent cross-client or cross-namespace reuse.

## Decision

### 1. Keep explicit API versioning in routes

We will keep separate versioned route trees rather than attempting to collapse all clients onto one mutable contract.

The reasons are:

- Mobile and downstream consumers often upgrade at different speeds.
- The request and response contract changes between `v1`, `v2`, and `v3` are meaningful, not superficial.
- Internal write operations in `v1` have different exposure and risk characteristics than external read operations.
- `v3` introduces delta semantics that would complicate older consumers if forced into a shared endpoint shape.

This choice preserves backward compatibility while allowing the service to evolve retrieval behavior incrementally.

### 2. Use JWT claims that bind the request to the expected contract

We will keep JWT verification tied to a narrow set of claims rather than relying only on signature validation.

The current token model intentionally validates:

- `iss` to ensure the token was minted for this service domain
- `requestId` to tie the token to the current request context
- `iat` to limit replay window
- `client` for `v1`
- `namespace` for `v2` and `v3`

The split between `client` in `v1` and `namespace` in `v2`/`v3` is deliberate:

- `v1` is aligned to an older client-facing contract keyed by application identity.
- `v2` and `v3` are aligned to a broader namespace model used for configuration ownership and mutation semantics.
- Using distinct claim expectations prevents accidental mixing of old and new contracts.

This design reduces the chance of a valid token being replayed against the wrong route generation or against the wrong logical configuration scope.

### 3. Use in-memory NodeCache for configuration read acceleration

We will keep `NodeCache` as the current cache strategy for configuration retrieval.

The reasons are:

- The repository is designed as a single service process with simple deployment semantics.
- The hottest reads are configuration lookups, which are cheap to cache in memory and expensive to repeat unnecessarily against MongoDB.
- TTL and check period are already configurable through runtime configuration keys.
- The code intentionally bypasses or narrows cache usage for referrer-driven and delta-driven behaviors where fresh or filtered DB reads are more appropriate.

The cache strategy is therefore:

- cache stable read paths aggressively
- avoid cache for write operations
- avoid relying on cache when referrer-driven filtering requires fresh data
- use version-aware cache keys, such as the explicit `V3` suffix for delta-capable retrieval flows

## Consequences

### Positive

- Existing consumers can continue using stable contracts without forced migration.
- Newer contracts can evolve independently, especially around namespace handling and delta delivery.
- Authentication remains tightly scoped to the route contract being used.
- MongoDB load and response latency are reduced for repeated configuration reads.
- The code keeps clear separation between read-path optimization and write-path correctness.

### Negative

- Versioned routes increase maintenance overhead because business logic must be reviewed across multiple API generations.
- JWT verification logic is more complex because claim expectations differ by route generation.
- In-memory cache is process-local, so cache coherence across multiple replicas is not guaranteed.
- Write operations rely on DB truth rather than coordinated distributed invalidation, which is simpler but less globally synchronized.

### Accepted Trade-Off

We accept duplicated route generations and process-local caching because the current operational goal is backward compatibility and simple, low-latency configuration delivery rather than a single evolving contract or distributed cache consistency.

## Alternatives Considered

### Alternative A: Single unversioned API contract

Rejected.

This would force all clients to adopt the latest request and response semantics simultaneously. That is risky for mobile and dependent services that may lag behind server changes.

### Alternative B: Use one universal JWT claim model for all versions

Rejected.

This would simplify validation logic, but it would blur the distinction between older `client`-centric contracts and newer `namespace`-centric contracts. The current separation is intentional and acts as a guardrail.

### Alternative C: Move immediately to a distributed cache such as Redis

Rejected for now.

The repository does not currently contain distributed cache infrastructure or invalidation workflows. Introducing Redis would add operational complexity without first proving that process-local caching is insufficient for current load and deployment shape.

## Implementation Notes

The current codebase reflects this decision in the following places:

- `src/app-manager/routes/v1/index.routes.ts`
- `src/app-manager/routes/v2/index.routes.ts`
- `src/app-manager/routes/v3/index.routes.ts`
- `src/app-manager/routes/v1/config.routes.ts`
- `src/app-manager/routes/v2/config.routes.ts`
- `src/app-manager/routes/v3/config.routes.ts`
- `src/app-manager/middleware/jwt-token.ts`
- `src/app-manager/common/models/jwt-payload.ts`
- `src/app-manager/cache/index.ts`
- `src/app-manager/utils/keys.ts`
- `src/app-manager/controllers/keys.ts`

## Review Trigger

This ADR should be revisited if any of the following becomes true:

- all consumers can be migrated to a single stable contract
- distributed cache consistency becomes a production requirement
- JWT claims need to carry additional authorization or tenancy context
- write traffic grows enough that current cache assumptions become invalid
- `v1` can be formally deprecated and removed