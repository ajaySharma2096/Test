# Contribution Checklist — App Manager

## Purpose

This document defines the rules for keeping the `docs/ai/` documentation consistent with the codebase. All contributors — human and AI — must follow these rules before closing a PR or marking a task done.

---

## When to Update Documentation

| Change type | Documents to update |
|---|---|
| New API endpoint or route | `api-error-handling.md` (route table, params, error codes) |
| New query parameter or response field | `api-error-handling.md` |
| New error code added to `constants.ts` | `api-error-handling.md` (Error Codes Reference table) |
| New client type added | `repo-overview.md`, `api-error-handling.md` |
| New middleware added | `architecture.md` (middleware execution order), `security.md` if security-related |
| New route version (v4, v5, …) | `architecture.md`, `api-error-handling.md`, `adr-versioned-routes-jwt-and-cache.md` or new ADR |
| JWT claim change | `security.md`, `api-error-handling.md`, ADR if it represents a contract change |
| Cache TTL or strategy change | `architecture.md`, `security.md` (Known Limitations), ADR if significant |
| New environment variable | `build-validation.md`, `repo-overview.md` |
| New script in `package.json` | `build-validation.md` |
| Coding convention change | `coding-standards.md` |
| New Docker or CI stage | `build-validation.md` |
| Any architectural decision | New ADR in `docs/ai/` following the template below |

---

## Documentation Quality Rules

### Accuracy
- Every file name, function name, constant, or route path mentioned in documentation must actually exist in the codebase.
- If you rename a function or file in code, update every documentation reference to it.
- Do not write aspirational documentation that describes behavior not yet implemented — clearly mark future or planned features as such.

### Completeness
- New routes must be documented before merge, not after.
- Error codes must be documented in `api-error-handling.md` before they are reachable in production.

### Consistency
- Use the same terminology throughout the docs:
  - `client` (not `clientId`, not `appClient`) for v1 request identifiers
  - `namespace` (not `namespaceId`, not `ns`) for v2/v3 request identifiers
  - `ErrorWrapper` (not `AppError`, not `CustomError`) for the error class
  - `successResponse` / `errorResponse` for the utility functions
- HTTP status codes and error codes must match what's in `constants.ts`.

### Format
- Use Markdown tables for lists of routes, parameters, and error codes.
- Use fenced code blocks with the language identifier (` ```typescript`, ` ```json`, ` ```bash`).
- Headings use sentence case for H3 and below; title case for H1 and H2.

---

## ADR Template

When a significant architectural decision is made (new versioning scheme, change in auth strategy, change in caching technology, etc.), create a new file in `docs/ai/` named `adr-<short-title>.md` using this structure:

```markdown
# ADR-NNN: <Title>

## Status
Accepted | Proposed | Deprecated | Superseded by ADR-NNN

## Date
DD Month YYYY

## Context
<Why this decision was needed. What problem were we solving?>

## Decision
<What we decided to do and why. Be specific — reference file names and constants.>

## Consequences

### Positive
<Benefits of this decision.>

### Negative
<Drawbacks and trade-offs.>

### Accepted Trade-Off
<The trade-off we intentionally accepted.>
```

Number ADRs sequentially based on the existing files.

---

## Pre-Merge Checklist

Before merging any PR that changes code, verify all items below:

### Code quality
- [ ] `yarn build:dev` exits 0 (TypeScript compiles cleanly)
- [ ] `npx prettier --check "src/**/*.ts"` exits 0
- [ ] No `any` without justification comment
- [ ] No raw string literals for error codes or client IDs — all in `constants.ts`

### Security
- [ ] No secrets in committed files
- [ ] No new route bypasses `verifyToken`/`verifyTokenV2`
- [ ] If new query params added: corresponding validator written
- [ ] If new surface added: XSS middleware still covers it (or is explicitly extended)

### Documentation
- [ ] All documentation references to files/functions/routes match current codebase
- [ ] New routes documented in `api-error-handling.md`
- [ ] New error codes documented in `api-error-handling.md`
- [ ] Architecture changes reflected in `architecture.md`
- [ ] Security changes reflected in `security.md`
- [ ] Significant decisions captured in an ADR
- [ ] `agent-workflow.md` updated if any working rules changed

### AI context (if AI agent worked on this)
- [ ] `docs/ai/` docs accurately describe the resulting state of the codebase
- [ ] No documentation presents implemented behavior as aspirational or vice versa
- [ ] `AGENTS.md` at repo root still accurately describe project conventions

---

## Documentation File Ownership

| File | Trigger for update |
|---|---|
| `repo-overview.md` | Stack version changes; new major feature; new client type |
| `architecture.md` | Request flow changes; middleware added/removed; new route version; DB schema change |
| `coding-standards.md` | Linting rules added; Prettier config changed; new mandatory pattern established |
| `api-error-handling.md` | Any API change: new route, parameter, error code, or response field |
| `security.md` | Auth changes; new security header; new validation rule; new known limitation |
| `build-validation.md` | New script; new env variable; Webpack or Docker change; CI stage change |
| `agent-workflow.md` | New working rule for agents or developers; new debugging guide |
| `contribution-checklist.md` | New quality gate; new documentation rule; checklist item added or removed |
| `adr-*.md` | Created for significant architectural decisions; never modified after "Accepted" — create a superseding ADR instead |

---

## Related Documentation

- [Agent Workflow](agent-workflow.md) — definition of done for code changes
- [Coding Standards](coding-standards.md) — code quality rules
- [API & Error Handling](api-error-handling.md) — API documentation template
