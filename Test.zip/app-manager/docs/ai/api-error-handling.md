# API & Error Handling — App Manager

## Route Structure

### Public operational endpoints (no auth)

| Method | Path | Purpose |
|---|---|---|
| GET | `/ping` | Liveness probe — returns 200 OK |
| GET | `/health` | Health check |
| GET | `/dependency` | Dependency status |

### v1 — client-keyed contract (external reads)

Base prefix: `/v1/api/app-manager`

| Method | Path | Middleware chain | Purpose |
|---|---|---|---|
| GET | `/config` | validateKeysRequest → verifyToken → fetchKeys | Retrieve active config keys for a `client` |

### v1 — internal write routes

Base prefix: `/internal/v1/api/app-manager`

| Method | Path | Middleware chain | Purpose |
|---|---|---|---|
| POST | `/config/add-update-key` | validateAddOrUpdateKeys → verifyTokenV2 → addOrUpdateKeys | Create or update a config key |
| POST | `/config/delete-key` | validateDeleteKeys → verifyTokenV2 → deleteKeys | Soft-delete a config key |
| GET | `/client` | internalClientRouter | Fetch client details |

### v2 — namespace-keyed contract (external reads)

Base prefix: `/ext/v2/api/app-manager`

| Method | Path | Middleware chain | Purpose |
|---|---|---|---|
| GET | `/config` | validateKeysRequestV2 → verifyTokenV2 → fetchKeysV2 | Retrieve active config keys for a `namespace` |

### v3 — delta namespace reads (external)

Base prefix: `/ext/v3/api/app-manager`

| Method | Path | Middleware chain | Purpose |
|---|---|---|---|
| GET | `/config` | validateKeysRequestV3 → verifyTokenV2 → fetchKeysV3 | Retrieve keys updated since `lastUpdatedAt`; returns a `deletedList` |

---

## Request Headers

| Header | Required | Description |
|---|---|---|
| `Authorization` | Yes (protected routes) | Signed JWT token |
| `requestId` | Yes (protected routes) | UUID v4 — logged for tracing; also validated against JWT payload |
| `client` | Conditional | Required for some validation paths; must match JWT claim in v1 |

---

## Query Parameters — v1 Config Read

| Parameter | Type | Required | Description |
|---|---|---|---|
| `client` | string | Yes | One of: `androidapp`, `iosapp`, `ppblAppClientAndroid`, `ppblAppClientIos` |
| `referrer` | string | No | `BOP` for portal path — bypasses cache, enables pagination |
| `offset` | string | Conditional | Required when `referrer` is present |
| `limit` | string | Conditional | Required when `referrer` is present |
| `search` | string | No | Regex search on key name (case-insensitive, BOP only) |

## Query Parameters — v2/v3 Config Read

| Parameter | Type | Required | Description |
|---|---|---|---|
| `namespace` | string | Yes | Equivalent to `client` in v1 |
| `lastUpdatedAt` | ISO date string | No (v3 only) | Returns keys updated after this timestamp plus `deletedList` |

---

## Success Response Shape

```json
{
  "status": "SUCCESS",
  "message": "Data is successfully fetched",
  "response": {
    "list": [
      {
        "id": "64f0a...",
        "key": "featureFlag.enableDarkMode",
        "value": "true",
        "namespace": "androidapp",
        "status": "active",
        "updatedBy": "admin",
        "createdAt": "22-Apr-2026",
        "updatedAt": "22-Apr-2026"
      }
    ],
    "total": 1
  }
}
```

Notes on serialisation:
- `_id` (Mongo ObjectId) is remapped to `id`
- `clientType` is renamed to `namespace` in the JSON output
- Dates are formatted as `DD-MMM-YYYY` via `moment`
- `__v` and raw `_id` / `clientType` fields are removed

---

## Error Response Shape

All errors are normalised through `errorResponse()` in `src/app-manager/utils/index.ts`.

```json
{
  "status": "FAILURE",
  "message": "Access Denied",
  "errorCode": 1001,
  "requestId": "uuid-of-the-request"
}
```

---

## Error Codes Reference

All codes are defined in `src/app-manager/constants.ts`.

### 401 — Access Denied

| Code | Constant | Trigger |
|---|---|---|
| 1000 | `INVALID_SIGNATURE` | JWT signature verification failed |
| 1001 | `MISSING_TOKEN` | `Authorization` header absent |
| 1002 | `INVALID_ISS` | Token `iss` claim does not match `'app-manager-service'` |
| 1003 | `INVALID_CLIENT` | JWT `client` claim does not match query `?client` |
| 1004 | `IAT_EXPIRED` | Token `iat` is outside the allowed time window |
| 1005 | `INVALID_REQUEST_ID` | JWT `requestId` does not match `requestId` header or is not a valid UUID |
| 1011 | `INVALID_NAMESPACE` | JWT `namespace` claim does not match query `?namespace` |
| 1012 | `XSS` | XSS vector detected in URL, params, query, cookies, or body |

### 400 — Invalid Query Params

| Code | Constant | Trigger |
|---|---|---|
| 1006 | `INVALID_QUERY_PARAMS.ERROR_CODE` | Invalid referrer; invalid client; invalid requestId; missing offset/limit when referrer present; invalid `lastUpdatedAt` |

### 500 — Internal Error

| Code | Constant | Trigger |
|---|---|---|
| 1007 | `INTERNAL_ERROR.ERROR_CODE` | Unhandled exception in controllers or DB layer |

### 404 — Not Found

| Code | Constant | Trigger |
|---|---|---|
| 1008 | `NOT_FOUND.ERROR_CODE` | Route not found |

---

## ErrorWrapper Class

`src/app-manager/common/models/error.ts`

```typescript
export class ErrorWrapper {
  message: string;   // human-readable message
  status?: number;   // HTTP status code
  requestId?: string;
  code?: number | string;  // application error code
  uri?: string;      // request path
  method?: string;   // HTTP method
  client?: string;   // client identifier from request
}
```

All error-producing code must construct an `ErrorWrapper` and pass it to `next()`. The `globalErrorHandler` in `src/app-manager/middleware/error.ts` reads the `ErrorWrapper` to produce the standardised response shape.

---

## Validation Pattern

Each route version has a dedicated validator middleware:

| Validator | Route | Key checks |
|---|---|---|
| `validateKeysRequest` | v1 GET /config | verifyReferrer, isValidClient, UUID requestId |
| `validateKeysRequestV2` | v2 GET /config | verifyReferrer, isValidNamespace, UUID requestId |
| `validateKeysRequestV3` | v3 GET /config | same as V2 + lastUpdatedAt format check |
| `validateAddOrUpdateKeys` | POST /config/add-update-key | key, value, clientType, updatedBy present; clientType is valid |
| `validateDeleteKeys` | POST /config/delete-key | key and clientType present; clientType is valid |

Validators must call `next()` on success and `next(ErrorWrapper)` on failure. They must never send a response directly.

---

## Logging on API Calls

Every request logs:
- `requestId` on entry (via `logRequest` middleware)
- `requestId` + response payload on success (`successResponse` calls `logger.info`)
- `requestId` + error object on failure (in `catch` blocks and `globalErrorHandler`)

---

## Related Documentation

- [Security Implementation](security.md) — JWT verification details
- [Coding Standards](coding-standards.md) — response/error helper usage
- [System Architecture](architecture.md) — middleware execution order
