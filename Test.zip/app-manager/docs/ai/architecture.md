# System Architecture — App Manager

## Overview

App Manager is a single-process Express.js service that sits between mobile/web clients and a MongoDB configuration store. It handles authentication, input validation, caching, and configuration retrieval/mutation through three versioned API generations.

---

## High-Level Component Diagram

```
┌──────────────────────────────────────────────────────────────────┐
│                          Clients                                 │
│  Android App  │  iOS App  │  Bank Android  │  Bank iOS  │  BOP  │
└──────────┬───────────────────────────────────────────────────────┘
           │  HTTPS  (Authorization: <JWT>, requestId: <uuid>)
           ▼
┌──────────────────────────────────────────────────────────────────┐
│                    Express.js Application                        │
│                    (src/server.ts — port 4000)                   │
│                                                                  │
│  Global Middleware Stack (applied to every request):            │
│  ┌────────────────────────────────────────────────────────────┐  │
│  │ 1. body-parser (JSON + urlencoded)                         │  │
│  │ 2. Morgan access log (Bunyan)                              │  │
│  │ 3. checkAllowedMethods — rejects non-allowed HTTP methods  │  │
│  │ 4. xssMiddleware — inspects URL/params/query/cookies/body  │  │
│  │ 5. Helmet (CSP, Referrer-Policy, X-Frame-Options)          │  │
│  └────────────────────────────────────────────────────────────┘  │
│                                                                  │
│  Route Trees:                                                    │
│  ┌─────────────────────────────────────────────────────────────┐ │
│  │  GET  /ping                  ← liveness probe               │ │
│  │  GET  /health                ← health check                 │ │
│  │  GET  /dependency            ← dependency status            │ │
│  │                                                             │ │
│  │  /v1/api/app-manager/...     ← v1 external reads           │ │
│  │  /internal/v1/api/app-manager/... ← v1 internal writes     │ │
│  │  /ext/v2/api/app-manager/... ← v2 namespace reads          │ │
│  │  /ext/v3/api/app-manager/... ← v3 delta namespace reads    │ │
│  └─────────────────────────────────────────────────────────────┘ │
│                                                                  │
│  Global Error Handler (src/app-manager/middleware/error.ts)      │
└──────────────────────────┬───────────────────────────────────────┘
                           │
          ┌────────────────┴────────────────┐
          ▼                                 ▼
┌─────────────────────┐          ┌──────────────────────┐
│   NodeCache         │          │   MongoDB             │
│   (in-memory)       │          │   (Mongoose ODM)      │
│                     │          │                       │
│  Cache key pattern: │          │  Collection: keys     │
│  GET_CONFIG_<client>│          │  Fields:              │
│  (TTL: config.ttl)  │          │  key, value,          │
└─────────────────────┘          │  clientType, status,  │
                                 │  updatedBy,           │
                                 │  createdAt, updatedAt │
                                 └──────────────────────┘
```

---

## Request Flow — v1 External Config Read

```
Client
  │
  │  GET /v1/api/app-manager/config?client=androidapp
  │  Headers: Authorization: <JWT>, requestId: <uuid>
  ▼
[xssMiddleware]
  └─ Reject if URL/params/query/cookies/body contain XSS vectors → 401 ACCESS_DENIED
  │
  ▼
[validateKeysRequest]  (middleware/validations.ts)
  ├─ verifyReferrer() — reject unknown referrers
  ├─ isValidClient()  — must be one of: androidapp, iosapp, ppblAppClientAndroid, ppblAppClientIos
  └─ isValidUUID(requestId header)
  │
  ▼
[verifyToken]  (middleware/jwt-token.ts)
  ├─ Reject if Authorization header missing → 401 MISSING_TOKEN
  ├─ jwt.verify(token, JWT_SECRET) → decode JwtTokenPayload
  ├─ Validate iss === 'app-manager-service'
  ├─ Validate |now - iat| <= JWT_TOKEN_EXPIRY
  ├─ Validate requestId === header requestId (UUID)
  └─ Validate client === query ?client
  │
  ▼
[fetchKeys]  (controllers/keys.ts)
  ├─ Build cacheKey = GET_CONFIG_<client>
  ├─ If referrer present OR cache miss → query MongoDB (aggregate pipeline)
  │     $match: { clientType: client, status: 'active' }
  │     $sort: { updatedAt: -1 }
  │     $project: (filtered for non-BOP referrer)
  ├─ If cache hit → return cached data
  └─ Write DB result to cache; return 200 success response
```

---

## Request Flow — v2 External Config Read

```
Client
  │
  │  GET /ext/v2/api/app-manager/config?namespace=androidapp
  │  Headers: Authorization: <JWT>
  ▼
[xssMiddleware] → [validateKeysRequestV2]
  └─ validates namespace instead of client
  │
  ▼
[verifyTokenV2]  (middleware/jwt-token.ts)
  └─ Validates namespace claim in JWT (instead of client)
  │
  ▼
[fetchKeysV2]  (controllers/keys.ts)
  └─ Same cache + DB logic as v1 but keyed by namespace
```

---

## Request Flow — v3 Delta Config Read

```
Client
  │
  │  GET /ext/v3/api/app-manager/config?namespace=androidapp&lastUpdatedAt=<ISO>
  ▼
[xssMiddleware] → [validateKeysRequestV3]
  └─ validates lastUpdatedAt format in addition to namespace
  │
  ▼
[verifyTokenV2]
  │
  ▼
[fetchKeysV3]  (controllers/keys.ts)
  ├─ If lastUpdatedAt provided: bypass cache, query DB for keys updated since that timestamp
  │   Returns both updated keys AND a deletedList for client-side reconciliation
  ├─ If no lastUpdatedAt: use cache path same as v2
  └─ Cache key uses V3 suffix to keep v3 results isolated from v2 cache entries
```

---

## Internal Write Flow (v1 only)

```
Trusted internal caller
  │
  │  POST /internal/v1/api/app-manager/config/add-update-key
  │  Body: { key, value, clientType, updatedBy }
  ▼
[validateAddOrUpdateKeys] → [verifyTokenV2]
  │
  ▼
[addOrUpdateKeys]  (controllers/keys.ts)
  ├─ Validate key structure
  ├─ Upsert into MongoDB (findOneAndUpdate with upsert: true)
  └─ Invalidate cache for affected clientType
```

---

## Middleware Execution Order

```
Request arrives
      │
      ▼
1. body-parser
2. Morgan (access log)
3. checkAllowedMethods
4. xssMiddleware            ← global XSS gate
5. Helmet (security headers)
      │
      ▼
Route-specific middleware:
6. logRequest               ← structured request log
7. validateKeys[V2|V3]      ← query param & referrer validation
8. verifyToken[V2]          ← JWT signature + claims verification
      │
      ▼
9. Controller               ← cache check → DB query → response
      │
      ▼ (on error)
10. globalErrorHandler      ← normalises ErrorWrapper → JSON error response
```

---

## Database Design

### Collection: `keys`

| Field | Type | Notes |
|---|---|---|
| `key` | String (required) | Configuration key name |
| `value` | String (required) | Configuration value |
| `clientType` | String enum (required) | One of the four allowed client IDs |
| `status` | String enum (required) | `active` or `deleted` |
| `updatedBy` | String (required) | Identity of last modifier |
| `createdAt` | Date | Formatted on serialisation via `moment` |
| `updatedAt` | Date | Used for delta recall in v3 |

On serialisation (`toJSON`):
- `_id` is remapped to `id`
- `clientType` is exposed as `namespace` for v2/v3 consumers
- `_id`, `clientType` (original field), and `__v` are removed

---

## Caching Architecture

```
GET_CONFIG_<client>  ← v1 and v2 cache key pattern
GET_CONFIG_<client>V3 ← v3 isolated cache key

Cache is bypassed when:
  - request has a referrer query param (BOP portal path — needs fresh + paginated data)
  - request has lastUpdatedAt (v3 delta path — must read from DB)

Cache is populated when:
  - cache miss on standard read path
  - after add/update/delete operations (targeted invalidation for affected clientType)

TTL and checkperiod are loaded from runtime config:
  cache.ttl          (minutes, default 5)
  cache.checkperiod  (minutes, default 5)
```

---

## Security Architecture

```
Environment Variables (never in config files)
  MIDDLEWARE_APP_MANAGER_MOBILE_JWT_SECRET_KEY    ← v1 JWT verification
  MIDDLEWARE_APP_MANAGER_PPBLAPP_MOBILE_JWT_SECRET_KEY ← v2/v3 JWT verification
  MIDDLEWARE_APP_MANAGER_MONGO_USER
  MIDDLEWARE_APP_MANAGER_MONGO_PASSWORD
         │
         ▼
  src/config/index.ts injects these via lodash _.set() at startup
         │
         ▼
  Runtime config object (read-only after startup)
```

See [ADR-001](adr-versioned-routes-jwt-and-cache.md) for architectural decision rationale.

---

## Deployment Topology

### Container & Runtime

The service is packaged as a Docker image using a two-stage build:

| Stage | Base image | Purpose |
|---|---|---|
| `build` | `node:16.15.1-alpine3.14` | Install deps, compile TypeScript via Webpack, strip `src/` |
| production | `node:16.15.1-alpine3.14` | Minimal runtime image with compiled bundle only |

The compiled bundle is served by **PM2 4.2.3** inside the container. The server listens on **port 4000**.

### Environments

| Environment | Config file | Base URL | MongoDB replica | Cache TTL |
|---|---|---|---|---|
| Local dev | `dev-config.json` | `localhost:4000` | single node (no credentials) | 5 min |
| Staging (EKS) | `eks-mwite1-config.json` | `app-manager-internal-ite.paytmbank.com` | `rs0` (3-node) | 5 min |
| Production | `prod-config.json` | `app-manager.paytmbank.com` | `rs0` (3-node) | 10 min |
| Alternate prod | `mwprod-config.json` | — | `rs0` (3-node) | — |

### Production Infrastructure Diagram

```
Mobile / Web Clients
        │  HTTPS
        ▼
┌───────────────────────┐
│   Load Balancer / API │
│   Gateway             │
│   (TLS termination)   │
└──────────┬────────────┘
           │  HTTP  :4000
           ▼
┌──────────────────────────────────────┐
│   EKS Cluster                        │
│                                      │
│  ┌─────────────────────────────────┐ │
│  │  Pod: app-manager (Docker)      │ │
│  │  Node 16.15.1-alpine            │ │
│  │  PM2 process manager            │ │
│  │  Port 4000                      │ │
│  │                                 │ │
│  │  ┌─────────────────────────┐   │ │
│  │  │  NodeCache (in-memory)  │   │ │
│  │  │  TTL: 10 min (prod)     │   │ │
│  │  └─────────────────────────┘   │ │
│  └─────────────────────────────────┘ │
│                                      │
│  Secrets injected at pod startup     │
│  via environment variables:          │
│   - MOBILE_JWT_SECRET_KEY            │
│   - PPBLAPP_MOBILE_JWT_SECRET_KEY    │
│   - MONGO_USER / MONGO_PASSWORD      │
└───────────────────┬──────────────────┘
                    │  TCP :27017
                    ▼
┌──────────────────────────────────────┐
│   MongoDB Replica Set  (rs0)         │
│                                      │
│   mongodb-1-db.prod.paytmpb.io       │
│   mongodb-2-db.prod.paytmpb.io       │
│   mongodb-3-db.prod.paytmpb.io       │
│                                      │
│   Collection: appmanager.keys        │
└──────────────────────────────────────┘
```

### CI/CD Pipeline (Jenkins)

```
Git push
   │
   ▼
┌──────────────────────────────────────────────────────────┐
│  Jenkinsfile stages                                       │
│                                                          │
│  Pre Build  ← checkout scm + docker/prebuild.sh          │
│      │                                                   │
│      ▼                                                   │
│  Build      ← docker/build.sh  (yarn install + webpack)  │
│      │           Node 16.15.1 pinned via nodeJSInstall   │
│      ▼                                                   │
│  Package    ← docker build → image tagged                │
│               dockerregistry.paytmpb.io/paytmbank/       │
│               middleware-app-manager:<version>_<commit>  │
│      ▼                                                   │
│  Push       ← docker/push.sh → registry                 │
│      ▼                                                   │
│  Deploy     ← docker/deploy.sh → EKS pod rollout        │
└──────────────────────────────────────────────────────────┘

⚠ No lint, test, or security-scan gate currently exists in this pipeline.
  All quality gates are developer-side only (Husky pre-commit).
  See docs/ai/build-validation.md for the recommended gate additions.
```

### Observability

- **Structured logs** — Bunyan writes JSON logs to `/log/middleware-app-manager/` inside the container (volume-mounted in production).
- **Application metrics** — StatsD metrics are emitted to `custom-monitoring.default:8130` with prefix `BankAppManager.` (configured in environment JSON; collected by the internal monitoring platform).
- **Operational endpoints** (no auth required):
  - `GET /ping` — liveness probe
  - `GET /health` — health check
  - `GET /dependency` — dependency status

---

## Related Documentation

- [Repository Overview](repo-overview.md)
- [Security Implementation](security.md)
- [API & Error Handling](api-error-handling.md)
- [Build & Validation](build-validation.md)
- [ADR-001 — Versioned Routes, JWT Claims, and Cache Strategy](adr-versioned-routes-jwt-and-cache.md)
