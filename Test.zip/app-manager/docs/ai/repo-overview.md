# Repository Overview — App Manager

## Purpose

App Manager is a TypeScript/Express.js middleware service for **Paytm Payments Bank** mobile and web applications. It provides two core capabilities:

1. **Configuration Management** — stores, serves, and invalidates key-value configuration pairs scoped to specific client types (Android app, iOS app, Bank Android, Bank iOS).
2. **Authentication Gateway** — validates JWT tokens on every protected request and enforces client/namespace contract alignment between the incoming token and the requested API version.

The service sits between downstream mobile clients and the MongoDB configuration store, adding a caching layer (NodeCache) to avoid repeated database reads on hot read paths.

---

## Technology Stack

| Layer | Technology | Version |
|---|---|---|
| Runtime | Node.js | 16.15.1 LTS |
| Language | TypeScript | 5.8.3 (strict mode) |
| Framework | Express.js | 4.18.2 |
| Database | MongoDB + Mongoose | 5+ / ~5.10.0 |
| Authentication | `jsonwebtoken` | 9.0.2 |
| Security headers | Helmet | ^7.1.0 |
| XSS protection | `xss` | ^1.0.15 |
| In-memory cache | `node-cache` | ^5.1.2 |
| Logging | Bunyan + rotating-file-stream | 1.8.15 / 3.1.1 |
| Build | Webpack + ts-loader | 5.89.0 / 9.5.0 |
| Containerization | Docker | — |
| CI/CD | Jenkins | — |
| Code formatting | Prettier | 3.0.3 |

---

## Project Structure

```
app-manager/               ← service root
├── src/
│   ├── server.ts          ← Express app bootstrap, middleware wiring, route mounting
│   ├── config/
│   │   ├── index.ts       ← Config loader: reads JSON file, injects env-var secrets
│   │   ├── logger.ts      ← Bunyan logger + Morgan access log middleware
│   │   ├── child-logger.ts
│   │   └── constants.ts
│   └── app-manager/       ← Core domain
│       ├── constants.ts   ← Error codes, client IDs, JWT claim names, cache keys
│       ├── cache/
│       │   └── index.ts   ← NodeCache singleton (TTL and check-period from config)
│       ├── common/
│       │   └── models/
│       │       ├── error.ts        ← ErrorWrapper class
│       │       └── jwt-payload.ts  ← JwtTokenPayload / JwtTokenPayloadV2 interfaces
│       ├── controllers/
│       │   ├── keys.ts    ← fetchKeys, addOrUpdateKeys, deleteKeys handlers
│       │   ├── client.ts  ← client fetch handler
│       │   └── dependency.ts
│       ├── database/
│       │   ├── mongodb.ts          ← Mongoose connection with retry logic
│       │   └── models/
│       │       └── keys.model.ts   ← Keys schema (key, value, clientType, status, updatedBy)
│       ├── middleware/
│       │   ├── auth.ts      ← XSS middleware (inspects URL, params, query, cookies, body)
│       │   ├── common.ts    ← checkAllowedMethods, logRequest
│       │   ├── error.ts     ← globalErrorHandler, notFoundHandler
│       │   ├── jwt-token.ts ← verifyToken (v1), verifyTokenV2 (v2/v3)
│       │   └── validations.ts ← per-version request validators
│       ├── routes/
│       │   ├── health.ts / ping.ts / dependency.ts ← operational endpoints
│       │   ├── v1/
│       │   │   ├── index.routes.ts   ← mounts /v1/api/app-manager/config and internal routes
│       │   │   ├── config.routes.ts  ← GET config; POST add-update-key, delete-key (internal)
│       │   │   └── client.routes.ts  ← GET client (internal only)
│       │   ├── v2/
│       │   │   ├── index.routes.ts   ← mounts /api/app-manager/config under /ext/v2
│       │   │   └── config.routes.ts
│       │   └── v3/
│       │       ├── index.routes.ts   ← mounts /api/app-manager/config under /ext/v3
│       │       └── config.routes.ts
│       └── utils/
│           ├── index.ts        ← successResponse, errorResponse, input helpers
│           ├── keys.ts         ← cache helpers, DB query builders, delta logic
│           └── app-monitoring.ts ← StatsD metric increments
├── environment/
│   ├── dev-config.json
│   ├── eks-mwite1-config.json  ← Staging
│   ├── prod-config.json
│   └── mwprod-config.json
└── tools/
    ├── run-server.js
    ├── test.env
    ├── build/                  ← Webpack config helpers
    └── docker/                 ← Docker boot scripts

docker/                    ← Docker build, push, deploy scripts
docs/
├── ai/                    ← AI-assisted development documentation (this folder)
│   ├── repo-overview.md         ← this file
│   ├── architecture.md
│   ├── coding-standards.md
│   ├── api-error-handling.md
│   ├── security.md
│   ├── build-validation.md
│   ├── agent-workflow.md
│   ├── contribution-checklist.md
│   └── adr-versioned-routes-jwt-and-cache.md
└── REPORT_GENERATION_GUIDE.md
Jenkinsfile
AGENTS.md                 ← project conventions reference (root)
```

---

## Key Features

### 1. Configuration key-value store
- Keys are scoped to a `clientType` (androidapp, iosapp, ppblAppClientAndroid, ppblAppClientIos).
- Keys have an `active`/`deleted` status with soft-delete semantics.
- The `v3` API supports **delta retrieval** via `lastUpdatedAt` and `deletedList`, reducing payload for clients that already hold a snapshot.

### 2. Multi-version API
- **v1** — `client`-keyed contract, includes internal write routes (add/update/delete keys, client lookup).
- **v2** — `namespace`-keyed contract, external read-only.
- **v3** — `namespace`-keyed contract with delta support, external read-only.

See [ADR-001](adr-versioned-routes-jwt-and-cache.md) for the full rationale.

### 3. JWT-based authentication
- Every protected route requires an `Authorization` header containing a signed JWT.
- Token claims differ by version: `client` (v1) vs `namespace` (v2/v3).
- Tokens are validated for signature, issuer, `iat` window, and claim alignment.

### 4. In-memory caching
- `NodeCache` singleton caches read-path results.
- Cache bypassed for referrer-driven (BOP) requests and delta-mode (v3) requests that require fresh DB data.

### 5. Security hardening
- Helmet security headers (CSP, Referrer-Policy, X-Frame-Options).
- Global XSS middleware rejects any request whose URL, params, query, cookies, or body contain XSS vectors.
- Secrets (JWT keys, DB credentials) are never committed — injected via environment variables at runtime.

---

## Environment Configurations

| File | Environment |
|---|---|
| `dev-config.json` | Local development |
| `eks-mwite1-config.json` | Staging (EKS) |
| `prod-config.json` | Production |
| `mwprod-config.json` | Alternate production |

Config files contain non-secret settings. Secret values (JWT keys, DB credentials) are injected at startup via `process.env` entries listed in `src/config/index.ts`.

---

## Getting Started

```bash
# 1. Install dependencies
cd app-manager
yarn install

# 2. Set required environment variables
export MIDDLEWARE_APP_MANAGER_MOBILE_JWT_SECRET_KEY=<secret>
export MIDDLEWARE_APP_MANAGER_PPBLAPP_MOBILE_JWT_SECRET_KEY=<secret>
export MIDDLEWARE_APP_MANAGER_MONGO_USER=<user>
export MIDDLEWARE_APP_MANAGER_MONGO_PASSWORD=<password>

# 3. Run in development mode (builds with webpack then starts server)
yarn server:dev

# Server starts on port 4000
```

---

## Related Documentation

- [System Architecture](architecture.md)
- [Coding Standards](coding-standards.md)
- [API & Error Handling](api-error-handling.md)
- [Security Implementation](security.md)
- [Build & Validation](build-validation.md)
- [Agent Workflow](agent-workflow.md)
- [Contribution Checklist](contribution-checklist.md)
- [ADR-001 — Versioned Routes, JWT Claims, and Cache Strategy](adr-versioned-routes-jwt-and-cache.md)
