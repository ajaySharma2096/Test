# Coding Standards — App Manager

## TypeScript Configuration

The project uses **TypeScript 5.8.3 in strict mode**. The `tsconfig.json` enforces:
- `strict: true` — enables all strict type-checking flags
- Path aliases for clean imports (`@app-manager/*`, `@config/*`)

**Never suppress TypeScript errors with `@ts-ignore` unless you have an explicit comment explaining why and there is no alternative.** (The only current exception is the `@ts-ignore` on the mongoose import in `server.ts` which exists because of a side-effect-only import.)

---

## No `any` Policy

Do not use `any` without a written justification in a comment on the same line.

```typescript
// ❌ Forbidden
const data: any = fetchFromDB();

// ✅ Required: explicit type
const data: { list: ConfigKey[]; total: number } = await fetchFromDB();

// ✅ Acceptable with justification
const pipeline: any = [{ $match }, { $sort }]; // mongoose aggregate typings require any[]
```

---

## Naming Conventions

| Construct | Convention | Example |
|---|---|---|
| Variable / function | `camelCase` | `fetchKeys`, `cacheKey`, `clientRequestId` |
| Interface / type | `PascalCase` | `JwtTokenPayload`, `IRequestIAT`, `IKeys` |
| Class | `PascalCase` | `ErrorWrapper` |
| Enum-like const object | `SCREAMING_SNAKE_CASE` | `ERROR_STATUS`, `JWT`, `CLIENT`, `METRIX` |
| File | `kebab-case` | `jwt-token.ts`, `keys.model.ts`, `app-monitoring.ts` |
| Route path segment | `kebab-case` | `/add-update-key`, `/delete-key` |
| MongoDB collection document interface | `I` prefix | `IKeys` |
| Request interface extension | `I` prefix | `IRequestIAT` |

---

## File Organisation

### Module boundaries
Each directory has a single responsibility. Do not mix concerns across directories:

| Directory | Allowed content |
|---|---|
| `controllers/` | Route handler functions only — read from request, call utilities/DB, write response |
| `middleware/` | Express middleware functions only — validate, authenticate, transform, handle errors |
| `routes/` | Router definitions only — wire middleware and controllers onto paths |
| `database/models/` | Mongoose schema and model definitions only |
| `cache/` | Cache singleton — no business logic |
| `utils/` | Pure helpers — no Express request/response objects (except `successResponse`/`errorResponse`) |
| `common/models/` | Shared TypeScript interfaces and lightweight classes only |
| `constants.ts` | String literals, error code maps, client ID maps — no logic |
| `config/` | Configuration loading and logger instantiation only |

### Import paths
Always use the configured path aliases. Never use relative `../../../` chains.

```typescript
// ✅ Correct
import logger from '@config/logger';
import { ErrorWrapper } from '@app-manager/common/models/error';
import { appManagerCache } from '@app-manager/cache';

// ❌ Avoid
import logger from '../../../config/logger';
```

---

## Error Handling Pattern

Every function that performs I/O must be wrapped in try/catch. Errors must be propagated to the next middleware via `next(error)`, never swallowed silently.

```typescript
// ✅ Required pattern in middleware/controllers
export const myMiddleware = (req: Request, res: Response, next: NextFunction) => {
  const clientRequestId = req.header('requestId') as string;
  try {
    // ... logic ...
    next();
  } catch (error) {
    const err = new ErrorWrapper(
      error?.message || ERROR_STATUS.INTERNAL_ERROR.RESPONSE.MESSAGE,
      error?.status  || ERROR_STATUS.INTERNAL_ERROR.HTTP_RESPONSE,
      error?.requestId || clientRequestId,
      error?.code  || ERROR_STATUS.INTERNAL_ERROR.RESPONSE.ERROR_CODE,
      error?.uri   || req?.originalUrl,
      error?.method || req?.method,
      error?.client || req?.query?.client as string,
    );
    return next(err);
  }
};
```

Do **not** call `res.json()` or `res.send()` directly for error cases in controllers or middleware. Always pass `ErrorWrapper` instances to `next()` so the global error handler can produce a consistent response shape.

---

## Logging Pattern

Use the Bunyan logger from `@config/logger`. Always include a `requestId` field when one is available.

```typescript
// ✅ Correct — structured log with requestId
logger.info({
  requestId: clientRequestId,
  response: data,
});

logger.error({
  requestId: clientRequestId,
  error: err,
});

// ❌ Avoid plain string logs in production code
logger.info('Request processed');
```

Log levels:
- `logger.info` — successful operations, response data
- `logger.error` — caught exceptions, validation failures, authentication errors
- `console.log` — allowed only in startup/boot context (`server.ts`, `mongodb.ts`)

---

## Constants Pattern

All magic strings and numeric error codes live in `src/app-manager/constants.ts`. Do not inline string literals in middleware or controllers.

```typescript
// ✅ Use constants
throw new ErrorWrapper(
  ERROR_STATUS.ACCESS_DENIED.RESPONSE.MESSAGE,
  ERROR_STATUS.ACCESS_DENIED.HTTP_RESPONSE,
  requestId,
  ERROR_STATUS.ACCESS_DENIED.RESPONSE.ERROR_CODE.MISSING_TOKEN,
);

// ❌ Inline strings
throw new ErrorWrapper('Access Denied', 401, requestId, 1001);
```

When adding new error codes, add them to the relevant section in `constants.ts` first, then reference them from code.

---

## Response Shape

All HTTP responses go through `successResponse()` or `errorResponse()` from `@app-manager/utils`. Do not construct raw response objects in controllers.

```typescript
// ✅ Success
return successResponse(data, _res, clientRequestId);

// ✅ Error (usually via next(err), not direct call)
return errorResponse(err, _res, clientRequestId);
```

---

## Async/Await

Prefer `async/await` over `.then()/.catch()` chains. All controller functions are `async`. Do not let unhandled promise rejections escape — always `await` async calls inside try/catch.

---

## Prettier Formatting

The project uses Prettier with `lint-staged` on commit. The configuration is in `.prettierrc`. Run before committing:

```bash
npx prettier --write "src/**/*.ts"
```

Prettier is not optional — malformatted code will be reformatted automatically on the pre-commit hook (`husky` + `lint-staged`).

---

## Code Review Criteria

Before submitting any change, verify:

- [ ] No `any` without justification comment
- [ ] All errors passed to `next()` as `ErrorWrapper` instances
- [ ] All logs include `requestId`
- [ ] No new string literals — constants added to `constants.ts`
- [ ] Import paths use aliases, not relative `../..` chains
- [ ] TypeScript compiles cleanly (`yarn build:dev`)
- [ ] Prettier passes (`npx prettier --check "src/**/*.ts"`)

---

## Related Documentation

- [Repository Overview](repo-overview.md)
- [API & Error Handling](api-error-handling.md)
- [Agent Workflow](agent-workflow.md)
