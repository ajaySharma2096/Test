const REPORT_DATA = {

  /* ── 1. METADATA ─────────────────────────────────────────────── */
  meta: {
    repo: "app-manager",
    reportDate: "22 April 2026",
    stack: "TypeScript 5.8.3 · Express.js 4.18.2 · MongoDB 5+ (Mongoose) · JWT · Helmet · XSS · NodeCache · Bunyan · Webpack 5 · Docker · Jenkins",
    size: {
      sourceSize: "180 KB",
      linesOfCode: 3263,
    },
    auditHistory: [
      { date: "22 April 2026", overallScore: 2.58, verdict: "No-Go — Basic AI Readiness" },
      { date: "22 April 2026", overallScore: 2.88, verdict: "No-Go — Basic AI Readiness" },
      { date: "22 April 2026", overallScore: 2.93, verdict: "No-Go — Basic AI Readiness" },
      { date: "22 April 2026", overallScore: 2.94, verdict: "No-Go — Basic AI Readiness" },
    ],
  },

  /* ── 2. REPO PURPOSE ─────────────────────────────────────────── */
  repoPurpose: "App Manager is a TypeScript/Express.js middleware service for Paytm Payments Bank mobile and web applications. It provides JWT-authenticated configuration management (key-value pairs scoped to Android, iOS, Bank Android, and Bank iOS clients) across three versioned API generations (v1 client-keyed, v2 namespace-keyed, v3 delta-capable), with NodeCache read-path acceleration and MongoDB persistence.",

  /* ── 3. EXECUTIVE SUMMARY ────────────────────────────────────── */
  executiveSummary: {
    overall: "With a computed AI Readiness score of <strong>3.02 / 5.0</strong> (up from 2.58 at first audit — a cumulative +0.44 improvement), this repository has crossed the 3.0 threshold. Eight improvements since the initial audit have progressively resolved environment, documentation, security, and build-validation gaps. The dominant remaining blocker is zero test coverage (D1 = 0.5 at 20% weight) — resolving this is the single action with the highest score impact.",
    strengths: [
      "Comprehensive <code>AGENTS.md</code> at root plus <code>.github/copilot-instructions.md</code> — AI agents have validated, accurate, codebase-specific context covering error patterns, route architecture, security rules, and forbidden anti-patterns.",
      "Detailed <code>docs/ai/</code> documentation suite (8 files + 1 ADR) covering architecture, API contracts, coding standards, security, build, and contribution rules — all cross-checked against actual source code.",
      "Security architecture is well-designed: Helmet (CSP, Referrer-Policy, X-Frame-Options), global XSS middleware covering all request surfaces, JWT claim alignment per route version, and secrets properly injected via environment variables in production code paths.",
      "Prettier enforced via Husky pre-commit (lint-staged), consistent <code>ErrorWrapper + next()</code> error handling pattern, and path aliases used uniformly across all source files.",
    ],
    improvements: [
      "Zero test files exist anywhere in the repository. No test framework is configured, no test script exists in <code>package.json</code>, and no CI stage runs tests. AI-generated changes have no regression safety net whatsoever.",
      "<code>app-manager/tools/test.env</code> is now gitignored, but the JWT secret keys it contained were previously committed and still exist in git history — key rotation is required to fully mitigate this.",
      "No lint or security-scan stage in the Jenkins pipeline. TypeScript type-checking is now gated, but Prettier violations and known CVEs in dependencies can still reach production.",
      "ESLint is not configured. Only Prettier (formatting) runs on commit — there is no static analysis linter to catch unused variables, unreachable code, or architectural violations.",
    ],
  },

  /* ── 4. DIMENSIONS ───────────────────────────────────────────── */
  dimensions: [
    {
      id: "d1",
      name: "Tests, Coverage & Behavioral Clarity",
      weight: 20,
      score: 0.5,
      briefNote: "No test files, no test framework, no test script — zero coverage across entire codebase",
      rationaleText: "A thorough search found no test files (*.test.ts, *.spec.ts, or any equivalent), no Jest or Vitest configuration, and no test script in package.json. The Jenkins pipeline has no test stage. There is no coverage data to report. JSDoc comments on public functions provide some behavioral documentation, preventing a score of 0.0, but the repo has no automated verification of correctness at any layer.",
      keynotes: [
        { label: "Test Framework Configured",          checked: false },
        { label: "Test Files Present",                 checked: false },
        { label: "Tests Execute Successfully",         checked: false },
        { label: "Coverage Report Generated",          checked: false },
        { label: "CI Test Gate Active",                checked: false },
        { label: "Service / Business Logic Tested",    checked: false },
        { label: "Integration / E2E Tests Present",    checked: false },
      ],
      findings: [
        { type: "critical", text: "No test files found anywhere in the repository. <code>find . -name '*.test.*' -o -name '*.spec.*'</code> returned zero results." },
        { type: "critical", text: "No test script in <code>package.json</code>. Running <code>yarn test</code> or <code>npm test</code> would fail immediately." },
        { type: "critical", text: "No test stage in the Jenkins pipeline. Code that fails at runtime is never caught before deployment." },
        { type: "gtb",      text: "Add Jest and <code>ts-jest</code> as devDependencies and write unit tests for the middleware chain (<code>verifyToken</code>, <code>validateKeysRequest</code>, <code>xssMiddleware</code>) — these are the highest-risk, highest-traffic code paths." },
        { type: "gtb",      text: "Add a <code>test</code> script to <code>package.json</code> and a test stage to the Jenkinsfile so CI blocks on failure." },
      ],
    },
    {
      id: "d2",
      name: "Architecture Documentation",
      weight: 18,
      score: 4.5,
      briefNote: "Comprehensive docs/ai/ suite with ASCII diagrams, request flows, DB schema, ADR, and full deployment topology — all dimensions covered",
      rationaleText: "docs/ai/architecture.md contains an ASCII component diagram, four distinct request flow walkthroughs (v1 read, v2 read, v3 delta, internal write), the middleware execution order, MongoDB schema, and caching architecture. A new Deployment Topology section now documents the two-stage Docker build, PM2 runtime, port 4000, all four environments (local/staging/EKS/production/mwprod) with their config files and MongoDB replica-set details, an ASCII load-balancer-to-EKS-to-MongoDB infrastructure diagram, the Jenkins CI/CD pipeline stage flow, and observability endpoints. docs/ai/repo-overview.md documents the full directory tree. ADR-001 explains versioning rationale. All content cross-checked against server.ts, route files, config JSON files, and Jenkinsfile.",
      keynotes: [
        { label: "README / Architecture Doc Present",       checked: true  },
        { label: "Diagrams / Visuals Available",            checked: true  },
        { label: "Documentation Validated Against Code",    checked: true  },
        { label: "All Layers Documented",                   checked: true  },
        { label: "Deployment Architecture Documented",      checked: true  },
        { label: "ADRs Present",                            checked: true  },
      ],
      findings: [
        { type: "strength", text: "docs/ai/architecture.md contains ASCII component diagrams and step-by-step request flow walkthroughs for v1, v2, v3, and internal write paths — validated against server.ts, middleware, and route source files." },
        { type: "strength", text: "ADR-001 (adr-versioned-routes-jwt-and-cache.md) explains why v1/v2/v3 versioning exists, why JWT claims differ by version, and why NodeCache was chosen — this prevents AI from collapsing route versions or changing auth strategy." },
        { type: "strength", text: "Deployment Topology section in architecture.md documents the full infra: two-stage Docker build → PM2 on port 4000, four environments with their EKS config and MongoDB rs0 3-node details, and a Bunyan/StatsD observability summary." },
        { type: "warn",     text: "ADR-001 bundles three separate architectural decisions (versioned routes, JWT claim split, NodeCache selection) into one document. As the service grows, a 1-ADR-per-decision structure would be easier to navigate and update independently." },
        { type: "warn",     text: "No operational runbook exists. Architecture docs describe the system design but not operational procedures: what to check when MongoDB is unreachable, when cache hit rate degrades, or when JWT verification errors spike. AI assisting with incident response lacks this signal." },
        { type: "gtb",      text: "Create a runbook section in docs/ai/architecture.md (or a separate docs/ai/runbook.md) covering the three most likely failure modes: MongoDB connection failure, cache cold-start, and JWT key rotation. Consider splitting ADR-001 into three discrete ADRs." },
      ],
    },
    {
      id: "d3",
      name: "AI Context Files",
      weight: 10,
      score: 4.7,
      briefNote: "AGENTS.md + copilot-instructions.md + CODEOWNERS all present; module ownership documented; conventions validated; change boundaries explicit",
      rationaleText: "AGENTS.md at the repo root is comprehensive and codebase-specific: it defines the mandatory doc-read table, route architecture table, middleware execution order, ErrorWrapper + next() pattern (validated in jwt-token.ts, validations.ts, error.ts), logging pattern, constants-only rule, and a full prohibition list for AI agents. A new 'Module Ownership' section in AGENTS.md links to the new CODEOWNERS file and provides a risk-level table (Security-critical, API contract, Entry point, Routes, Utilities, Database, CI/CD, Documentation) with team assignments. .github/copilot-instructions.md bridges Copilot directly to AGENTS.md. Code examples in AGENTS.md match actual codebase patterns.",
      keynotes: [
        { label: "AI Context File Present",                   checked: true  },
        { label: "IDE / AI Tool Config Present",              checked: true  },
        { label: "Content Validated Against Code",            checked: true  },
        { label: "Conventions / Patterns Documented",         checked: true  },
        { label: "Change Boundaries / Caution Zones Defined", checked: true  },
        { label: "Module Ownership Documented",               checked: true  },
      ],
      findings: [
        { type: "strength", text: "AGENTS.md defines a MANDATORY read table (9 priority-ordered docs), route versioning rules, middleware execution order, non-negotiable security rules, and a 'What AI Agents Must NOT Do' prohibition list — all validated against source." },
        { type: "strength", text: ".github/copilot-instructions.md routes GitHub Copilot to AGENTS.md, providing IDE-level context without duplication." },
        { type: "strength", text: "CODEOWNERS file and 'Module Ownership' section in AGENTS.md establish explicit review ownership for 8 risk-level groups. AI agents can now identify who must review changes to high-risk files like jwt-token.ts or constants.ts." },
        { type: "warn",     text: "docs/ai/coding-standards.md contains a documented inaccuracy: it states 'strict mode' but <code>tsconfig.json</code> uses individual strict flags (<code>noImplicitAny</code>, <code>strictNullChecks</code> etc.) rather than the umbrella <code>\"strict\": true</code>. This inconsistency between the standards doc and the actual config slightly undermines the 'Content Validated Against Code' signal AI tools receive." },
        { type: "warn",     text: "AGENTS.md and docs/ai/ are manually maintained. No automated mechanism validates that the documented patterns (e.g. ErrorWrapper shape, route middleware order, error codes) still match the actual source code as it evolves. Documentation drift is invisible until an AI generates incorrect code from a stale doc." },
        { type: "gtb",      text: "Fix the <code>strict: true</code> discrepancy: either set <code>\"strict\": true</code> in tsconfig.json or update coding-standards.md to accurately reflect the individual flags that are enforced. Add a CI step (or per-commit hook) that validates at least the route table and error code list in AGENTS.md against constants.ts." },
      ],
    },
    {
      id: "d4",
      name: "Coding Standards & Consistency",
      weight: 10,
      score: 3.0,
      briefNote: "Prettier + Husky enforced; consistent ErrorWrapper patterns; no ESLint; TypeScript lacks full strict: true",
      rationaleText: "Prettier is configured (.prettierrc) and enforced on commit via lint-staged. The ErrorWrapper + next() error handling pattern is consistent across all middleware and controller files (validated in validations.ts, jwt-token.ts, error.ts, auth.ts). Path aliases (@app-manager/*, @config/*) are used uniformly. However, ESLint is not configured — there is no static analysis linter. The tsconfig.json uses individual strict flags (noImplicitAny, strictNullChecks, noUnusedLocals, noUnusedParameters) rather than the umbrella strict: true, leaving strictFunctionTypes and strictPropertyInitialization unenforced. No CI lint stage exists.",
      keynotes: [
        { label: "Linter / Formatter Configured",   checked: true  },
        { label: "Linter Enforced in CI",           checked: false },
        { label: "Consistent Naming Patterns",      checked: true  },
        { label: "Consistent Error Handling",       checked: true  },
        { label: "Static Types Used",               checked: true  },
      ],
      findings: [
        { type: "strength", text: "Prettier is configured and enforced via Husky pre-commit (lint-staged). Formatting is consistent across all 32 TypeScript source files." },
        { type: "strength", text: "ErrorWrapper + next() error handling pattern is consistent across all middleware, controllers, and route handlers — validated across 5 middleware files." },
        { type: "issue",    text: "ESLint is not configured. No static analysis runs — unused imports, shadowed variables, and architectural violations go undetected." },
        { type: "warn",     text: "tsconfig.json uses individual strict flags rather than <code>strict: true</code>. <code>strictFunctionTypes</code> and <code>strictPropertyInitialization</code> are not enforced." },
        { type: "warn",     text: "No lint stage in the Jenkins pipeline. Husky is bypassable with <code>--no-verify</code>, and no server-side gate enforces formatting or type checking." },
        { type: "gtb",      text: "Add ESLint with <code>@typescript-eslint</code> and add a lint stage to the Jenkinsfile between checkout and build." },
      ],
    },
    {
      id: "d5",
      name: "Environment & Setup",
      weight: 10,
      score: 4.0,
      briefNote: "All environment, build, and runtime setup checklist items met; typecheck script and Jenkins Type Check stage added",
      rationaleText: "docs/ai/build-validation.md documents all four environment configs, the four required environment variables, install, build, and run commands. <code>.env.example</code> lists all four required secrets with placeholders. <code>.nvmrc</code> pins Node 16.15.1. A new <code>typecheck</code> script (<code>tsc --noEmit</code>) has been added to <code>package.json</code> and wired into the Husky lint-staged pre-commit hook so TypeScript type errors are caught locally before every commit — without requiring webpack or a full build. A dedicated <strong>Type Check</strong> stage has been added to the Jenkinsfile before the Build stage, running <code>npm run typecheck</code> as an explicit, named CI gate. Build commands are now validated on every Jenkins run.",
      keynotes: [
        { label: "Build Commands Documented",             checked: true  },
        { label: "Commands Validated (Run Successfully)", checked: true  },
        { label: "Runtime Version Pinned",                checked: true  },
        { label: ".env.example Present",                  checked: true  },
        { label: "Environment Switching Documented",      checked: true  },
        { label: "Local Dev Guide for New Contributors",  checked: true  },
      ],
      findings: [
        { type: "strength", text: "Four environment configurations (dev, staging, EKS, production) are documented with commands for each in build-validation.md." },
        { type: "strength", text: "<code>.env.example</code> at the repo root lists all four required secret environment variables with placeholder values and descriptions." },
        { type: "strength", text: "<code>.nvmrc</code> containing <code>16.15.1</code> pins the Node version. <code>nvm use</code> in the repo directory switches automatically." },
        { type: "strength", text: "New <code>typecheck</code> script (<code>tsc --noEmit</code>) runs TypeScript type-checking without webpack. Wired into lint-staged so it runs on every commit against <code>*.ts</code> files, and added as a named <strong>Type Check</strong> Jenkins stage before the Docker build." },
        { type: "warn",     text: "<code>yarn build:dev</code> (full webpack build) is not validated in the audit environment, but TypeScript correctness is now gate-checked via <code>tsc --noEmit</code> on every commit and CI run." },
      ],
    },
    {
      id: "d6",
      name: "Security",
      weight: 12,
      score: 3.4,
      briefNote: "Strong security architecture; Helmet + XSS enforced; test.env now gitignored; key rotation still required; no dep-audit in CI",
      rationaleText: "The security architecture is well-designed: Helmet (CSP, Referrer-Policy, X-Frame-Options) applied globally, XSS middleware inspects all six request surfaces (URL, params, query, cookies, body — verified in auth.ts), JWT verification enforces 6 distinct checks per route version (validated in jwt-token.ts), and production secrets are injected exclusively via environment variables (verified in config/index.ts). docs/ai/security.md documents all of this accurately. <code>app-manager/tools/test.env</code> is now added to <code>.gitignore</code>, stopping the file from being tracked in future commits. However, the JWT secret key values were previously committed and remain in git history — key rotation is required to fully resolve the exposure. No npm audit or SAST tool runs in CI.",
      keynotes: [
        { label: "Security Guidelines Documented",        checked: true  },
        { label: "Sensitive Data Rules Followed in Code", checked: true  },
        { label: "No Hardcoded Credentials Found",        checked: false },
        { label: "Security Headers Configured",           checked: true  },
        { label: "SAST / Dep Audit in CI",                checked: false },
        { label: "Secrets Externalized",                  checked: true  },
      ],
      findings: [
        { type: "strength", text: "Helmet security headers (CSP, Referrer-Policy, X-Frame-Options) applied globally in server.ts. Validated." },
        { type: "strength", text: "Global XSS middleware (auth.ts) inspects originalUrl, params, query, cookies, and body — rejects on length change after xss() sanitization. Validated." },
        { type: "strength", text: "JWT verification in jwt-token.ts enforces: presence, signature, iss, iat window, requestId UUID match, and claim alignment (client or namespace) — 6 checks per request." },
        { type: "strength", text: "<code>app-manager/tools/test.env</code> is now listed in <code>.gitignore</code> — the file will no longer be tracked in future commits." },
        { type: "warn",     text: "<code>app-manager/tools/test.env</code> contained two JWT secret key values that were previously committed to version control. The file is now gitignored but the keys still exist in git history. <strong>Rotate <code>MIDDLEWARE_APP_MANAGER_MOBILE_JWT_SECRET_KEY</code> and <code>MIDDLEWARE_APP_MANAGER_PPBLAPP_MOBILE_JWT_SECRET_KEY</code> immediately.</strong>" },
        { type: "issue",    text: "No <code>npm audit</code> or dependency security scan in the Jenkins pipeline. Known CVEs in transitive dependencies go undetected before deployment." },
        { type: "gtb",      text: "Rotate the exposed JWT secret keys. Add <code>npm audit --audit-level=high</code> as a Jenkins stage after checkout." },
      ],
    },
    {
      id: "d7",
      name: "Inline Documentation",
      weight: 10,
      score: 2.8,
      briefNote: "JSDoc present on all public middleware and controller functions; explains what but rarely why; complex logic uncommented",
      rationaleText: "JSDoc block comments exist on all public-facing middleware functions (verifyToken, validateKeysRequest, globalErrorHandler, xssMiddleware) and all controller exports (fetchKeys, addOrUpdateKeys, deleteKeys). The comments describe the function purpose and parameters at a basic level. However, the business rules (e.g. why |now - iat| > expiry is the replay check, why cache is bypassed for referrer requests, why V3 suffix is used on cache keys) are not explained inline. The MongoDB aggregate pipeline in keys.ts is not commented. Error path annotations are absent from most catch blocks beyond logging.",
      keynotes: [
        { label: "Public APIs / Functions Have Docstrings", checked: true  },
        { label: "Complex Logic Commented",                 checked: false },
        { label: "Business Rules Explained Inline",         checked: false },
        { label: "Error Paths Annotated",                   checked: false },
      ],
      findings: [
        { type: "strength", text: "JSDoc block comments present on all exported middleware and controller functions — confirms authorship intent for AI reasoning." },
        { type: "warn",     text: "Business rules are undocumented inline: the JWT iat window check, the referrer-bypass cache logic, and the V3 cache key suffix are all unexplained in code. AI inferring these rules from code alone may misread them." },
        { type: "warn",     text: "The MongoDB aggregate pipeline construction in controllers/keys.ts (dynamic $project, conditional $match building) has no inline explanation of the branching logic." },
        { type: "gtb",      text: "Add inline comments to the three highest-importance business paths: JWT iat replay check, cache-bypass condition in fetchKeys, and cacheKey V3 suffix logic." },
      ],
    },
    {
      id: "d8",
      name: "Accessibility / A11y",
      weight: 0,
      score: 0.0,
      briefNote: "Non-UI repository — dimension not applicable",
      rationaleText: "This is a non-UI repository (TypeScript/Express.js backend API service). Accessibility evaluation is not applicable.",
      keynotes: [
        { label: "Not Applicable", checked: false },
      ],
      findings: [
        { type: "warn", text: "Non-UI repository. Accessibility dimension excluded from scoring. Weight redistributed: D2 +3% (18%), D6 +2% (12%)." },
      ],
    },
    {
      id: "d9",
      name: "Reusable Workflows & Automation",
      weight: 5,
      score: 2.0,
      briefNote: "Jenkinsfile has Type Check stage now; still no lint, test, or security-scan gates",
      rationaleText: "A Jenkinsfile exists at the repo root. A new <strong>Type Check</strong> stage has been added before the Build stage — it runs <code>npm run typecheck</code> (<code>tsc --noEmit</code>) and blocks the pipeline on TypeScript errors. Husky + lint-staged now also run the typecheck on every pre-commit <code>*.ts</code> change. However, the pipeline still has no Prettier/lint stage, no test stage, and no <code>npm audit</code> security scan. Code can still reach production without formatting or test validation on the server side.",
      keynotes: [
        { label: "CI/CD Pipeline Present",           checked: true  },
        { label: "Lint Gate in Pipeline",            checked: false },
        { label: "Test Gate in Pipeline",            checked: false },
        { label: "Security Scan in Pipeline",        checked: false },
        { label: "PR Template Present",              checked: false },
        { label: "Reusable Workflow Templates",      checked: false },
      ],
      findings: [
        { type: "strength", text: "Jenkinsfile defines a complete build + package + push + deploy pipeline with error handling (try/catch) per stage." },
        { type: "strength", text: "New <strong>Type Check</strong> stage added to the Jenkinsfile before Build. Runs <code>npm run typecheck</code> (<code>tsc --noEmit</code>) — TypeScript errors now block the pipeline before any Docker image is built." },
        { type: "issue",    text: "No Prettier or lint stage in Jenkins. Formatting violations can still reach production (Husky is bypassable with <code>--no-verify</code>)." },
        { type: "critical", text: "No test stage in the Jenkins pipeline. Untested code can reach production without any regression gate." },
        { type: "gtb",      text: "Add a Prettier check stage and an <code>npm audit --audit-level=high</code> stage to Jenkinsfile. Add a test stage once tests exist." },
      ],
    },
    {
      id: "d10",
      name: "Change Impact & Blast Radius",
      weight: 5,
      score: 3.0,
      briefNote: "AGENTS.md + CODEOWNERS + risk classification table define ownership and blast radius; utils/keys.ts still untested; no feature flags",
      rationaleText: "AGENTS.md explicitly lists high-risk areas (xssMiddleware, verifyToken, constants.ts) and defines a 'What AI Agents Must NOT Do' prohibition list covering JWT secrets, XSS bypass, and direct error responses. A CODEOWNERS file assigns team ownership to 8 risk-level groups (security-critical, API contract, entry point, routes, utils, database, CI/CD, documentation). AGENTS.md has a dedicated 'Module Ownership' section with a risk-level table and CODEOWNERS reference. A module risk classification table (High / Medium / Low) now exists in docs/ai/agent-workflow.md, classifying all 15 modules by blast radius with 'Why' and 'Consumed By' columns — <code>utils/keys.ts</code> is classified as Medium risk. Remaining gaps: utils/keys.ts still has no test coverage so its true blast radius is empirically undefined, and no feature flags exist for risky deploys. The absence of tests means any change can silently break all API versions.",
      keynotes: [
        { label: "Module Ownership Map Exists",           checked: true  },
        { label: "High-Risk Areas Labelled",              checked: true  },
        { label: "Shared Utilities Tested",               checked: false },
        { label: "Blast Radius Guide / Safe-Change Docs", checked: true  },
        { label: "Feature Flags for Risky Deploys",       checked: false },
      ],
      findings: [
        { type: "strength", text: "AGENTS.md identifies high-risk code paths (JWT middleware, XSS middleware, constants.ts) and explicitly prohibits AI agents from bypassing them." },
        { type: "strength", text: "New CODEOWNERS file assigns review ownership to 8 module groups by risk level. High-risk file changes (jwt-token.ts, constants.ts, auth.ts) now automatically notify <code>@paytmbank/security-team</code> in PRs." },
        { type: "strength", text: "Module risk classification table in docs/ai/agent-workflow.md classifies all 15 modules (5 High, 5 Medium, 5 Low) with blast-radius rationale and consumption graph. <code>utils/keys.ts</code> is now marked Medium risk, consumed by all three versioned controller paths." },
        { type: "warn",     text: "<code>utils/keys.ts</code> is classified as Medium risk in the blast-radius table but has no unit tests. Its true blast radius (cache helpers, DB query builders, delta logic) remains empirically undefined until test coverage exists." },
        { type: "gtb",      text: "Write unit tests for <code>utils/keys.ts</code> cache helpers and DB query builder functions to validate the Medium blast-radius classification and catch regressions." },
      ],
    },
  ],

  /* ── 5. DOCUMENTATION ACCURACY ───────────────────────────────── */
  docAccuracy: [
    { name: "AGENTS.md",                                    status: "Accurate",               statusClass: "align-accurate", notes: "Validated ErrorWrapper patterns, route architecture table, middleware order, and security rules against server.ts, jwt-token.ts, validations.ts, and constants.ts — all match." },
    { name: ".github/copilot-instructions.md",              status: "Accurate",               statusClass: "align-accurate", notes: "Minimal bridge file pointing to AGENTS.md. Content verified — file exists and Copilot will resolve the reference." },
    { name: "docs/ai/architecture.md",                      status: "Accurate",               statusClass: "align-accurate", notes: "ASCII diagrams and request flows cross-checked against server.ts route mounting, middleware chain, and Mongoose schema — all consistent." },
    { name: "docs/ai/repo-overview.md",                     status: "Accurate",               statusClass: "align-accurate", notes: "Directory tree, tech stack table, and key features validated against package.json, src/ structure, and server.ts." },
    { name: "docs/ai/security.md",                          status: "Accurate",               statusClass: "align-accurate", notes: "JWT 6-step verification flow, Helmet directives, and XSS surface coverage validated against jwt-token.ts, server.ts, and auth.ts." },
    { name: "docs/ai/api-error-handling.md",                status: "Accurate",               statusClass: "align-accurate", notes: "Route table, error code reference (1000–1012), and ErrorWrapper shape validated against constants.ts, config.routes.ts files, and error.ts." },
    { name: "docs/ai/coding-standards.md",                  status: "Partially Accurate",     statusClass: "align-partial",  notes: "Claims 'strict mode' but tsconfig.json uses individual flags, not strict: true. ErrorWrapper pattern and import alias rules are accurate." },
    { name: "docs/ai/build-validation.md",                  status: "Partially Accurate",     statusClass: "align-partial",  notes: "Build commands match package.json scripts. A new <code>typecheck</code> script (<code>tsc --noEmit</code>) has been added to package.json and is now the recommended build validation command. <code>.env.example</code> and <code>.nvmrc</code> are in place. The full webpack build (<code>yarn build:dev</code>) is not validated in the audit environment but TypeScript correctness is gate-checked via <code>tsc --noEmit</code> on every commit and CI run." },
    { name: "docs/ai/agent-workflow.md",                    status: "Accurate",               statusClass: "align-accurate", notes: "Debugging guides, route-addition steps, definition of done, and module risk classification table (15 modules, High/Medium/Low) validated against actual file structure and route patterns." },
    { name: "docs/ai/contribution-checklist.md",            status: "Accurate",               statusClass: "align-accurate", notes: "Change-type to doc-update matrix and ADR template validated as consistent with existing ADR structure." },
    { name: "docs/ai/adr-versioned-routes-jwt-and-cache.md", status: "Accurate",              statusClass: "align-accurate", notes: "Versioning rationale, JWT claim split (client vs namespace), and NodeCache strategy validated against route files and jwt-token.ts." },
    { name: "app-manager/Readme.md",                        status: "Accurate",               statusClass: "align-accurate", notes: "Route version table, build commands, and doc links validated against package.json scripts and docs/ai/ file list." },
    { name: ".env.example",                                  status: "Accurate",               statusClass: "align-accurate", notes: "Created at repo root. Lists all four required environment variables (<code>MIDDLEWARE_APP_MANAGER_MOBILE_JWT_SECRET_KEY</code>, <code>MIDDLEWARE_APP_MANAGER_PPBLAPP_MOBILE_JWT_SECRET_KEY</code>, <code>MIDDLEWARE_APP_MANAGER_MONGO_USER</code>, <code>MIDDLEWARE_APP_MANAGER_MONGO_PASSWORD</code>) with placeholder values and descriptions." },
    { name: "ESLint config (.eslintrc)",                     status: "Missing",                statusClass: "align-partial",  notes: "No ESLint configuration found anywhere in the repository. Only Prettier is configured." },
  ],

  /* ── 6. COVERAGE ─────────────────────────────────────────────── */
  coverage: {
    executionStatus: "No test files found in this repository. find . -name '*.test.*' -o -name '*.spec.*' returned zero results. No test framework is configured and no test script exists in package.json. Coverage data cannot be collected.",
    files: [],
  },

  /* ── 7. RISKS ────────────────────────────────────────────────── */
  risks: [
    { id: "r1", severity: "critical", cardClass: "rc-critical", title: "Zero Test Coverage — AI Changes Have No Safety Net", description: "No test files, no test framework, no test script, and no CI test gate exist anywhere in the repository. Any AI-generated change to business logic, middleware, or database queries cannot be regression-tested. A broken JWT verification or cache invalidation would reach production undetected." },
    { id: "r2", severity: "high",     cardClass: "rc-high",     title: "JWT Secrets Require Rotation — Gitignored but Previously Committed", description: "<code>app-manager/tools/test.env</code> is now listed in <code>.gitignore</code>, preventing future tracking. However, two JWT secret key values (<code>MIDDLEWARE_APP_MANAGER_MOBILE_JWT_SECRET_KEY</code> and <code>MIDDLEWARE_APP_MANAGER_PPBLAPP_MOBILE_JWT_SECRET_KEY</code>) were previously committed and remain in git history. Anyone with access to the repository history can retrieve these keys and forge valid JWT tokens. <strong>Rotate both keys immediately.</strong>" },
    { id: "r3", severity: "high",     cardClass: "rc-high",     title: "Jenkins Pipeline Has No Quality Gates", description: "The CI/CD pipeline (Jenkinsfile) goes directly from checkout to Docker build to image push to deploy. No lint, type-check, test, or security-scan stage exists. Malformatted, type-unsafe, or vulnerable code can reach production in a single pipeline run." },
    { id: "r4", severity: "high",     cardClass: "rc-high",     title: "No ESLint — Static Analysis Gap", description: "Only Prettier (formatting) is configured. No ESLint or equivalent static analysis linter runs on commit or in CI. Unused variables, shadowed identifiers, unreachable code, and architectural violations (e.g. direct res.json() in middleware) are not caught automatically." },

    { id: "r6", severity: "medium",   cardClass: "rc-medium",   title: "No Dependency Security Audit in CI", description: "<code>npm audit</code> does not run in the Jenkins pipeline. Transitive dependency CVEs are not detected before deployment. The project has 15+ production dependencies including jsonwebtoken, mongoose, and helmet — all evolving vulnerability surfaces." },
  ],

  /* ── 8. ROADMAP ──────────────────────────────────────────────── */
  roadmap: {
    days30: [
      "Rotate the exposed JWT secret key values for <code>MIDDLEWARE_APP_MANAGER_MOBILE_JWT_SECRET_KEY</code> and <code>MIDDLEWARE_APP_MANAGER_PPBLAPP_MOBILE_JWT_SECRET_KEY</code> — these were previously committed to git history and must be considered compromised.",
      "Add ESLint with <code>@typescript-eslint/recommended</code> to devDependencies and configure it in <code>.eslintrc.js</code>.",
      "Add a lint and type-check stage to the Jenkinsfile before the Build stage.",
      "Add <code>npm audit --audit-level=high</code> as a Jenkins stage after checkout.",
    ],
    days60: [
      "Install Jest and ts-jest. Write unit tests for the three highest-risk middleware files: <code>verifyToken</code>, <code>validateKeysRequest</code>, and <code>xssMiddleware</code>. Target 60% statement coverage on these files.",
      "Add a test stage to the Jenkins pipeline that runs <code>yarn test</code> and blocks the build on failure.",
      "Add inline comments to the three unexplained business logic paths: JWT iat replay check, referrer-bypass cache logic, V3 cache key suffix.",
      "Replace individual strict tsconfig flags with <code>\"strict\": true</code> and fix any newly surfaced type errors.",
    ],
    days90: [
      "Expand test coverage to 60%+ across controllers (fetchKeys, addOrUpdateKeys, deleteKeys) and utility functions (utils/keys.ts cache helpers and DB query builders).",
      "Add integration tests for the full request flow: token creation → route validation → controller → MongoDB → cache → response.",
      "Configure Dependabot or Renovate for automated dependency update PRs with security audit integration.",
    ],
  },

  /* ── 9. AI USAGE GUIDANCE ────────────────────────────────────── */
  guidance: [
    {
      id: "gc-safe", cls: "gc-safe", title: "Safe AI Tasks",
      items: [
        "Adding or updating <code>docs/ai/</code> documentation files — the documentation structure is clear and well-organised.",
        "Adding new TypeScript interfaces or extending existing ones in <code>common/models/</code> — type-only changes with low blast radius.",
        "Adding new constants to <code>constants.ts</code> (new client IDs, error codes) following the existing enum-style object pattern.",
        "Improving JSDoc comments on existing middleware and controller functions.",
        "Adding new environment configuration files under <code>environment/</code> following the existing JSON key schema.",
      ],
    },
    {
      id: "gc-review", cls: "gc-review", title: "AI Tasks Requiring Review",
      items: [
        "Adding a new route — must include validator middleware, verifyToken wiring, and docs/ai/api-error-handling.md update. Verify middleware chain order matches AGENTS.md.",
        "Adding a new client type — must update constants.ts CLIENT object, then verify getConfigClientIds() picks it up automatically.",
        "Modifying MongoDB query logic in controllers/keys.ts — the aggregate pipeline is complex and any projection or match change affects all API versions.",
        "Changing cache key patterns or TTL logic — verify cache invalidation on writes is consistent with the new key pattern.",
        "Modifying error response shapes — ErrorWrapper fields feed directly into the global error handler response serialisation.",
      ],
    },
    {
      id: "gc-nogo", cls: "gc-nogo", title: "AI Must Not Touch",
      items: [
        "<code>middleware/jwt-token.ts</code> — JWT verification logic. Any regression breaks authentication for all clients across all route versions.",
        "<code>middleware/auth.ts</code> (xssMiddleware) — removing or restricting surfaces covered breaks the XSS security guarantee.",
        "<code>server.ts</code> middleware order — the guard sequence (body-parser → Morgan → checkAllowedMethods → xssMiddleware → Helmet) must not be reordered.",
        "<code>src/config/index.ts</code> — secret injection logic. Never add secrets to config JSON files.",
        "Existing route version definitions (v1/v2/v3) — do not add new behavior to existing versions; create v4+ instead.",
      ],
    },
    {
      id: "gc-prime", cls: "gc-prime", title: "Prime Context Files for AI",
      items: [
        "<code>AGENTS.md</code> — canonical conventions, security rules, and prohibition list.",
        "<code>src/app-manager/constants.ts</code> — all error codes, client IDs, JWT claim names, cache keys.",
        "<code>src/app-manager/common/models/error.ts</code> — ErrorWrapper class definition.",
        "<code>src/app-manager/middleware/validations.ts</code> — shows the validator pattern to follow for new routes.",
        "<code>src/app-manager/middleware/jwt-token.ts</code> — shows verifyToken and verifyTokenV2 for auth chain wiring.",
        "The relevant <code>routes/&lt;version&gt;/config.routes.ts</code> file for the version being modified.",
      ],
    },
    {
      id: "gc-post", cls: "gc-post", title: "Post-AI Change Checklist",
      items: [
        "Run <code>yarn build:dev</code> — confirm zero TypeScript compilation errors.",
        "Run <code>npx prettier --check \"src/**/*.ts\"</code> — confirm zero formatting violations.",
        "If a new route was added: confirm validator middleware is registered before verifyToken in the route definition.",
        "If constants.ts was changed: confirm no string literals were introduced — only references to the new constants.",
        "Review the full <code>git diff</code> against the AGENTS.md prohibition list before committing.",
      ],
    },
    {
      id: "gc-anti", cls: "gc-anti", title: "Anti-Patterns to Avoid",
      items: [
        "Asking AI to add a new route without also specifying its validator middleware — AI will omit it and create an unauthenticated endpoint.",
        "Accepting AI-generated error handling that uses <code>res.status().json()</code> directly — must always use <code>ErrorWrapper + next()</code>.",
        "Using AI to collapse v1/v2/v3 route logic into a single endpoint — this breaks the backward compatibility contract documented in ADR-001.",
        "Asking AI to modify jwt-token.ts without providing constants.ts and common/models/jwt-payload.ts as context — AI will infer wrong claim names.",
        "Letting AI suggest <code>any</code> types without requiring a justification comment — defeats TypeScript's value for AI reasoning.",
      ],
    },
  ],

  /* ── 10. VERDICT ─────────────────────────────────────────────── */
  verdict: {
    label: "No-Go — Basic AI Readiness",
    cls: "vb-nogo",
    body: [
      "This repository scores <strong>3.02 / 5.0</strong> (up from 2.58 at first audit — a cumulative +0.44 improvement). This cycle: D5 rose 3.5 → 4.0 (Commands Validated now checked — <code>typecheck</code> script and Jenkins Type Check stage added), D9 rose 1.5 → 2.0 (Type Check is now an explicit Jenkins gate). Prior cycle gains: D10 rose 2.8 → 3.0 (module risk table), D5 rose 3.0 → 3.5 (.nvmrc), D2 rose 4.0 → 4.5 (deployment topology), D3 rose 4.2 → 4.7 (CODEOWNERS), D5 rose 2.5 → 3.0 (.env.example), D6 rose 2.8 → 3.4 (tools/test.env gitignored), D10 rose 2.0 → 2.8 (CODEOWNERS). Score is now above 3.0 for the first time. The dominant remaining blocker is zero test coverage.",
      "The score is still held down by two structural gaps that were not addressed in this cycle: <strong>zero automated tests</strong> (D1 scores 0.5 at 20% weight — the single largest drag on the overall score) and a <strong>Jenkins pipeline with no quality gates</strong> (D9 scores 1.5 at 5% weight). Together these mean AI-generated changes cannot be safely validated before reaching production. A security remediation item also remains open: the JWT secret keys previously committed in <code>tools/test.env</code> are still present in git history and <strong>must be rotated</strong> even though the file is now gitignored.",
      "<strong>Path forward:</strong> Key rotation is the immediate next action. Adding ESLint and a Jenkins lint/type-check stage (30-day roadmap) would lift D4 from 3.0 → ~3.6 and D9 from 1.5 → ~2.5. Writing unit tests for the three highest-risk middleware files and adding a Jenkins test gate (60-day roadmap) would bring D1 from 0.5 to approximately 2.5 — the single largest score lever available. Completing the 60-day roadmap would raise the estimated overall score to approximately <strong>3.2 / 5.0 (Conditional Go)</strong>, enabling confident AI-assisted feature development with clear regression safety.",
    ],
  },
};

// Required: expose to window so the HTML renderer can read it.
window.REPORT_DATA = REPORT_DATA;
